/**
 * JPfm is a java language binding for Pismo file mount ( http://www.pismotechnic.com/pfm/ ). </p>
 * </p>
 * Pismo File Mount has been created by Joe Lowe.
 * Implementors interested in making a readonly filesystem (functions other than read are intrinsically
 * blocking nature) quickly should start with reading {@link jpfm.JPfmReadOnlyFormatter } .
 * For making a readonly or writable filesystem with all filesystem function that
 * are non-blocking in nature should directly go to {@link jpfm.JPfmFormatter } .
 * JPfm was originally create by Shashank Tulsyan specifically
 * for Neembuu http://neembuu.sourceforge.net/ 
 * but evolved in such a fashion as to allow more diverse usage.
 * JPfm site : http://jpfm.sourceforge.net/ 
 */
package jpfm;

