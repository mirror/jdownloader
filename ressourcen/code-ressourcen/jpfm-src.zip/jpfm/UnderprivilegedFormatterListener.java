/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   UnderprivilegedFormatterListener.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.util.concurrent.CountDownLatch;

/**
 * These can be used to listener to various
 * messages (informative, error, warning ...)
 * from both native side and java side of jpfm.
 * 
 * @author Shashank Tulsyan
 */
public interface UnderprivilegedFormatterListener {

    public void eventOccurred(FormatterEvent event);

    public class WaitingUnderprivilegedFormatterListener implements UnderprivilegedFormatterListener {

        CountDownLatch latch;

        public WaitingUnderprivilegedFormatterListener() {
            latch = new CountDownLatch(1);
        }

        public void waitUntilUnmounted(){
            try{
                latch.await();
            }catch(InterruptedException a){
                a.printStackTrace();
            }
        }

        public void eventOccurred(FormatterEvent event) {
            if(event.getEventType()==FormatterEvent.EVENT.DETACHED){
                latch.countDown();
            }
        }

    }
}
