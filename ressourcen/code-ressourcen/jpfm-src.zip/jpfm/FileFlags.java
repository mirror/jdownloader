/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *  http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

import jpfm.operations.NativeInterfaceMethods;

/**
 *
 * <b>File flags</b><br/>
 * Invalid (0xFF),<br/>
 * ReadOnly (0x01),<br/>
 * Hidden (0x02),<br/>
 * System (0x04),<br/>
 * Execute 0x08,<br/>
 * Archive (0x20)<br/>
 *<br/><br/>
 * <b>EXTRA FILES FLAGS</b><br/>
 * PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagOffline, 0x01);<br/>
 * PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagNoIndex, 0x02);<br/>
 * @author Shashank Tulsyan
 */
public final class FileFlags {
//    stored in unsigned 8bit int
//    Invalid (0xFF),
//    ReadOnly (0x01),
//    Hidden (0x02),
//    System (0x04),
//    Execute 0x08,
//    Archive (0x20)

// EXTRA FILES FLAGS
//PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagOffline, 0x01);
//PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagNoIndex, 0x02);


    static {
        NativeInterfaceMethods.setFlagbuilder(new SimpleBuilder());
    }



    private final short fileFlag;//using 2bytes, and later we will just &0xFF what we need
    private final short extraFileFlag;


    /*package private*/ FileFlags(final short fileFlag, final short extraFileFlag) {
        this.fileFlag = fileFlag;
        this.extraFileFlag = extraFileFlag;
    }

    public final boolean isInvalid(){
        // (0xFF),
        return (fileFlag&0xff) == 0xff;
    }
    public final boolean isReadOnly(){
        //(0x01),
        return ( fileFlag&0x01 ) == 0x01;
    }
    public final boolean isHidden(){
        //(0x02),
        return ( fileFlag&0x02) == 0x02;
    }
    public final boolean isSystem(){
        //(0x04),
        return (fileFlag&0x04) == 0x04;
    }
    public final boolean isArchive(){
        //(0x20);
        return (fileFlag&0x20) == 0x20;
    }
    public final boolean isExecutable(){
        //0x08,
        return (fileFlag&0x08) == 0x08;
    }

    public final boolean isOffline(){
        //PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagOffline, 0x01);
        return ( extraFileFlag&0x01) == 0x01;
    }

    public final boolean isNoIndex(){
        //PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagNoIndex, 0x02);
        return ( extraFileFlag&0x02 ) == 0x02;
    }


    public final int getFileFlag() {
        return fileFlag;
    }

    public final int getExtraFileFlag(){
        return extraFileFlag;
    }

    @Override
    public String toString() {
        return  " FileFlags{"
                +(isExecutable()?"isExecutable,":"")
                +(isArchive()?"isArchive,":"")
                +(isReadOnly()?"isReadOnly,":"")
                +(isSystem()?"isSystem,":"")
                +(isHidden()?"isHidden":"")
                +(isNoIndex()?"isNoIndex":"")
                +(isOffline()?"isOffline":"")
                +"}";
    }

    /**
     * used internally
     */
    public static final class SimpleBuilder {
        private SimpleBuilder() {
        }
        public FileFlags build(short fileFlag){
            return new FileFlags(fileFlag,(short)0);
        }
        public FileFlags build(short fileFlag,short extrafileflag){
            return new FileFlags(fileFlag,extrafileflag);
        }
    }

    public static final class Builder {
        private short fileFlag = 0;
        private short extraFileFlag = 0;

        public Builder(){
            fileFlag = 0;
            extraFileFlag = 0;
        }

        /**
         * Removes all flags in this.
         * It does not affect extra file flags however.
         * @return
         */
        public final Builder clear(){
            fileFlag = 0;
            return this;
        }

        /**
         * Removes all extrafileflags from this.
         * It does not affect fileflags however.
         * @return
         */
        public final Builder clearExtraFlags(){
            extraFileFlag = 0;
            return this;
        }

        /**
         * Sets the fileflags invalid. This function
         * has no effect on extrafileflags.
         * @return
         */
        public final Builder setInvalid(){
            // (0xFF),
            fileFlag|=0xff;
            return this;
        }
        public final Builder setReadOnly(){
            checkIsInvalid();
            //(0x01),
            fileFlag|=0x01;
            return this;
        }
        public final Builder setHidden(){
            checkIsInvalid();
            //(0x02),
            fileFlag|=0x02;
            return this;
        }
        public final Builder setSystem(){
            checkIsInvalid();
            //(0x04),
            fileFlag|=0x04;
            return this;
        }
        public final Builder setArchive(){
            checkIsInvalid();
            //(0x20);
            fileFlag|=0x20;
            return this;
        }
        /**
         * We recommend that this flag is not set.
         * Some utilities (like unlocker for windows) have been found to
         * have difficulty unlocking files. This could be troublesome if
         * the file that the user is trying to unlock is a malicious program.
         * Setting this flag should be avoided as far as possible.
         * @return
         */
        public final Builder setExecutable(){
            checkIsInvalid();
            //(0x08);
            fileFlag|=0x08;
            return this;
        }

        /**
         * Pismo extra file flag. Use OFFLINE and NO_INDEX for files
         * that are on the network. Use of these will cause
         * windows explorer (in case of windows) to not render
         * thumbnails. Rending of thumbnails automatically is a problem
         * since this causes download of unnessary regions.
         * @return
         */
        public final Builder setOffline(){
            //PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagOffline, 0x01);
            extraFileFlag|=0x01;
            return this;
        }

        /**
         * Pismo extra file flag. Use OFFLINE and NO_INDEX for files
         * that are on the network. Use of these will cause
         * windows explorer (in case of windows) to not render
         * thumbnails. Rending of thumbnails automatically is a problem
         * since this causes download of unnessary regions.
         * @return
         */
        public final Builder setNoIndex(){
            //PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagNoIndex, 0x02);
            extraFileFlag|=0x02;
            return this;
        }

        public final void checkIsInvalid()throws IllegalStateException{
            if(isInvalid()){
                throw new IllegalStateException(
                    "This fileflag has already been set to invalid. If you want to use this object, invoke clear first");
            }
        }

        public final boolean isInvalid(){
            // (0xFF),
            return (fileFlag&0xff) == 0xff;
        }
        public final boolean isReadOnly(){
            //(0x01),
            return ( fileFlag&0x01 ) == 0x01;
        }
        public final boolean isHidden(){
            //(0x02),
            return ( fileFlag&0x02) == 0x02;
        }
        public final boolean isSystem(){
            //(0x04),
            return (fileFlag&0x04) == 0x04;
        }
        public final boolean isExecutable(){
            //0x08,
            return (fileFlag&0x08) == 0x08;
        }
        public final boolean isArchive(){
            //(0x20);
            return (fileFlag&0x20) == 0x20;
        }
        public final boolean isOffline(){
            //PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagOffline, 0x01);
            return ( extraFileFlag&0x01) == 0x01;
        }

        public final boolean isNoIndex(){
            //PFM_STATIC_CONST( PFM_UINT8, pfmExtraFlagNoIndex, 0x02);
            return ( extraFileFlag&0x02 ) == 0x02;
        }

        public FileFlags build(){
            return new FileFlags(fileFlag,extraFileFlag);
        }

    }

}
