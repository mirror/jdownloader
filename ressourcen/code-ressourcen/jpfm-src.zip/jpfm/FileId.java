/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

import java.util.Comparator;
import jpfm.operations.FileSystemOperation;
import jpfm.operations.NativeInterfaceMethods;

/**
 * This class wraps PFM fileID or openID.<br/>
 * As explained in {@link FileDescriptor } files and folder are
 * generally represented by numbers in pismo filesystem, NOT by path.
 * The reason being path of the file is mutable, whereas the number once
 * passed has to kept so forever throughout the life time of the file.
 * <br/>
 * One exception to this is, if the file changes it's size by itself,
 * that is, not from setSize requests from the client/user 's side.
 * This happens, for example, in Avisynth filesystem 's error.log file.
 * As more error and trace messages are put the file size grows.
 * To keep PFM aware of this change, the entire FileDescriptor needs to be
 * changed with the new one that comes. How to do this is explained in
 * {@link FileAttributesProvider#getFileSize() }.
 * <br/>
 * @see FileDescriptor
 * @author Shashank Tulsyan
 */
public final class FileId implements Comparable<FileId>, Comparator<FileId>{
    public static final FileId INVALID = new FileId(0);
    public static final Comparator<FileId> COMPARATOR = new FileId(0);
    private final long openId;// 8bytes
    //total class size object = perfect 16bytes

    static {
        NativeInterfaceMethods.setFileIdBuilder(Builder.SINGLETON);
        FileSystemOperation.setFileIdBuilder(Builder.SINGLETON);
    }

    /*package private*/ FileId(final long openId){
        this.openId = openId;
    }

    /*package private*/ final long getOpenId() {
        return openId;
    }

    @Override
    public final String toString() {
        return "FileId{" + this.openId +"}";
    }


    public final boolean isValid(){
        return openId >0 ;
    }

    public final boolean implies(FileDescriptor fd){
        return fd.implies(this);
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof FileId)){
            return false;
        }
        if(this.openId==0)
            return super.equals(obj);
        return ((FileId)obj).openId == this.openId;
    }

    @Override
    public int hashCode() {
        if(openId==0)
            return super.hashCode();
        // if the above line is not included,
        // for somereason, things do not work
        return (int)openId;
    }


    /**
     * Included for allowing quick search and sort.
     * Can be used with java collections api.
     */
    public int compareTo(FileId o) {
        return ((int) (this.openId - o.openId));
    }

    /**
     * Included for allowing quick search and sort.
     * Can be used with java collections api.
     */
    public int compare(FileDescriptor o1, FileDescriptor o2) {
        return o1.compareTo(o2);
    }
    /**
     * Included for allowing quick search and sort.
     * Can be used with java collections api.
     * Use this instance of Comparator to make things simple
     */
    public static final Comparator<FileId> getComparator() {
        return COMPARATOR;
    }

    /**
     * Used from native side
     * for some unknown reason calling constructors does not work properly
     * for some unknown reason calling constructors does not work properly
     * @return an instance
     */
    private final static FileId constructFileId(final long openid){
        if(openid < 0) throw new IllegalArgumentException("Trying to create a openid with negative value");
        return new FileId(openid);
    }

    public int compare(FileId o1, FileId o2) {
        return o1.compareTo(o2);
    }

    public static final class Builder {
        private static final Builder SINGLETON = new Builder();
        private Builder(){    
        }
        public final FileId constructFileId(final long openid){
            return FileId.constructFileId(openid);
        }

    }
}
