/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

/**
 *
 * @author Shashank Tulsyan
 */
public final class Media {

    Media() {
    }
//#define PFM_UUID struct {
//    PFM_UINT32 data1;
//    PFM_UINT16 data2; PFM_UINT16 data3; PFM_UINT8 data4[8]; }
//struct PfmMediaInfo
//{
//   PFM_UUID mediaUuid;
//   PFM_UINT64 mediaId64;
//   PFM_UINT32 mediaId32;
//   PFM_UINT8 mediaFlags;
//   PFM_UINT8 reserved1[3];
//   PFM_INT64 createTime;
//}

    
//   GUID     mediaUuid ;
//   uint64_t mediaId64 ;
//   uint32_t mediaId32 ;
//   uint8_t  mediaFlags ;
//   int64_t  createTime ;



}
