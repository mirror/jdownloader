/*
 *  Copyright 2010 Shashank Tulsyan.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */
package jpfm.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Indicates that the annotated abstract method is designed
 * in such a way that it can be implemented in non-blocking fashion.
 * If this annotation is noticed on an abstract method, it means that
 * the implementor should try to implement the function in NonBlocking fashion.
 * But that is only an option. Implementor may implement it in a blocking
 * fashion as well. Since we are unsure how the implementor will do it we
 * annotated the method as <b>MightBeBlocking </b>.
 * Like {@link java.io.RandomAccessFile#read() } is blocking in nature
 * while {@link java.nio.channels.AsynchronousFileChannel#read(java.nio.ByteBuffer, long) } is not.
 * {@link jpfm.JPfmFileSystem#read(jpfm.operations.Read) } can be implemented using
 * either {@link java.io.RandomAccessFile#read() } or
 * {@link java.nio.channels.AsynchronousFileChannel#read(java.nio.ByteBuffer, long, java.lang.Object, java.nio.channels.CompletionHandler) }
 * so {@link jpfm.JPfmFileSystem#read(jpfm.operations.Read) } may be marked as
 * {@link jpfm.annotations.MightBeBlocking }.
 * Similarly all methods using api such as AsynchronousFileChannel would have a @NonBlocking annotation to indicate this.
 * When an entire class in indicated as MightBeBlocking, it implies all functions
 * are so unless explicitly annotated.
 * @author Shashank Tulsyan
 */
@Documented
@Retention(value=RetentionPolicy.RUNTIME) // to allow inspection of classes for blocking functions even in runtime
@Target(value={ElementType.METHOD,ElementType.TYPE})
public @interface MightBeBlocking {
    /**
     * @return The name of the function or module which is suspected
     * to be blocking in nature OR some string decribing why possiblity
     * of blocking nature was not eliminated. Annotating an abstract method
     * with this implies that the method MightBeBlocking because we cannot
     * gaurentee how the implementor implements the code.
     */
    public String reason() default "UNKNOWN";
}
