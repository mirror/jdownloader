/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations.readwrite;


/**
 * The job of a Completer is to call complete function on a pending read request.
 * The completer can optionally register with a {@link jpfm.operations.Read }.
 * Registering will not prevent other Completers from calling complete function,
 * unless if they use {@link jpfm.operations.Read#complete(jpfm.JPfmError, int, jpfm.operations.readwrite.Completer)  },
 * and pass and object of themselves. In such a case an exception will be thrown.
 * It is a good practice to use {@link jpfm.operations.Read#complete(jpfm.JPfmError, int, jpfm.operations.readwrite.Completer)  }
 * as it helps in finding out implementation mistakes. Completer interface and associate functions
 * have been provided as utility for the implementors, it is on the implementor to decide what he
 * would like to use.
 * @author Shashank Tulsyan
 */
public interface Completer<R extends ReadRequest> {
    /**
     * @return number of bytes already filled in the bytebuffer correctly
     * the position variable ot bytebuffer is not a safe way to check this
     * as bytebuffer is often splitted and filled as an array from different
     * offets rather than linearly. Linearly is a common situation, but there
     * are exceptions as already explained. Typical example in jpfm.fs.SplitFS
     */
    public int getBytesFilledTillNow(R pendingRequest);

    /**
     * If a request is taking very long to complete, the filesystem
     * might decide to simply supply whatever is available till now
     * even if the buffer has not been completely filled.
     * Any filesystem which worries about application being casted into
     * <b>Not responding</b> state will do this.
     */
    public void completeNow(R pendingRequest);

    /**
     * This is for strict debugging purposes.
     * @return the program path followed that resulted in finally completing the
     * pending request.
     */
    public StackTraceElement[]getStackTrace();
}
