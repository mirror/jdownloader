/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.AccessLevel;
import jpfm.FileAttributesProvider;
import jpfm.FileControlFlag;
import jpfm.FileId;
import jpfm.JPfmError;
import jpfm.FileFlags;
import jpfm.FileType;

/**
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileId<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 *
 * This function is called by the marshaller to process file open and create requests from the driver.
 * Correct use of newCreateOpenId parameter, the newExistingOpenId parameter, the existed result,
 * the openAttribs->openId result, and the openAttribs->openSequence result, are critical to proper
 * functioning of the atomicity guarantees provided by the driver.<br/><br/>
 *
 * If the formatter returns no error (0) then it must return the information about the newly opened/created
 * file through the openAttribs parameter, the existed parameter, and optionally through the parentFileId
 * parameter the endName parameter. All of the openAttribs->attribs fields must be filled.
 * The four time fields in openAttribs->attribs should be filled with valid times, or with constant pfmTimeInvalid.<br/><br/>
 * The name of the file being opened is indicated by the nameParts and namePartCount parameters.<br/><br/>
 *
 * If the formatter determines that the indicated file exists but has not already been opened then it must
 * associate the driver specified newExistingOpenId with the file, and return this same value in
 * openAttribs->openId. The openAttribs->openSequence value must be initialized to a non zero positive value,
 * and the value must be associated with the open file for use during subsequent close processing.
 * The  variable referenced by the existed parameter must be set to true.
 * If the formatter determines that the indicated file is already open then it must return in openAttribs->openId
 * the same openId that is already associated with the open file. The openAttribs->openSequence value must be
 * initialized to a positive value that is greater than the openSequence returned by any previous open of the
 * same file. The new openSequence value must be associated with the open file for use during subsequent close processing.
 * The variable referenced by the existed parameter must be set to true.
 * If the parent folder of the indicated file does not exist then the formatter should return pfmErrorParentNotFound.
 * If the indicated file does not exist and the newCreateOpenId parameter is zero then the formatter should return
 * pfmErrorNotFound.
 * If the indicated file does not exist and the newCreateOpenId parameter is non-zero then the formatter should
 * create the file. The createFileType, createFileFlags, and writeTime parameters should be used to to
 * initialize the new file. The formatter must associate the driver specified newCreateOpenId with the file,
 * and return this same value in openAttribs->openId. The openAttribs->openSequence value must be initialized
 * to a non zero positive value, and the value must be associated with the open file for use during subsequent
 * close processing. The variable referenced by the existed parameter must be set to false.<br/><br/>
 *
 * If the formatter is opening a file with different spelling for the last name component than was specified
 * by the driver then it must return the correct spelling through the endName parameter. If the endName is
 * returned then the marshaller will call the PfmFormatterOps::ReleaseName function to allow the formatter
 * to free any related memory.<br/><br/>
 * 
 * The openAttribs->accessLevel field should be filled with the highest access level currently available for
 * the file. For most formatters this field can always be initialized with pfmAccessWriteData.
 * For redirectors, when opening existing files, the existingAccessLevel parameters can be used
 * to avoid opening files with higher access levels than are needed for the current request.
 * @see jpfm.JPfmFileSystem#open(jpfm.operations.Open)
 * @see jpfm.JPfmReadOnlyFileSystem#open(java.lang.String[]) 
 * @author Shashank Tulsyan
 */
public final class Open extends FileSystemOperation {
//struct PfmMarshallerOpenOp
//{
//   virtual const PfmNamePart* PFM_CCALL NameParts(void) = 0;
//   virtual size_t             PFM_CCALL NamePartCount(void) = 0;
//   virtual PFM_INT8           PFM_CCALL CreateFileType(void) = 0;
//   virtual PFM_UINT8          PFM_CCALL CreateFileFlags(void) = 0;
//   virtual PFM_INT64          PFM_CCALL WriteTime(void) = 0;
//   virtual PFM_INT64          PFM_CCALL NewCreateOpenId(void) = 0;
//   virtual PFM_INT8           PFM_CCALL ExistingAccessLevel(void) = 0;
//   virtual PFM_INT64          PFM_CCALL NewExistingOpenId(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError,bool existed,const PfmOpenAttribs* openAttribs,PFM_INT64 parentFileId,const wchar_t* endName,PfmFormatterSerializeOpen* serializeOpen) = 0;
//};

    private final long handle;
    private final long formatterDispatch;
    private final String[]name;
    private final int fileType;
    private final FileFlags createFlags;
    private final long writeTime;
    private final long newCreateOpenId;
    private final AccessLevel existingAccessLevel;
    private final long newExistingOpenId;

    private final AtomicBoolean completed = new AtomicBoolean(false);

    /*package private*/ Open(
            final long handle,
            final long formatterDispatch,
            final String[] name,
            final int fileType,
            final FileFlags createFlags,
            final long writeTime,
            final long newCreateOpenId,
            final AccessLevel existingAccessLevel,
            final long newExistingOpenId) {
        this.handle = handle;
        this.formatterDispatch = formatterDispatch;
        this.name = name;
        this.fileType = fileType;
        this.createFlags = createFlags;
        this.writeTime = writeTime;
        this.newCreateOpenId = newCreateOpenId;
        this.existingAccessLevel = existingAccessLevel;
        this.newExistingOpenId = newExistingOpenId;
    }

    public final FileFlags getCreateFlags() {
        return createFlags;
    }

    public final AccessLevel getExistingAccessLevel() {
        return existingAccessLevel;
    }

    public final FileType getFileType() {
        if(fileType==FileType.FILE.getFileType())
            return FileType.FILE;
        if(fileType==FileType.NONE.getFileType())
            return FileType.NONE;
        return FileType.FOLDER;
    }

    public final String[] getName() {
        return name;
    }

    public final long getWriteTime() {
        return writeTime;
    }

    public final boolean isCompleted() {
        return completed.get();
    }

    public final FileId getNewCreateFileId(){
        return FILEID_BUILDER.constructFileId(newCreateOpenId);
    }

    public final FileId getNewExistingFileId(){
        return FILEID_BUILDER.constructFileId(newExistingOpenId);
    }


    ////   virtual void PFM_CCALL Complete(
    //int pfmError,
    //bool existed,
    //const PfmOpenAttribs* openAttribs, // FileAttributesProvider
    //PFM_INT64 parentFileId, // FileAttributesProvider.getParentFileId
    //const wchar_t* endName, // FileAttributesProvider.getName
    //PfmFormatterSerializeOpen* serializeOpen) = 0; // FileAttributesProvider.getFileId

    public final void complete(
            final JPfmError error,
            final boolean existed,
            final AccessLevel accessLevel,
            final FileControlFlag controlFlag,
            final FileAttributesProvider attributesProvider
        ) throws IllegalStateException, IllegalArgumentException{

        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        
        /*if(error == JPfmError.SUCCESS && attributesProvider==null){
            NativeInterfaceMethods.completeOpen(
                handle,
                formatterDispatch,
                error.getErrorCode(),
                existed,
                accessLevel!=null?accessLevel.getAccessLevel():null,
                controlFlag!=null?controlFlag.getControlFlag():null,
                null,
                null,
                null,
                null
            );
            // thin
            //throw new IllegalArgumentException("FileAttributesProvider suppl");
        }*/

        //set FileId's open status
        if(attributesProvider!=null){
            if(attributesProvider.getFileDescriptor()!=null){
                //TODO: attributesProvider.getFileId.open
                //export open function somehow
            }
        }

        NativeInterfaceMethods.completeOpen(
                handle,
                formatterDispatch,
                error==null?JPfmError.FAILED.getErrorCode():error.getErrorCode(),
                existed,
                accessLevel!=null?accessLevel.getAccessLevel():0,
                controlFlag!=null?controlFlag.getControlFlag():0,
                attributesProvider,
                attributesProvider!=null?attributesProvider.getParentFileDescriptor():null,
                attributesProvider!=null?attributesProvider.getName():"",// better than sending null
                attributesProvider!=null?attributesProvider.getFileDescriptor():null
            );
    }


    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    
    public final void handleUnexpectedCompletion(final Exception exception){
        if(!this.completed.get()){
            if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
                //we were expecting false, but it is true. implying it is already complete, throw an exception
                throw AlreadyCompleteException.createNew();
            }
            NativeInterfaceMethods.completeOpen(handle, formatterDispatch, 0, false, 0, 0, null, null, null, null);
            //this.complete(JPfmError.FAILED,false,AccessLevel.OWNER,FileControlFlag.NONE,null);

        }
    }

    @Override
    public String toString() {
        StringBuilder path = new StringBuilder();
        path.append("$root");
        path.append(java.io.File.separatorChar);
        for (int i = 0; i < name.length; i++) {
            path.append(name[i]);
            path.append(java.io.File.separatorChar);
        }
        return "Open{"+ path.toString() + "}{"+ this.createFlags + "}{"+ this.existingAccessLevel + "}{newCreateOpenId="+ this.newCreateOpenId + "}{newExistingOpenId="+ this.newExistingOpenId + "}" ;
    }
}
