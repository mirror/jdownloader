/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.FileId;
import jpfm.JPfmError;
import jpfm.JPfmReadOnlyFileSystem;

/**
 * Also read {@link  JPfmReadOnlyFileSystem#delete(jpfm.FileId) }
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileId<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * The marshaller calls this function when processing a delete
 * request from the driver. This request is made when a file
 * name is being deleted.
 * Formatters that support multiple file names for a single
 * file (hard links) can use the parentFileId and endName
 * parameters to identify which file name is being deleted.
 * @see JPfmReadOnlyFileSystem#delete(jpfm.FileId)
 * @see jpfm.JPfmFileSystem#delete(jpfm.operations.Delete) 
 * @author Shashank Tulsyan
 */
public final class Delete extends FileSystemOperation {
//struct PfmMarshallerDeleteOp
//{
//   virtual PFM_INT64          PFM_CCALL OpenId(void) = 0;
//   virtual PFM_INT64          PFM_CCALL ParentFileId(void) = 0;
//   virtual const PfmNamePart* PFM_CCALL EndName(void) = 0;
//   virtual PFM_INT64          PFM_CCALL WriteTime(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError) = 0;
//};

    private final long handle;
    private final long formatterDispatch;
    private final long fileId;

    private final AtomicBoolean completed = new AtomicBoolean(false);

    

    /*package private*/ Delete(final long handle,final long formatterDispatch,final long fileid) {
        this.handle = handle;
        this.formatterDispatch = formatterDispatch;
        this.fileId = fileid;
    }

    public FileId getFileId() {
        return FILEID_BUILDER.constructFileId(fileId);
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    
    public final boolean isCompleted() {
        return completed.get();
    }


    public void complete(final JPfmError pfmError)throws IllegalStateException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeDelete(handle,formatterDispatch,pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode());
    }

    public final void handleUnexpectedCompletion(final Exception exception){
        if(!isCompleted()){
            this.complete(JPfmError.FAILED);
        }
    }

    @Override
    public String toString() {
        return "Delete{"+ getFileId() + "}";
    }
    
}
