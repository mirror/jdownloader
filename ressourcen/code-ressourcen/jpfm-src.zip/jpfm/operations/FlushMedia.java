/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.JPfmError;

/**
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileDescriptor<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * In most cases implementor would just
 * pass JPfmError.SUCCESS,  and a flushDelay of -1
 * in {@link FlushMedia#complete(jpfm.JPfmError, int) }
 * flushDelay of -1 indicates flushDelay = infinity
 * <br/>
 * <br/>
 * <br/>
 * <br/>
 * <br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * The driver will generate a flush media request shortly after a
 * preiod of inactivity (~1 second). The formatter
 * can use this request to perform whatever updates
 * are applicable based on the file system characteristics.
 *
 * If an error is returned from this function, a cache write
 * failure notification will be displayed to the user.
 *
 * The driver will continue to generate media flush requests
 * every few seconds unless the formatter set the mediaClean
 * parameter to true.
 * @see jpfm.JPfmFileSystem#flushMedia(jpfm.operations.FlushMedia) 
 * @author Shashank Tulsyan
 */
public final class FlushMedia extends FileSystemOperation {
//struct PfmMarshallerFlushMediaOp
//{
//   virtual void PFM_CCALL Complete(int pfmError,int msecFlushDelay) = 0;
//};
    private final long handle;
    private final long formatterDispatch;
    private final AtomicBoolean completed = new AtomicBoolean(false); // we use atomicboolean eveywhere to ensure

    public static final int INDEFINITE_FLUSH_DELAY = -1;


    /*package private*/ FlushMedia(final long handle,final long formatterDispatch) {
        this.handle = handle;
        this.formatterDispatch = formatterDispatch;
    }

    public final boolean isCompleted() {
        return completed.get();
    }


    /**
     * @param pfmError
     * @param msecFlushDelay the time in milli seconds that system should wait
     * before issuing calles to flush. A negative value indicates that this
     * volume does not require to be flushed, that is all writes are
     * instantaneously committed to the storage device.
     * @throws IllegalStateException if complete method was already called
     */
    public void complete(final JPfmError pfmError,final int msecFlushDelay)throws IllegalStateException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeFlushMedia(handle, formatterDispatch,pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode(),msecFlushDelay);
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    
    public final void handleUnexpectedCompletion(final Exception exception){
        if(!completed.get()){
            this.complete(JPfmError.FAILED, -1);//got from ramfs
        }
    }

    @Override
    public String toString() {
        return "FlushMedia";
    }

}
