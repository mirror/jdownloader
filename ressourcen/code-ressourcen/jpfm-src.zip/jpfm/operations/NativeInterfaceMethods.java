/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.nio.ByteBuffer;
import jpfm.AccessLevel;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileFlags.SimpleBuilder;
import jpfm.FileId;
import jpfm.Media;

/**
 *
 * @author Shashank Tulsyan
 */
public final class NativeInterfaceMethods {
    private static FileDescriptor.Builder fdb;
    private static FileFlags.SimpleBuilder flagbld;
    private static FileId.Builder fileidbuilder;

    private static final boolean DEBUG = true;

    static {
        FileDescriptor.Builder.class.getClass();
        FileDescriptor.FDModifier.class.getClass();
        FileId.Builder.class.getClass();
        FileFlags.SimpleBuilder.class.getClass(); // ensuring execution of static block
    }

    public final static void setBuilder(final FileDescriptor.Builder fdbuild){
        if(fdbuild==null)throw new NullPointerException("Attempting to set FileDescriptor builder to null");
        NativeInterfaceMethods.fdb = fdbuild;
    }

    public static void setFlagbuilder(final SimpleBuilder flagbld) {
        if(flagbld==null)throw new NullPointerException("Attempting to set FileFlag builder to null");
        NativeInterfaceMethods.flagbld = flagbld;
    }

    public static void setFileIdBuilder(final FileId.Builder builder){
        if(builder==null)throw new NullPointerException("Attempting to set FileId builder to null");
        fileidbuilder = builder;
    }


    private final static Capacity constructCapacityOp(final long handle,final long formatterDispatch,final long openId){
        Capacity capacity = new Capacity(handle, formatterDispatch, openId);
        if(DEBUG)System.out.println(capacity);
        return capacity;
    }

    private final static Close constructCloseOp(final long handle,final long formatterDispatch,final long openId){
        Close close = new Close(handle, formatterDispatch,  fdb.build(openId));
        if(DEBUG)System.out.println(close);
        return close;
    }

    private final static Control constructControlOp(
            final long handle,
            final long formatterDispatch,
            final int accessLevel,
            final int controlCode,
            final ByteBuffer input,
            final ByteBuffer output,
            final long openId){
        Control control = new Control(handle, formatterDispatch, AccessLevel.get(accessLevel), controlCode, input, output, openId);
        if(DEBUG)System.out.println(control);
        return control;
    }

    private final static Delete constructDeleteOp(final long handle,final long formatterDispatch,final long openId){
        Delete delete = new Delete(handle, formatterDispatch, openId);
        if(DEBUG)System.out.println(delete);
        return delete;
    }

    private final static FlushFile constructFlushFileOp(final long handle,final long formatterDispatch,final long openId){
        FlushFile flushFile = new FlushFile(handle, formatterDispatch, openId);
        if(DEBUG)System.out.println(flushFile);
        return flushFile;
    }

    private final static FlushMedia constructFlushMediaOp(final long handle,final long formatterDispatch){
        FlushMedia flushMedia = new FlushMedia(handle, formatterDispatch);
        if(DEBUG)System.out.println(flushMedia);
        return flushMedia;
    }

    private final static List constructListOp(final long handle,final long formatterDispatch,final long openId,final long listId,final long jpfmContentListHandle){
        List list = new List(handle, formatterDispatch, openId, listId, jpfmContentListHandle);
        if(DEBUG)System.out.println(list);
        return list;
    }

    private final static ListEnd constructListEndOp(final long handle,final long formatterDispatch,final long openId,final long listId){
        ListEnd listEnd = new ListEnd(handle, formatterDispatch, openId, listId);
        if(DEBUG)System.out.println(listEnd);
        return listEnd;
    }

    private final static MediaInfo constructMediaInfoOp(final long handle,final long formatterDispatch,final long openId){
        MediaInfo mediaInfo = new MediaInfo(handle, formatterDispatch, openId);
        if(DEBUG)System.out.println(mediaInfo);
        return mediaInfo;
    }

    private final static Move constructMoveOp(
            final long handle,
            final long formatterDispatch,
            final long sourceFileDescriptor,
            final long sourceParentFileDescriptor,
            final String sourceEndName,
            final String[] targetName,
            final boolean deleteSource,
            final /*pismo time*/long writeTime,
            final long newExisitingOpenId){
        Move move = new Move(
                handle,
                formatterDispatch,
                sourceFileDescriptor,
                sourceParentFileDescriptor,
                sourceEndName,
                targetName,
                deleteSource,
                toJavaTime(writeTime),
                newExisitingOpenId
        );
        if(DEBUG)System.out.println(move);
        return move;
    }
    

    private final static MoveReplace constructMoveReplaceOp(
            final long handle,
            final long formatterDispatch,
            final long sourceFileDescriptor,
            final long sourceParentFileDescriptor,
            final String sourceEndName,
            final long targetFileDescriptor,
            final long targetParentFileDescriptor,
            final String targetEndName,
            final boolean deleteSource,
            final /*pismo time*/long writeTime
            /*final long newExistingFileDescriptor*/){
        MoveReplace moveReplace = new MoveReplace(
                handle,
                formatterDispatch,
                sourceFileDescriptor,
                sourceParentFileDescriptor,
                sourceEndName,
                targetFileDescriptor,
                targetParentFileDescriptor,
                targetEndName,
                deleteSource,
                toJavaTime(writeTime)
                //fdb.build(newExistingFileDescriptor)
        );
        if(DEBUG)System.out.println(moveReplace);
        return moveReplace;
    }

    private final static Open constructOpenOp(
            final long handle,
            final long formatterDispatch,
            String[] name,
            final int fileType,
            final short createFlags,
            final /*pismo time*/long writeTime,
            final long newCreateOpenId,
            final int existingAccessLevel,
            final long newExistingOpenId
            ){
        if(name==null)name = new String[0];
        Open open = new Open(
            handle,
            formatterDispatch,
            name,
            fileType,
            flagbld.build(createFlags),
            toJavaTime(writeTime),
            newCreateOpenId,
            AccessLevel.get(existingAccessLevel),
            newExistingOpenId
        );
        if(DEBUG)System.out.println(open);
        return open;
    }


    private final static Read constructReadOp(final long handle,final long formatterDispatch,final long openId,final long fileOffset,final ByteBuffer buffer){
        //return new Read(handle, formatterDispatch, fdb.build(openId), fileOffset, buffer);
        return new Read(handle, formatterDispatch, openId, fileOffset, buffer);
    }

    private final static Read constructReadOpRO(final long handle,final long formatterDispatch,final long openId,final long fileOffset,final ByteBuffer buffer){
        //return new Read(true ,handle, formatterDispatch, fdb.build(openId), fileOffset, buffer);
        return new Read(handle, formatterDispatch, openId, fileOffset, buffer);
    }


    private final static Replace constructReplaceOp(
            final long handle,
            final long formatterDispatch,
            final long targetFileDescriptor,
            final long targetParentFileDescriptor,
            final String targetEndName,
            final short createFileFlags,
            final /*pismo time*/long writeTime,
            final long newCreateOpenId
        ){
        return new Replace(
                handle,
                formatterDispatch,
                targetFileDescriptor,
                targetParentFileDescriptor,
                targetEndName,
                flagbld.build(createFileFlags),
                toJavaTime(writeTime),
                newCreateOpenId);
    }

    private final static SetSize constructSetSizeOp(final long handle,final long formatterDispatch,final long openId,final long newFileSize){
        return new SetSize(handle, formatterDispatch, openId, newFileSize);
    }

    private final static Write constructWriteOp(final long handle,final long formatterDispatch,final long openId,final long fileOffset,final ByteBuffer buffer){
        return new Write(handle, formatterDispatch, openId, fileOffset, buffer);
    }


    final static native void addToList(final long handle,final long formatterDispatch,final FileAttributesProvider file,final long jpfmContentListHandle);

    final static native void completeCapacity(final long handle,final long formatterDispatch,final int pfmError,final long totalCapacity,final long availableCapacity);
    final static native void completeClose(final long handle,final long formatterDispatch,final int pfmError);
    final static native void completeControl(final long handle,final long formatterDispatch,final int pfmError,final int actualOutputSize);
    final static native void completeDelete(final long handle,final long formatterDispatch,final int pfmError);
    final static native void completeFlushFile(final long handle,final  long formatterDispatch,final int pfmError);
    final static native void completeFlushMedia(final long handle,final long formatterDispatch,final int pfmError,final int msecFlushDelay);
    final static native void completeList(final long listOpHandle,final long formatterDispatch,final int pfmError,final boolean noMore);
    final static native void completeListEnd(final long handle,final long formatterDispatch,final int pfmError,final long jpfmContentListHandle);
    final static native void completeMediaInfo(final long handle,final long formatterDispatch, final int pfmError,final Media media,final  String mediaLabel);
    final static native void completeMove(final long handle,final  long formatterDispatch,final int pfmError,final boolean existed,final FileAttributesProvider fileAttributesProvider,final FileDescriptor parentFileDescriptor,final String endName,final FileDescriptor fileDescriptor, int accessLevel, int controlFlags);
    final static native void completeMoveReplace(final long handle,final  long formatterDispatch,final  int pfmError);
    final static native void completeOpen(final long handle,final  long formatterDispatch,final int error,final boolean existed,final int accessLevel,final int controlFlag,final FileAttributesProvider attributesProvider,final FileDescriptor parentFileDescriptor,String endName,final FileDescriptor fileDescriptor);
    final static native void completeRead(final long handle,final  long formatterDispatch,final int jpfmError,final int actualRead);
    final static native void completeReplace(final long handle,final  long formatterDispatch,final int error,final FileAttributesProvider fileAttributesProvider,final FileDescriptor fileDescriptor, final int accessLevel, int controlFlags);
    final static native void completeSetSize(final long handle,final  long formatterDispatch,final int pfmError);
    final static native void completeWrite(final long handle, final long formatterDispatch,final int jpfmError,final int actualSize);

    //final static native void completeReadRO(final long handle,final  long readOnlyFormatterDispatch,final int jpfmError,final int actualRead);

    final static long toPismoCompatibleTime(final long nbtime){
        return (
                nbtime
                +
                11644473600000L//LL//U
            )*10000;
    }
    
    final static long toJavaTime(final long pismotime){
        return (
                (pismotime/10000)
                - 11644473600000L
        );
    }


    //final static native FileDescriptor newExistingOpenIdForMove(long setInPartialMode);

    //final static native FileDescriptor newCreateOpenIdForOpen(long setInPartialMode);
    //final static native FileDescriptor newExistingOpenIdForOpen(long setInPartialMode);
}
