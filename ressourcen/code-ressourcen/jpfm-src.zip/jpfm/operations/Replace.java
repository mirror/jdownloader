/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.Date;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.AccessLevel;
import jpfm.FileAttributesProvider;
import jpfm.FileControlFlag;
import jpfm.FileId;
import jpfm.FileFlags;
import jpfm.JPfmError;

/**
 * <u>Note : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileId<br/></u>
 * <br/>
 * <br/>
 * <b>Example : </b> <br/><br/>
 * PFM<br/>
 * <b>struct ReplaceOp</b>
 * <pre>
 * virtual PFM_INT64          PFM_CCALL NewCreateOpenId(void) = 0;
 * virtual PFM_INT64          PFM_CCALL TargetParentFileId(void) = 0;</pre>
 * <br/>
 * JPFM equivalent <br/>
 * <b>class jpfm.operations.Replace</b>
 * <pre>
 * public final FileId getNewCreateFileId()
 * public final FileId getTargetParentFileId()</pre>
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 *
 * The marshaller calls this function when processing a
 * replace request from the driver. This request is made when an
 * existing file is being replaced by a new file with the same name.
 * The replaced file name becomes deleted.<br/><br/>
 * The file being replaced has already been opened and is identified 
 * with the targetOpenId parameter.<br/><br/>
 * If the target file type is a folder and the formatter does not
 * support replace for folders then the formatter should return
 * pfmErrorInvalid. Formatters must support replace for files.<br/><br/>
 * If the target file type is a folder and the folder is not empty 
 * then the formatter should return pfmErrorNotEmpty.<br/><br/>
 * Formatters that support multiple names for a single file (hard links)
 * should use the targetParentFileId and targetEndName parameters to
 * identify which name is being replaced.<br/><br/>
 * The createFileFlags and writeTime parameters should be used to 
 * initialize the new file. The file type is always the same as the target.<br/><br/>
 * The newCreateOpenId and openAttribs parameters should be treated
 * the same as is described for the PfmFormatterOps::Open function
 * when a new file is created.<br/><br/>
 * @see jpfm.JPfmFileSystem#replace(jpfm.operations.Replace) 
 * @author Shashank Tulsyan
 */
public final class Replace extends FileSystemOperation {
//{
//   virtual PFM_INT64          PFM_CCALL TargetOpenId(void) = 0;
//   virtual PFM_INT64          PFM_CCALL TargetParentFileId(void) = 0;
//   virtual const PfmNamePart* PFM_CCALL TargetEndName(void) = 0;
//   virtual PFM_UINT8          PFM_CCALL CreateFileFlags(void) = 0;
//   virtual PFM_INT64          PFM_CCALL WriteTime(void) = 0;
//   virtual PFM_INT64          PFM_CCALL NewCreateOpenId(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError,const PfmOpenAttribs* openAttribs,PfmFormatterSerializeOpen* serializeOpen) = 0;
//};/*package private*/


    private final long handle;
    private final long formatterDispatch;
    private final long targetFileId;
    private final long targetParentFileId;
    private final String targetEndName;
    private final FileFlags createFileFlags;
    private final long writeTime;

    private final AtomicBoolean completed = new AtomicBoolean(false);
    private final long newCreateOpenId;

    /*package private*/ Replace(
            final long handle,
            final long formatterDispatch,
            final long targetFileId,
            final long targetParentFileId,
            final String targetEndName,
            final FileFlags createFileFlags,
            final long writeTime,
            final long newCreateOpenId) {
        this.handle = handle;
        this.formatterDispatch = formatterDispatch;
        this.targetFileId = targetFileId;
        this.targetParentFileId = targetParentFileId;
        this.targetEndName = targetEndName;
        this.createFileFlags = createFileFlags;
        this.writeTime = writeTime;
        this.newCreateOpenId = newCreateOpenId;
    }

    public FileId getNewCreateFileId() {
        return FILEID_BUILDER.constructFileId(newCreateOpenId);
    }

    public final FileFlags getCreateFileFlags() {
        return createFileFlags;
    }

    public final String getTargetEndName() {
        return targetEndName;
    }

    public final FileId getTargetFileId() {
        return FILEID_BUILDER.constructFileId(targetFileId);
    }

    public final FileId getTargetParentFileId() {
        return FILEID_BUILDER.constructFileId(targetParentFileId);
    }

    public final boolean isCompleted() {
        return completed.get();
    }


    public final long getWriteTime() {
        return writeTime;
    }

    public final Date getWriteTimeAsDate() {
        return new Date( writeTime );
    }


//   virtual void PFM_CCALL Complete(
    //int pfmError,const PfmOpenAttribs* openAttribs,
    //PfmFormatterSerializeOpen* serializeOpen) = 0;

    public final void complete(
            final JPfmError error,
            final FileAttributesProvider fileAttributesProvider,
            final AccessLevel accessLevel,
            final FileControlFlag controlFlag) throws IllegalStateException,IllegalArgumentException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeReplace(
                handle,
                formatterDispatch,
                error==null?JPfmError.FAILED.getErrorCode():error.getErrorCode(),
                fileAttributesProvider,
                fileAttributesProvider.getFileDescriptor(),
                accessLevel==null?0:accessLevel.getAccessLevel(),
                controlFlag==null?0:controlFlag.getControlFlag()
        );
    }


    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    

    public final void handleUnexpectedCompletion(Exception exception){
        if(!this.completed.get()){
            this.complete(JPfmError.FAILED,null,null,null);
        }
    }
    
    @Override
    public String toString() {
        return "Replace{targetFileId"+ targetFileId+" targetEndName" +targetEndName + "}";
    }
}
