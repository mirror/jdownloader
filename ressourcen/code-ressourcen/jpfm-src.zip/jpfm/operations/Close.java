/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import jpfm.FileDescriptor;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.FileId;
import jpfm.JPfmError;
import jpfm.JPfmFileSystem;

/**
 * Unlike native formatters handling each close request is not required.
 * When all instances of a file have been closed, close ({@link JPfmFileSystem#close(jpfm.operations.Close) } ) is invoked once.
 * After successful closing of the file, {@link Close#complete(jpfm.JPfmError) } must be invoked
 * (not doing this will result in leakage of kernel memory, this might also
 * cause trouble while unmounting the formatter (in such cases JPfmFileSystem would just
 * forcefully complete pending requests.) )
 * <br/>
 * Non blocking nature of Close is not really essential as close operations
 * in pratice do not take time to execute. For this reason {@link Close} should not
 * be passed beyond the filesystem. <br/>
 * For example : In jpfm.JPfmReadable close has been represented as :
 * <pre>public void close()</pre>
 * There is no point in passing {@link JPfmFileSystem#close(jpfm.operations.Close) }
 * object since it only would increase the risk of {@link AlreadyCompleteException }
 * <br/><br/>
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileDescriptor<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * @see AlreadyCompleteException
 * @see #complete(jpfm.JPfmError)
 * @see jpfm.JPfmReadOnlyFileSystem#close(jpfm.FileDescriptor)
 * @see jpfm.JPfmFileSystem#close(jpfm.operations.Close) 
 * @author Shashank Tulsyan
 */
public final class Close extends FileSystemOperation {
//struct PfmMarshallerCloseOp
//{
//   virtual PFM_INT64 PFM_CCALL OpenId(void) = 0;
//   virtual PFM_INT64 PFM_CCALL OpenSequence(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError) = 0;
//};

    private final long handle; 
    private final long formatterDispatch;

    private final FileDescriptor fileDescriptor; //4
    private final AtomicBoolean completed = new AtomicBoolean(false); //4 + 16

    /*package private*/ Close(final long handle,final long formatterDispatch,final FileDescriptor fileDescriptor) {
        this.handle = handle;
        this.formatterDispatch = formatterDispatch;
        this.fileDescriptor = fileDescriptor;
    }

    public final FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    public final boolean isCompleted() {
        return completed.get();
    }


    public final void complete(final JPfmError pfmError)throws IllegalStateException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeClose(handle, formatterDispatch,pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode());
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    public final void handleUnexpectedCompletion(final Exception exception){
        if(!this.completed.get()){
            this.complete(JPfmError.FAILED);
        }
    }

    
    @Override
    public String toString() {
        return "Close{"+ getFileDescriptor() + "}";
    }
    
}
