/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   FormatterListener.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.util.LinkedList;

/**
 *
 * @author Shashank Tulsyan
 */
public final class FormatterListener {

    private LinkedList<UnderprivilegedFormatterListener> listeners = null;
    private boolean exitOnUnmount;
    private static boolean toStdOut = true;
    private final JPfmMount mount;

    protected FormatterListener(boolean exitOnUnmount, final JPfmMount mount) {
        this.exitOnUnmount = exitOnUnmount;
        this.mount = mount;
    }

    /*package private*/ final JPfmMount getMount() {
        return mount;
    }
    
    public final void eventOccurred(final FormatterEvent event) {
        if (event == null) {
            System.out.println("event shold not be null");
            return;
        }

        if (toStdOut) {
            System.out.print("Formatter Event {Mount = " + mount +"}");
            System.out.println(event);
        }

        if (exitOnUnmount) {
            if (event.getEventType() == FormatterEvent.EVENT.DETACHED) {
                if (toStdOut) {
                    System.out.println("Exit on unmount option was enabled, exiting...");
                    System.exit(0);
                }
            }
        }

        //this call is from a native method, we do not want any trouble
        //propagating to native side, neither do we want to make
        //the native code complex trying to figure out java exceptions
        if (listeners == null) {
            return;
        }
        for (final UnderprivilegedFormatterListener listener : listeners) {
            try {
                Thread t = new Thread() {

                    @Override
                    public void run() {
                        listener.eventOccurred(event);
                    }
                };
                t.start();
            } catch (Exception any) {
            }
        }
    }

    public final synchronized void addListener(UnderprivilegedFormatterListener listener) {
        if (listener == null) {
            return;
        }
        if (listeners == null) {
            listeners = new LinkedList<UnderprivilegedFormatterListener>();
        }
        listeners.add(listener);
    }

    public final synchronized void removeListener(UnderprivilegedFormatterListener listener) {
        if (listener == null) {
            return;
        }
        listeners.remove(listener);
        if (listeners.size() == 0) {
            listeners = null;
        }
    }

    /*package private*/ final static void setToStdOut(boolean toStandardOut) {
        toStdOut = toStandardOut;
    }
}
