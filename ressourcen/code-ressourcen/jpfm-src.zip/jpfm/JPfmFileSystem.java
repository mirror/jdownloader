/*
 *  Copyright 2010 Shashank Tulsyan
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

import jpfm.annotations.NonBlocking;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentLinkedQueue;
import jpfm.annotations.MightBeBlocking;
import jpfm.operations.*;

/**
 * JPfmFileSystem is a java wrapper for Pismo File Mount which is a
 * operating system extension that enables access and modification to
 * user and program data through the file system interface of the operating system
 * <br/>
 * JPfmFileSystem should be used when all filesystem functions are to be implemented in non-blocking fashion,
 * and/or writing and other forms of modifications are to allowed in the virtual filesystem.
 * Otherwise {@link JPfmReadOnlyFileSystem} can be used.
 * There are 16 file system operations supported.<br/>
 * Each operation method can throw exception, but it would be wise to handle them, as it will be better for performance.
 * There are various examples available. Most filesystems are provided in jpfm-fs.jar in jpfm.fs package.
 * <br/>
 * <br/>
 * <u>Note</u> : All filesystem operations provide a FileDescriptor which has to be used to
 * locate the correct file. FileDescriptors can be very easily saved in collections, as it implements Comparable.
 * Also note that the FileDescriptor passed is not equal to the one which you have in the corresponding FileAttributesProvider.
 * To find correct FileAttributesProvider corresponding to a given FileDescriptor
 * {@link FileDescriptor#implies(jpfm.FileDescriptor) } method should be used.
 * That is to say {@link FileAttributesProvider#getFileDescriptor() } is not equal to
 * fileDescriptor in {@link FileSystemOperation}.
 * These should never be interchanged. The best thing to do would be to declare
 * FileDescriptor field in your FileAttributesProvider class as final. And always return it
 * on calls to {@link FileAttributesProvider#getFileDescriptor() }.
 * <br/>
 * <br/>
 * <br/>
 * <br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ } <br/><br/>
 * Pismo File Mount is a operating system extension that
 * enables access and modification to user and program data through
 * the file system interface of the operating system. By exposing
 * data through the file system, problems can elegantly and
 * efficiently be solved that otherwise require less flexible
 * and more resource intensive solutions.
 * <br/>
 * Pismo File Mount works by enabling user mode file systems to
 * present file data through a virtual mount point on an existing local,
 * remote, or removable drive. The virtual mount point is created in
 * place on top of an existing file.
 * Typically the mount point file is an archive or data file whose data is
 * being exposed by the user mode file system,
 * but purely virtual file systems are also possible.
 * While mounted, the mount point file appears as a folder
 * whose contents are served by the user mode file system.
 * <br/>
 *
 * @see FileAttributesProvider
 * @see FileDescriptor
 * @see JPfmReadOnlyFileSystem
 * @author Shashank Tulsyan
 */
@MightBeBlocking
public abstract class JPfmFileSystem extends JPfmReadOnlyFileSystem {
    private final VolumeFlags volumeFlags;
    private final Object lock = new Object();
    private final LinkedList<jpfm.operations.List> pendingLists = new LinkedList<List>();

    protected JPfmFileSystem(final VolumeFlags volumeFlags){
        super(new ConcurrentLinkedQueue<FileSystemOperation>());
        // todo : the thread which handles pending requests should be
        // stopped when volume has been unmounted from everywhere
        this.volumeFlags = volumeFlags;
        
    }

    public final VolumeFlags getVolumeFlags() {
        if(volumeFlags==null)return new VolumeFlags.Builder().build();
        return volumeFlags;
    }

    //virtual void PFM_CCALL SerializeOpen(PFM_INT64 openId,PFM_INT64* openSequence) = 0;
    private final long serializeOpen1(final FileId fileId)throws IncorrectImplementationException{
        FileAttributesProvider fap = getFileAttributes(fileId);
        if(fap==null){
            IncorrectImplementationException tothrow = new IncorrectImplementationException("Open succeeded and so getFileAttributes(fd) is not expected to be null. "+fileId.toString());
            throw tothrow;
        }
        try{    
            return fap.getFileDescriptor().
                getAndIncrementOpenSequence();//<<atomic operation
        }
        catch(Exception any){
            IncorrectImplementationException tothrow = new IncorrectImplementationException("Open succeeded and so getFileAttributes(fd).getFileDescriptor() is not expected to throw exception.", any );
            tothrow.setStackTrace(any.getStackTrace());
            throw tothrow;
        }
    }

    /**
     * used from native side
     * all calls originate from here
     * this is called only by one thread (by more if same fs mounted using more than one JPfmMount instance )
     * no synchronization required even on pendingoperations
     * as it is also thread safe
     */
    @NonBlocking
    private final void addOperation(
            final FileSystemOperation fileSystemOperation,
            final FormatterListener formatterListener //unique for every mount, if not what ?
        ){
        //System.out.print("addOperation : ");
        //System.out.println(fileSystemOperation);
        if(!formatterListener.getMount().wasMountedSuccessfully){
            formatterListener.getMount().wasMountedSuccessfully = true;
            formatterListener.eventOccurred(new FormatterEvent(FormatterEvent.EVENT.SUCCESSFULLY_MOUNTED, " "));
        }
        pendingOperations.add(fileSystemOperation);
        try{
            //TODO :: handle in separate thread, so that it does not
            //matter how many instances are mounted and are calling
            //all calls will automatically get alligned and it
            //would appear comming from 1 thread.
            //use ConcurrentLinkedQueue
            //and Object.lock and notify
            dispatch(fileSystemOperation);
        }catch(AlreadyCompleteException alreadyCompleteException){
            formatterListener.eventOccurred(
                    new FormatterEvent(
                        FormatterEvent.EVENT.INCORRECT_IMPLEMENTATION,
                        "complete method was invoked more than once. There was no harm done, but this error should be fixed",
                        alreadyCompleteException));
        }catch(Exception any){
            try{
                fileSystemOperation.handleUnexpectedCompletion(any);
                formatterListener.eventOccurred(new FormatterEvent(FormatterEvent.EVENT.INCORRECT_IMPLEMENTATION,"Exception occurred, and handled partially. Fix this to prevent kernel memory leaks.",any));
            }catch(Exception exception){//cannot happen
                formatterListener.eventOccurred(new FormatterEvent(FormatterEvent.EVENT.INCORRECT_IMPLEMENTATION," FileSystemOpertion unexpected completion handler incorrectly implemented",exception));
            }
        }

        // inherited from JPfmReadOnlyFileSystem
        // this can be used to check which file system operations
        // have been pending since a long time
        incompleteOperations.add(fileSystemOperation);
        synchronized(lock){
            lock.notifyAll();
        }
    }



    private final void dispatch(final FileSystemOperation fileSystemOperation) throws Exception{
        if(fileSystemOperation instanceof Capacity){
            capacity((Capacity)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof Close){
            Close closeop = (Close)fileSystemOperation;
            //System.out.println(closeop);
            //impl here itself
            FileDescriptor closeOpFDesc = closeop.getFileDescriptor();
            FileDescriptor myOpenSequence = getFileAttributes(closeOpFDesc.getFileId()).getFileDescriptor();
            //If the openSequence parameter is less than the openSequence of
            //the file then the file is still makrOpen. The formatter should perform no action.

            //If the openSequence parameter is greater than or equal to the openSequence
            //of the file then the driver no longer has any references to the file.
            //boolean canClose = closeOp->OpenSequence() >= myOpenSequence; // << non atomic in nature

            //cannot perform this using CAS
            //using synchronizes instead to prevent someone from changing
            synchronized(myOpenSequence.getAtomicOpenSequence()){
               boolean canClose =
                      closeOpFDesc.getAtomicOpenSequence().get() >= myOpenSequence.getAtomicOpenSequence().get();
               if(canClose){
                   close(closeop);
               }else {
                   closeop.complete(JPfmError.SUCCESS);
               }
            }
            return;
        }
        if(fileSystemOperation instanceof Control){
            control((Control)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof Delete){
            delete((Delete)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof FlushFile){
            flushFile((FlushFile)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof FlushMedia){
            flushMedia((FlushMedia)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof List){
            synchronized(pendingLists){
                pendingLists.add((List)fileSystemOperation);
            }
            list((List)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof ListEnd){
            listEnd((ListEnd)fileSystemOperation);
            System.gc();
            return;
        }
        if(fileSystemOperation instanceof MediaInfo){
            mediaInfo((MediaInfo)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof Move){
            move((Move)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof MoveReplace){
            moveReplace((MoveReplace)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof Open){
            open((Open)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof Read){
            read((Read)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof Replace){
            replace((Replace)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof SetSize){
            setSize((SetSize)fileSystemOperation);
            return;
        }
        if(fileSystemOperation instanceof Write){
            write((Write)fileSystemOperation);
            return;
        }
        else{
            throw new Exception(
                    "It seems you are using a newer version of the native library. " +
                        "The FileSystemOperation send by the native side could not be recognized : "
                        +fileSystemOperation.getClass()+ " { " + fileSystemOperation.toString()  + " }");
        }
    }

    protected abstract void capacity(final Capacity capacity)throws Exception;
    protected abstract void close(final Close close)throws Exception;
    protected abstract void control(final Control control)throws Exception;
    protected abstract void delete(final Delete delete)throws Exception;
    protected abstract void flushFile(final FlushFile flushFile)throws Exception;
    protected abstract void flushMedia(final FlushMedia flushMedia)throws Exception;
    protected abstract void list(final List list)throws Exception;
    private final void listEnd(final ListEnd listEnd)throws Exception{
        synchronized(pendingLists){
            Iterator<List> it = pendingLists.iterator();
            List nextList;
            while(it.hasNext()){
                nextList = it.next();
                if(nextList.getListId() == listEnd.getListId()){
                    nextList.fillWithContentListHandle(listEnd);
                    it.remove();
                    listEnd.complete(JPfmError.SUCCESS);
                    return;
                }
            }
        }
        //will not happen
        throw new Exception("There is a possiblility of memory leak : could not find list of the given listId="+listEnd.getListId());
    }
    protected abstract void mediaInfo(final MediaInfo mediaInfo)throws Exception;
    protected abstract void move(final Move move)throws Exception;
    protected abstract void moveReplace(final MoveReplace moveReplace)throws Exception;
    protected abstract void open(final Open open)throws Exception;
    protected abstract void read(final Read read)throws Exception;
    protected abstract void replace(final Replace replace )throws Exception;
    protected abstract void setSize(final SetSize setSize)throws Exception;
    protected abstract void write(final Write write)throws Exception;


    private final static String BLOCKING_METHODS_NOT_SUPPORTED = "Blocking filesystem methods not supported in non blocking filesystem.";

// <editor-fold defaultstate="collapsed" desc="Methods Inherited from readonly filesystem">
    @Deprecated
    @Override
    protected final FileAttributesProvider getRootAttributes() {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }

    @Deprecated
    @Override
    protected final FileAttributesProvider open(String[] filePath) {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }

    @Deprecated
    @Override
    protected void open(FileAttributesProvider descriptor) {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }

    @Deprecated
    @Override
    protected final DirectoryStream list(FileId folderToList) {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }

    @Deprecated
    @Override
    protected final int read(FileId file, long offset, ByteBuffer directByteBuffer) {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }

    @Deprecated
    @Override
    protected final void close(FileId file) {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }

    @Deprecated
    @Override
    protected final void delete(FileId fileToDelete) {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }

    @Deprecated
    @Override
    protected final long capacity() {
        throw new UnsupportedOperationException(BLOCKING_METHODS_NOT_SUPPORTED);
    }// </editor-fold>

    private static final class ListStateMaintainer {
        private final List list;

        private ListStateMaintainer(final List list) {
            this.list = list;
        }

        public final List getList() {
            return list;
        }
    }
    
    private static final class RemoveCompletedOps extends Thread {
        private final JPfmFileSystem parent;

        public RemoveCompletedOps(JPfmFileSystem parent) {
            super("IncompleteOperationsListManager");
            this.parent = parent;
        }

        @Override
        public void run() {
            INFINITE_LOOP:
            for(;parent.getMountCount()>0;){
                Iterator<FileSystemOperation> it = parent.incompleteOperations.iterator();
                FileSystemOperation next;

                while(it.hasNext()){
                    next = it.next();
                    if(next.isCompleted()){
                        it.remove();
                    }
                }


                synchronized(parent.lock){
                    try{
                        while(true)
                            parent.lock.wait();
                    }catch(InterruptedException any){
                        //implies new element added
                    }
                }
            }
        }
    }

}
