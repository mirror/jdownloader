/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   FileDescriptor.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.util.Comparator;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import jpfm.operations.FileSystemOperation;
import jpfm.operations.NativeInterfaceMethods;

/**
 * Used by native code.
 * </br>
 * Files are generally identified by path strings, such as c:\videos\somevideo.avi ;
 * But this is not the way we identify files in Pfm. We use numbers instead. In JPfm these numbers
 * are abstracted by using FileDescriptor instead.
 * The reason to use numbers to represent files is pfm is that path of file can change, filename can change,
 * the location can change.
 * So to keep the identidity unique and constant throughout it's lifetime, the file is
 * assigned a number by filesystem native driver. This number and the manipulation functions
 * required to keep it meaningful for the filesystem driver are wrapped around
 * a java class called FileDescriptor.</br>
 * Implementors need not worry themselves about how it works, they just need to create
 * an instance of FileDescriptor for each file in their virtual filesystem, and return
 * this same object everytime.
 * </br>
 * To check if a given {@link FileAttributesProvider} is same
 * as the one represented by this use {@link FileDescriptor#implies(jpfm.FileDescriptor) }
 * <br/><br/>
 * FileDescriptor is a wrapper for pfm openId and openSequence. It is also
 * handles serialize makrOpen operation.
 * <br/><br/><br/>
 * All filesystem operations provide a FileDescriptor which has to be used to
 * locate the correct file. FileDescriptors can be very easily saved in collections,
 * as it implements Comparable.
 * Also note that the FileDescriptor passed is not equal to the one which you have
 * in the corresponding FileAttributesProvider.
 * To find correct FileAttributesProvider corresponding to a given FileDescriptor
 * {@link FileDescriptor#implies(jpfm.FileDescriptor) } method should be used.
 * That is to say {@link FileAttributesProvider#getFileDescriptor() } is not equal to
 * fileDescriptor in {@link FileSystemOperation}.
 * These should never be interchanged. The best thing to do would be to declare
 * FileDescriptor field in your FileAttributesProvider class as final. And always return it
 * on calls to {@link FileAttributesProvider#getFileDescriptor() }.
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * <b>OpenId and OpenSequence<b/><br/>
 * OpenId and openSequence are integral parts of the PFM protocol.
 * The openId is the mechanism used to identify makrOpen files and folders.
 * OpenSequence is maintained by the driver and used by the formatter
 * to identify when the last reference to an makrOpen file or folder has closed.
 * OpenIds are not file IDs. In particular the openId values for new
 * files is assigned by the driver, where file IDs are assigned
 * by the formatter.
 * <br/><br/>
 * The use of openIds and openSequence allows PFM to provide atomicity guarantees
 * during file system name space changes and share mode checks. Without this
 * mechanism the driver would have to make assumptions about the formatters
 * name space, and hold locks while waiting for the formatter to process many requests.
 * @author Shashank Tulsyan
 */
public class FileDescriptor implements Comparable<FileDescriptor>, Comparator<FileDescriptor> {
    static {
        NativeInterfaceMethods.setBuilder(Builder.SINGLETON);
        FileSystemOperation.setFDModifier(FDModifier.SINGLETON);
    }
    
    protected static final long INVALID_OPEN_ID = 0;
    /**
     * Values set by native code using
     * private methods setOpenId and setOpenSequence
     */
    private volatile long openId = INVALID_OPEN_ID; /*need not be volatile if not used in hashCode. this really doesnot make any performance difference*/
    private long listHandle = 0;//used only in jpfmreadonlyfilesystem
    private final AtomicLong openSequence = new AtomicLong(1);
    //private long openSequence = 1;
    private long serializeOpenPointer = 0;
    private final AtomicBoolean open = new AtomicBoolean(false);

    public static final Comparator<FileDescriptor> COMPARATOR = new FileDescriptor();

    //total space occupied in making
    //an instance = 8 + 8+ 8 + 8 + 8 = 40 = 40 bytes (in multiple of 8)
    //total space occupied in making when openSequence is atomic long
    //an instance = 8 + 8+ (4+8+8) + 8 + 8 = 52 = 56 bytes (in multiple of 8)
    /**
     * Use this to create new FileDescriptor and always return
     * the same FileDescriptor for a given file throughtout it's lifetime
     */
    public FileDescriptor() {
    }

    /*package private*/ private FileDescriptor(long openId){
        this.openId = openId;
    }

    private final long getOpenId(long newId) {
        if (openId == INVALID_OPEN_ID) {
            this.openId = newId;
            if (openSequence.get() == 0) {
                openSequence.set(1);
            }
        }
        return openId;
    }

    private final long getOpenSequence() {
        return openSequence.get();
    }

    final /*package private*/ void opened(){
        // no need to check like close
        //this can always happen
        //because more than one instance of a file can be open
        open.set(true);
    }

    final /*package private*/ void closed(){
        if(!open.compareAndSet(/*expect*/true,/*update*/false)){
            //unexpected behavious, theoretically should never happen
            System.out.println("file already close");
        }
    }

    public final boolean isOpen(){
        return open.get();
    }

    /**
     * called from native library jpfmreadonlyformatterdispatch.cpp : line ~ 948
     * in function void PFM_CCALL JPfmFormatterSerializeOpen::SerializeOpen.
     * package private because JPfmFileSystem needs access.
     * although name is get and add, it adds and returns.
     */
    final /*package private*/ long getAndIncrementOpenSequence() {
        return openSequence.addAndGet(1);
    }

    /*package private*/ final AtomicLong getAtomicOpenSequence() {
        //openSequence++;
        return openSequence;
    }

    private final void setOpenId(long openId) {
        this.openId = openId;
    }

    private long getListHandle() {
        return listHandle;
    }

    private void setListHandle(long listHandle) {
        this.listHandle = listHandle;
    }

    private long getSerializeOpenPointer() {
        return serializeOpenPointer;
    }

    private void setSerializeOpenPointer(long serializeOpenPointer) {
        synchronized(openSequence) { // this is called only once in the lifetime of a FileDescriptor, so it does not affect performance
            // using openSequence instead of locking on this
            this.serializeOpenPointer = serializeOpenPointer;
        }
    }

    /**
     * Wraps the openId of this filedescriptor around an nonmutable FileId instance.
     * You wouldn't be needing to use this function in general cases.
     * @return instance of a nonmutable FileId instance wrapping openId of this
     */
    public final FileId getFileId(){
        return new FileId(openId);
    }

    /**
     * A FileDescriptor is invalid until the native code
     * associates corrent data with it.
     * @return true if data in this FileDescriptor has not been
     * initialized by the native code
     */
    public final boolean isValid() {
        return openId > 0 || openId != INVALID_OPEN_ID;
    }

    /*@Override
    public final boolean equals(Object obj) {
    if(!(obj instanceof FileDescriptor))return false;
    return
    this.openId ==((FileDescriptor)obj).openId
    && this.listHandle==((FileDescriptor)obj).listHandle
    && this.serializeOpenPointer==((FileDescriptor)obj).serializeOpenPointer;
    }*/
    /**
     * Is similar to {@link Object#equals(java.lang.Object) } .
     * This method should be used to check if the FileDescriptor
     * send by  {@link JPfmReadOnlyFormatter#reOpen(jpfm.FileDescriptor) } ,
     * {@link JPfmReadOnlyFormatter#list(jpfm.FileDescriptor)  } ,
     * {@link JPfmReadOnlyFormatter#read(jpfm.FileDescriptor, long, java.nio.ByteBuffer) } and
     * {@link JPfmReadOnlyFormatter#close(jpfm.FileDescriptor)  }
     *   is equivalent to(same as) the one obtained by
     *   {@link FileAttributesProvider#getFileDescriptor() }
     * @param fileDescriptor The FileDescriptor to compare
     * @return if this FileDescriptor and the one passed as argument indicate/imply to the same file
     */
    public final boolean implies(FileDescriptor fileDescriptor) {
        if (fileDescriptor.openId == INVALID_OPEN_ID) {
            throw new IllegalArgumentException(
            /*System.out.println(*/"Attempting to check filedescriptor with INVALID_OPEN_ID");
            //System.out.println("Native code should have reported even before invoking this");
            // TODO : throw illegal argument exception
            //return false;
        }
        return this.openId == fileDescriptor.openId;
    }

    public final boolean implies(FileId fileId) {
        if (fileId.getOpenId() == INVALID_OPEN_ID) {
            throw new IllegalArgumentException(
            /*System.out.println(*/"Attempting to check filedescriptor with INVALID_OPEN_ID");
            //System.out.println("Native code should have reported even before invoking this");
            // TODO : throw illegal argument exception
            //return false;
        }
        return this.openId == fileId.getOpenId();
    }

    public final void set(FileId fileId){
        if(!fileId.isValid())
            throw new IllegalArgumentException("Trying to set file id as invalid. This is a priveledged task");
        this.openId = fileId.getOpenId();
    }

    protected final void setInvalid(){
        this.openId = 0;
    }


    @Override
    public String toString() {
        //return "FileDescriptor{OpenId=" + openId + " Opensequence=" + openSequence + "}";
        return "FileDescriptor{OpenId=" + openId + " Opensequence=" + openSequence +"}";
    }

    /*package private*/ static final String makeFileDescriptorString(long openId){
        if(openId==0)return "";
        return " FileDescriptor{OpenId=" + openId + " Opensequence=0}";
    }

    // to implement custom serializeopenppinter is a very bad idea
    // the message below was never observed, so it means we implemented correctly
    // should be used only for debugging
    /*
    @Override
    protected void finalize() throws Throwable {
        if (serializeOpenPointer != 0) {
            System.out.println("finalizing serialize = " + serializeOpenPointer);
            deleteSerializePointer(serializeOpenPointer);
        }
        super.finalize();
    }*/

    private native int deleteSerializePointer(long serializeOpenPointer);

    /**
     * Included for allowing quick search and sort.
     * Can be used with java collections api.
     */
    public int compareTo(FileDescriptor o) {
        return ((int) (this.openId - o.openId));
    }

    /**
     * Included for allowing quick search and sort.
     * Can be used with java collections api.
     */
    public int compare(FileDescriptor o1, FileDescriptor o2) {
        return o1.compareTo(o2);
    }
    /**
     * Included for allowing quick search and sort.
     * Can be used with java collections api.
     * Use this instance of Comparator to make things simple
     */
    public static final Comparator<FileDescriptor> getComparator() {
        return COMPARATOR;
    }


    @Override
    public final int hashCode() {
        if(openId==0)
            return super.hashCode();
        return (int)openId;
    }

    @Override
    public final boolean equals(Object obj) {
        if(!(obj instanceof FileDescriptor ))return false;
        if(this.openId==0)
            return super.equals(obj);
        return this.implies((FileDescriptor)obj)
                && this.serializeOpenPointer == ((FileDescriptor)obj).serializeOpenPointer;
    }

    public static final class Builder {
        private static final Builder SINGLETON = new Builder();
        private Builder(){};
        public final FileDescriptor build(final long openId) {
            FileDescriptor fileDescriptor = new FileDescriptor();
            fileDescriptor.openId = openId;
            return fileDescriptor;
        }
    }

    public static final class FDModifier{
        private static final FDModifier SINGLETON = new FDModifier();
        private FDModifier(){}
        public final long getAndIncrementOpenSequence(FileDescriptor fd){
            return fd.getAndIncrementOpenSequence();
        }
    }
}
