/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   JPfmReadOnlyFileSystem.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import jpfm.annotations.NonBlocking;
import jpfm.annotations.Blocking;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import jpfm.annotations.MightBeBlocking;
import jpfm.operations.FileSystemOperation;
import jpfm.operations.Read;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;
//import jpfm.volume.AbstractVolume;

/**
 * JPfmReadOnlyFileSystem is a quick way to implement readonly
 * virutal filesystems in java. JPfmReadOnlyFileSystem , {@link jpfm.fs.SimpleReadOnlyFileSystem }
 * or classes extending any of these can be used to quickly make
 * readonly virtual filesystems in java
 *<br/>
 *<br/>
 * This is semiconcurrent, that is
 * All filesystem functions are
 * implemented as blocking in nature, with exception to read.
 * <br/><br/>
 * <u>Some advice :</u><ul>
 * <li>All JPfmReadOnlyFileSystem functions (with exception to {@link #read(jpfm.operations.Read) } )
 * are intrinsically blocking in nature. That is, there is no way to implement them in NonBlocking fashion.
 * Therefore {@link #open(filePath)} , {@link #getFileAttributes(null) },
 * {@link #close(jpfm.FileDescriptor) } , {@link #capacity() },
 * {@link #delete(jpfm.FileDescriptor) } , {@link #getRootAttributes() } and
 * {@link #list(jpfm.FileDescriptor) }  should be implemented in such a
 * way that it does not take much time to execute,
 * because the client application may be in <b>Not Responding</b> state during execution of these functions.
 * <li><u>Read requests (that is {@link #read(jpfm.operations.Read)  } )</u><br/>
 * If the implementor feels, might take some time for the request to be satisifed,
 * he should handle it in a separate thread or do it in a non-blocking java-nio fashion.
 * Implementing read in blocking fashion
 * might risk locking the client application in <b>Not Responding</b> state.
 * See {@link java.nio.channels.AsynchronousFileChannel } and
 * {@link neembuu.vfs.test.ThrottledRealFile } for inspiration.
 * <li>It would be good idea to shift to {@link JPfmFileSystem }
 * if non-blocking nature is required for all filesystem functions. 
 * JPfmFileSystem provides all pismo file mount features.
 * <li>Cases in which you should use {@link JPfmFileSystem } would be
 * for example : FTPFileSystem . See {@link JPfmFileSystem#list(jpfm.operations.List) }
 * for exact reason why an FTPFileSystem would be implemented using non blocking list
 * implementation.
 * </ul>
 * <br/><br/>
 * <u>JPfm annotations</u>
 * Keep an eye on the type of annotation on methods, it is one of :
 * <ul>
 * <li> {@link jpfm.annotations.NonBlocking}
 * <li> {@link jpfm.annotations.Blocking}
 * <li> {@link jpfm.annotations.MightBeBlocking}
 * </ul>
 * Try to annotate your functions, and also note the annotation made of JPfm library functions,
 * as it will keep you consious why a method has been implemented as blocking, what are assumptions made,
 * why it must be implemented in non blocking fashion, when it is safe to
 * ignore .... so on so forth.
 * @see #read(jpfm.operations.Read)
 * @see JPfmFileSystem
 * @author Shashank Tulsyan
 */
@Blocking(getReasonWhyItDoesNotMatter="Although functions are intrinsically blocking in nature, read function can be implemented as non blocking")
public abstract class JPfmReadOnlyFileSystem {

    
    /**
     * Returned in legacy {@link #read(jpfm.FileDescriptor, long, java.nio.ByteBuffer) }
     * to indicate that the file was not found and thus could not be read
     * @deprecated blocking read function is unsafe and can put
     * the system file explorer in a <b>Not Responding</b> state.
     */
    @Deprecated
    public static final int READ_FILE_NOT_FOUND  = -2; 
    /**
     * Returned in legacy {@link #read(jpfm.FileDescriptor, long, java.nio.ByteBuffer) }
     * to indicate that the end of file was reached while reading.
     * @deprecated blocking read function is unsafe and can put
     * the system file explorer in a <b>Not Responding</b> state.
     */
    @Deprecated
    public static final int READ_END_OF_FILE  = -1;

    private ReadDispatchThread readDispatchThread ;
    /*package private*/ final ConcurrentLinkedQueue<FileSystemOperation> pendingOperations;
    // if monitor snatched, it means that new fs op is queue
    private final Object lock = new Object();
    /**
     * This is used to keep track of readrequests that have not been satisfied (or completed) yet.
     * These requests might need to be forcefully completed to avoid the operating system
     * filesystem explorer (example : windows explorer, nautilius ) from going into not responding state.
     * Implementors of JPfmReadOnlyFileSystem may use
     */
    protected final ConcurrentLinkedQueue<FileSystemOperation> incompleteOperations = new ConcurrentLinkedQueue<FileSystemOperation>();
    /*package private*/ final MountStateListener mountStateListener = new MountStateListener(this);
    //protected static Read.ForceComplete READ_FORCE_COMPLETER = null;
    private final ConcurrentLinkedQueue<FileSystemMountStateListener> mountStateListeners = new ConcurrentLinkedQueue<FileSystemMountStateListener>();
    private final AtomicInteger mountCount = new AtomicInteger(0);
    /**
     * Used internally. Implementors need not bother
     * themselves with trying to understanding this .
     */
    /*public static final void setReadForceComplete(Read.ForceComplete forceCompleteInst){
        if(forceCompleteInst==null )throw new IllegalArgumentException("Trying to initialize Read.ForceComplete with null");
        READ_FORCE_COMPLETER = forceCompleteInst;
    }*/

    /*protected static final Read.ForceComplete getForceCompleteOnRead(){
        return READ_FORCE_COMPLETER;
    }*/

    public JPfmReadOnlyFileSystem() {
        //readDispatchThread = new ReadDispatchThread(this);
        pendingOperations = new ConcurrentLinkedQueue<FileSystemOperation>();
        //readDispatchThread.start(); call from mount state listener instead
    }

    /*package private*/JPfmReadOnlyFileSystem(final ConcurrentLinkedQueue<FileSystemOperation> pendingReadOperations){
        //writableFS has overtaken the responsibility
        readDispatchThread = null;
        this.pendingOperations = pendingReadOperations;
    }

    /**
     * Called from native side, concurrent read requests are send here.
     * This is not called when JPfmFileSystem is implemented.
     * JPfmFileSystem has it's own dispatch methods.
     * This functions adds requests to pendingOperations
     * and ReadDispatch thread dispatches them from a separate thread.
     * Thus all filesystem operations other than read share a single thread,
     * being implemented in blocking fashion, and all read operations
     * are dispatched from a single independent thread.
     */
    @NonBlocking
    private final void concurrentRead(Read read){
        pendingOperations.add(read);//thread safe
        synchronized(lock){
            //synchronization is required only if same volume is mounted
            //at more than one location
            lock.notifyAll();
        }
        //System.out.println("adding"+read);
    }

    @MightBeBlocking(reason="Function is abstract")
    protected abstract void read(Read read)throws Exception;

    ///*to remove later*/ private AbstractVolume getVolume(){return null;}
    
    //+++++++++++pismo file mount equivalents++++++++++
    /**
     * @return FileAttributesProvider for the root directory
     */
    //@NotNull
    protected abstract FileAttributesProvider getRootAttributes();

    /**
     * Called from native side. Call forwarded to abstract open.
     * Added to process filedecriptor after opening.
     * Doing this using JNI is cumbersome.
     * @param filePath
     * @return
     */
    private final FileAttributesProvider open1(String[] filePath){
        FileAttributesProvider ret = open(filePath);
        if(ret!=null){
            if(ret.getFileDescriptor()!=null){
                boolean wasOpen = ret.getFileDescriptor().isOpen();
                ret.getFileDescriptor().opened();
                if(!wasOpen)
                    open(ret); // to ensure opening of files
            }
        }            
        return ret;
    }

    /**
     * The for filepath  /directory1/file1.bin
     * filePath[] = {"directory1", "file1.bin"} <br/>
     * <br/>
     * The filedescriptor is set as open after this method
     * successfully returns. Just after that,
     * {@link #open(jpfm.FileDescriptor) } is called.
     * It is in {@link #open(jpfm.FileDescriptor) } that you
     * should call open() of any JPfmReadable. <br/>
     * Here you are supposed to simply return the
     * appropriate FileAttributesProvider, nothing more.
     * @param filePath The path of the file or folder being opened
     * @return FileAttributesProvider associated with the given filePath
     * or null if no such file exists in the Volume
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that open consumes negligible time to complete")
    protected abstract FileAttributesProvider open(String[] filePath);

    /**
     * This is always called after open, if and only if
     * the file is being opened for the first time.
     * This method should be used to call open() function
     * of all JPfmReadables .
     * @param FileAttributesProvider
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that open consumes negligible time to complete")
    protected abstract void open(FileAttributesProvider fap);

    /**
     * Invoked for file whose existence in the abstract volume was
     * recently confirmed. This is used for serializingOpen operation.
     *
     *
     * This has no concurrent counterpart and is also used in {@link JPfmReadOnlyFileSystem } .
     * Just as all blocking fileystem method this method should be implemented in such a
     * way that it does not take much time to execute,
     * because the client application may be in <b>Not Responding</b> state during execution of this.
     * <br/>
     * The FileAttributesProvider is not cached by the JPfm.
     * This provides the freedom for the FileAttributes to be saved in
     * any desired fashion : in RAM, harddisk or database;
     * which would probably be more efficient
     * (and memory saving) that JPfm handling all this.
     * <br/>
     * Even the FileDescriptor is not cached by JPfm, it only
     * maintains certain Id to differentiate between files.
     * <br/>
     * The correct way to know if a given
     * FileAttributesProvider correspondes to the
     * FileDescriptor passed is  to get the fileDescriptor FileAttributesProvider being checked
     * by {@link FileAttributesProvider#getFileDescriptor()} and then
     * using {@link FileDescriptor#implies(jpfm.FileDescriptor) } passing it the
     * fileDescriptor of the file being reopened.
     * If {@link FileDescriptor#implies(jpfm.FileDescriptor) } returns true
     * then that FileAttributesProvider should be returned.
     * If no FileAttributesProvider in this volume satify this criteria
     * null can be returned. (this implies that the file existed but not any more)
     *
     * @param fileDescriptor The fileDescriptor corresponding to a
     * file
     * @return The FileAttributesProvider associated with the given
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that getFileAttributes consumes negligible time to complete, and files metainfo is not backed by a slow source.")
    protected abstract FileAttributesProvider getFileAttributes(FileId fileDescriptor);

    /**
     * @param folderToList The FileDescriptor of the folder whoes contents are to be listed
     * Null may be returned
     * @return DirectoryStream that provides an iterator over the abstract list of files
     * and folders in this folderToList
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that list consumes negligible time to complete, as the folder is not a remote one, or folder contents have been cached")
    protected abstract DirectoryStream list(FileId folderToList);

    /**
     * The legacy JPfm equivalent of read. This has been deprecated.
     * This is not invoked by the jpfm native driver in general settings.
     * Implementin this is optional.
     *
     *
     * <br/>
     * Invoked when read requests are made on a file.
     * The ByteBuffer is a directBuffer and should be filled with the requested region
     * @param file The FileDescriptor of file to be read
     * @param offset The offset of the file from where reading is started
     * @param directByteBuffer The buffer where the data is to be filled. In general, if possible the buffer should be fully filled.
     * @return Value greater than equal to zero if file corresponding to the given FileDescriptor was found,
     * and this returned value indicates the actual number of bytes filled in buffer
     * A negative 1 is returned if the end of the file is reached
     * Any value smaller than -1 to indicate that file was not found
     * @deprecated blocking read function is unsafe and can put
     * the system file explorer in a <b>Not Responding</b> state.
     */
    @Blocking(getReasonWhyItDoesNotMatter="Not used unless native libaries are compiled with custom settings")
    @Deprecated
    protected abstract int read(FileId file, long offset, ByteBuffer directByteBuffer);

    /**
     * This is called when all instances of the file have been closed.
     * The memory allocated and handles can be freed and FileDescriptor can be saved or forgotten whichever
     * is desired. (removing reference to FileDescriptor will free 40 bytes of memory  )
     * @param file The filedescriptor of the file whoes resources (if any) can be freed/that is file can be closed
     */
    @Blocking(getReasonWhyItDoesNotMatter="Calls to close in any java.io or java.nio library do not block")
    protected abstract void close(FileId file);

    /**
     * This is called when user/an application tries to delete a file.
     * Implementing this is would allow deletion of malacious files.
     * It is would be a better idea not to check if the file is being read, before deleting it,
     * because this way malacious files cannot be locked.
     * Files on virtual filesystem are unreal, so it does not matter if they are deleted, they can
     * be very easily re-added to the filesystem.
     *
     * <br/><br/><br/><br/>
     * <b><u>Additional reference from PFM docs</u></b><br/><br/>
     * <i>Please note : Native implementation is different from java implementation. The description
     * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
     * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
     * <br/><br/>
     * <b>Deleted Files</b><br/>
     * The PFM Protocol handles file deletion using a unix model,
     * where deletion applies to file names as opposed to underlying
     * file data. After a file has been deleted, the file data must
     * remain accessible until the file is finally closed.<br/><br/>
     * The unix file deletion model requires extra code for some formatters.
     * For other formatters it is trivially supported. Regardless,
     * it is a requirement for formatters and is utilized by the driver.<br/><br/>
     * Formatter developers should understand that the NT file system
     * model is more complex than is apparent to casual
     * users of the Win32 API. Using a unix model for
     * file delete allows the driver to achieve a high level
     * of application compatibility in a more portable and
     * supportable way than if the native NT delete model were
     * directly supported by the protocol.
     *
     * @param file The filedescriptor of the file whoes resources (if any) can be freed/that is file can be closed
     */
    @Blocking
    protected abstract void delete(FileId fileToDelete);

    /**
     * The total size of the volume.
     * For read only volume it is the sum of size of each file in the volume.
     * This is only informative and incorrect implementation will not cause funtional failuers in readonly volume/formatter.
     * @return The total size of the volume, that is the sum of size of each file in the volume
     */
    @Blocking
    protected abstract long capacity();
    //-----------pismo file mount equivalents---------

    /**
     * A mount can also be initiated from the native side.
     * In such a case the native side needs to know which
     * formatter can be used to manage the volume being mounted.
     *
     *
     * Implementors should also refer the pismo documentation
     * {@link http://www.pismotechnic.com/pfm/doc/#pfmformatter-identify }
     *
     *
     * {@link JPfmReadOnlyFileSystem#canManage(jpfm.AbstractVolume) }
     * is just ceremonial, actually classes implementing
     * JPfmReadOnlyFileSystem will be searched for canManage and create method.
     *
     *
     * @param volumeRawData Buffer containing initial few bytes of data of the file
     * that is being mounted as a volume
     * @param name Name of the file that contains data associated with the volume
     * @param volumeFileChannel The file channel which can be used to read (currently write not supported)
     * the file being mounted
     * @param the path of the file being mounted. This can be used to construct a nio Path
     * @return true is and only if the provided can be managed by an instance of this
     */
    public static boolean canManage(String name, java.nio.ByteBuffer volumeRawData, FileChannel volumeFileChannel) {
        return false;
    }

    public static JPfmReadOnlyFileSystem create(
            String name,
            java.nio.ByteBuffer volumeRawData,
            FileChannel volumeFileChannel,
            String directory) {
        return null;
    }

    public void printIncompleteOperations() {
        printIncompleteOperations(System.out);
    }
    
    public void printIncompleteOperations(java.io.PrintStream printStream) {
        Iterator<FileSystemOperation> it = incompleteOperations.iterator();
        printStream.println("+++++++++ operations dipatched but not completed yet ++++++++++++");
        while(it.hasNext()){
            FileSystemOperation next = it.next();
            if(next.isCompleted()){
                it.remove();
                continue;
            }
            printStream.println(next);
        }
        printStream.println("-------- operations dipatched but not completed yet -------------");
        it = pendingOperations.iterator();
        printStream.println("+++++++++ operations not dipatched yet ++++++++++++");
        while(it.hasNext()){
            FileSystemOperation next = it.next();
            if(next.isCompleted()){
                it.remove();
                continue;
            }
            printStream.println(next);
        }
        printStream.println("-------- operations not dipatched yet -------------");
    }

    /**
     * Indicates the number of mount location where this filesystem is mounted.
     * Usually it will be one, because implementation of filesystems which
     * can be mounted at more than one mount location is slightly more
     * difficult.
     */
    public final int getMountCount() {
        return mountCount.get();
    }

    public synchronized final boolean addMountStateListener(final FileSystemMountStateListener listener){
        return mountStateListeners.add(listener);
    }

    public synchronized final boolean removeMountStateListener(final FileSystemMountStateListener listener){
        return mountStateListeners.remove(listener);
    }
    
    public final void forceComplete() throws Exception,SecurityException{
        Exception exc = new Exception("FileSystem level force completion initiated");
        synchronized(pendingOperations){
            Iterator<FileSystemOperation> it = incompleteOperations.iterator();
            while(it.hasNext()){
                FileSystemOperation next = it.next();
                it.remove();
                next.handleUnexpectedCompletion(exc);
                pendingOperations.remove(next);
            }
        }
    }

    /**
     * ReadDispatchThread does not operate for JPfmFileSystem, since
     * all filesystem functions are allow NonBlocking implementation.
     */
    private static final class ReadDispatchThread extends Thread {
        private final JPfmReadOnlyFileSystem parent;
        private static final int SLEEP_INTERVAL = 50000;//milliseconds

        public ReadDispatchThread(JPfmReadOnlyFileSystem parent) {
            super("JPfmReadOnlyFormatter_read_dispatcher");
            this.parent = parent;
        }

        @Override
        public void run() {
            INFINITE_LOOP:
            for(;parent.mountCount.get()>0;){
                Iterator<FileSystemOperation> it = parent.pendingOperations.iterator();
                Read read;FileSystemOperation next;

                WHILE_LOOP:
                while(it.hasNext()){
                    next = it.next();
                    if(next instanceof Read){
                        read = (Read)next;
                        if(read.isCompleted()){
                            //parent.pendingOperations.remove(read);
                            //System.out.println("removing"+read);
                            //>>>>> TODO :
                            //parent.incompleteOperations.remove(next);
                            it.remove();
                            continue WHILE_LOOP;
                        }
                        try{
                            parent.read(read);
                            //object has been send once, it can be removed now
                            //we send requests only once.
                            //otherwise in second loop it will come agan, as while we are busy dispatching it
                            //it might get completed. There is no point in sending requests more than once.
                            //However we could have a flag that indicates that the request has been send
                            //Multiple such flags will exists,
                            // example : if throttled file use : one for JPfmReadOnlyFileSystem, one for ThrottledReadlFile
                            parent.incompleteOperations.add(next);
                            it.remove(); continue WHILE_LOOP;
                        }catch(Exception any){
                            any.printStackTrace();
                            if(!read.isCompleted())
                                read.complete(JPfmError.FAILED, 0,new ForceCompleter());
                            /*if(!read.isSatisfied()){
                                System.out.println("invoking forceCompleteOnRead");
                                READ_FORCE_COMPLETER.forceComplete(read);
                                //read.complete(JPfmError.FAILED, 0);
                            }*/
                        }
                    }else {
                        //cannot happen
                        throw new RuntimeException("JPfmReadOnlyFileSystem receiving one Read type FileSystemOperation");
                    }
                }

                try{
                    synchronized(parent.lock){
                        while(parent.pendingOperations.size()==0)
                            parent.lock.wait(SLEEP_INTERVAL);
                    }
                }catch(InterruptedException any){
                    any.printStackTrace(System.out);
                }
            }
        }
    }

    private static final class ForceCompleter implements Completer {
        private final StackTraceElement[] stackTrace;
        private ForceCompleter(){
            stackTrace = new Throwable().getStackTrace();
        }
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            return 0;
        }

        public void completeNow(ReadRequest pendingRequest) {
            pendingRequest.complete(JPfmError.FAILED, 0, this);
        }

        public StackTraceElement[] getStackTrace() {
            return stackTrace;
        }

    }

    protected final static class MountStateListener implements UnderprivilegedFormatterListener {
        private final JPfmReadOnlyFileSystem parent;
        private MountStateListener(final JPfmReadOnlyFileSystem parent) {
            this.parent = parent;
        }

        public final void eventOccurred(final FormatterEvent event) {
            switch(event.getEventType()){
                case SUCCESSFULLY_MOUNTED: {
                    final int state = parent.mountCount.incrementAndGet();
                    new Thread(FormatterEvent.EVENT.SUCCESSFULLY_MOUNTED.name()){
                        @Override
                        public void run() {
                            final Iterator<FileSystemMountStateListener> it
                                    = parent.mountStateListeners.iterator();
                            
                            // There is a separate Dispatch mechanism for
                            // JPfmFileSystem, it is useless calling
                            // this for it.
                            if(state==1)
                                if(!(parent instanceof JPfmFileSystem)){
                                    parent.readDispatchThread = new ReadDispatchThread(parent);
                                    parent.readDispatchThread.start();
                                }
                            while(it.hasNext()){
                                if(state==1)
                                    it.next().mounted();
                                else
                                    it.next().remounted();
                            }
                        }
                    }.start();
                    break;
                }
                case DETACHED: {
                    final int state = parent.mountCount.decrementAndGet();
                    if(state==0){
                        new Thread(FormatterEvent.EVENT.DETACHED.name()){
                            @Override
                            public void run() {
                                Iterator<FileSystemMountStateListener> it
                                        = parent.mountStateListeners.iterator();
                                while(it.hasNext()){
                                    it.next().completelyUnmounted();
                                }
                            }
                        }.start();
                    }
                    break;
                }
                default:
                    //ignore
            }
        }

    }
}
