/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jpfm;

import java.nio.ByteBuffer;

/**
 *
 * @author Shashank Tulsyan
 */
public interface ReadOnlyFileSource {
    public long getFileSize();
    public int read(long offset, ByteBuffer directByteBuffer);
}
