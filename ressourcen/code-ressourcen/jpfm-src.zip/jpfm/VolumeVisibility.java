/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

/**
 * This allows the virtual volume to be visible only to some processes.
 * Visible process ID sets the process (and its children)
 * that will see the virtual folder, useful for an applciation that wants
 * to access resource files or something, but does not want the user to
 * see them. <br/>
 * Currently, you can set visibility to all processes only.
 * In future this will allow you to limit process visibility.
 * The reason why it is not supported at the moment, is that
 * processId is a platform specific id, and there is no direct method in
 * java to know process id of a given application. <br/>
 * <br/>
 * VolumeVisibility is also limited by the {@link  MountFlags#isSystemVisible() }
 * flag.
 * @see MountFlags#isSystemVisible()
 * @see VolumeVisibility#GLOBAL
 * @author Shashank Tulsyan
 */
public final class VolumeVisibility {
    private final int processId;

    //enum {pfmVisibleProcessIdAll        = -1, };
    /**
     * Global visibility implies that all processes would be able to view this
     * virtual folder. This is different from {@link  MountFlags#isSystemVisible() } <br/>
     * System visible determines whether other sessions (fast user
     * switching, system service session, terminal server) can see the virtual
     * folder. Drive letter and UNC access is unaffected.
     */
    public static final VolumeVisibility GLOBAL = new VolumeVisibility(-1,0);

    public static final VolumeVisibility ME_AND_MY_CHILD_PROCESSES = new VolumeVisibility(-2,0);
    // do not change the constant value from -2 to anything else,
    // you'll have to edit the native libraries also at different unexpected
    // places for that to work.

    private VolumeVisibility(final int processId,final int x) {
        this.processId = processId;
    }

    public VolumeVisibility(final int processId) throws IllegalArgumentException {
        if(processId < 0)throw new IllegalArgumentException("ProcessId cannot be negative. For processId passed="+processId);
        this.processId = processId;
    }

    /**
     * @return Platform specific process id for the process and child processes
     * to which this virtual volume be visible OR -1 implying global visibility,
     * and -2, impyling visibility limited to this JVM process and it's child processes.
     * Since -1, and -2 and not valid values, values returned from this function should not be
     * blindly used.
     */
    public int getProcessId() {
        return processId;
    }
    
}
