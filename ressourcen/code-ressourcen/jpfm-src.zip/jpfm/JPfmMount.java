/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   JPfmMount.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import jpfm.annotations.NonBlocking;
import java.io.File;
import jpfm.annotations.Blocking;
import jpfm.operations.FileSystemOperation;



/**
 *
 * @author Shashank Tulsyan
 */
public final class JPfmMount {

    private JPfmReadOnlyFileSystem formatter;
    private String mountLocation;
    private long formatterHandle;
    private boolean wasUnmountedByMe = false;
    private static boolean jpfmApiCreated = false;
    private ThreadGroup threadGroup;
    private FormatterListener formatterListener;
    public static final String JPFM_LIBRARY_NAME = "jpfm";
    /*package private*/ boolean wasMountedSuccessfully = false; // used by jpfmfilesystem
    private long mountId = 0;
    private VolumeVisibility volumeVisibility =  VolumeVisibility.GLOBAL;

    static {
        try{
            System.loadLibrary(JPFM_LIBRARY_NAME);
        }catch(UnsatisfiedLinkError any){
            System.out.println();
            System.out.println("+++++++++Could not find jpfm native library+++++++++++");
            any.printStackTrace();
            System.out.println();
            if(System.getProperty("os.name").toLowerCase().contains("windows"))
                System.out.println("To fix this error, copy jpfm.dll to system32 directory.");
            else if(System.getProperty("os.name").contains("Linux"))
                System.out.println("To fix this error, copy libjpfm to suitable directory like /usr/lib ");
            System.out.println("---------Could not find jpfm native library-----------");
            System.out.println();
        }
        FileSystemOperation.setHandleGetter(new FormatterDispatchHandleGetter());
        //jpfmApiCreated = createJPfmApi();
    }

    private JPfmMount() {
    }

    /**
     * Returns the formatter which is used to list contents of folders and read files
     * inside the abstract volume mounted in the location represented by this mount
     * @see JPfmReadOnlyFileSystem
     * @see JPfmMount#getMountLocation() 
     * @return The formatter associated with this mount
     */
    public final JPfmReadOnlyFileSystem getFileSystem() {
        return formatter;
    }

    /**
     * The location where the abstract volume appears in the
     * operating system's/native filesystem
     * @return the mount location
     */
    public final String getMountLocation() {
        return mountLocation;
    }

    /**
     * The sole method to create new mounts.
     * Currently only readonly formatters are supported can be mounted.
     * @param toMount the formatter which should be used to list contents of folders and read files
     * inside the abstract volume which is going to be mounted
     * @param mountLocation The location where the abstract volume should be mounted
     * @param listener (null allowed)
     * @return A JPfmMount object representing a mount location of
     * mounted abstract volume (if no errors occur)
     * @throws MountException
     */
    public final static synchronized JPfmMount mount(
            JPfmReadOnlyFileSystem toMount,
            String/*java.nio.file.Path*/ mountLocation,
            UnderprivilegedFormatterListener listener) throws MountException {
        return mount(toMount, mountLocation, listener, true);
    }

    /**
     * Readonly FileSystems are supported can be mounted.
     * If it is attempted to mount a concurrent fileystem, the flow is simply redirected to correct method,
     * with MountFlag set to ReadOnly.
     * @param toMount the formatter which should be used to list contents of folders and read files
     * inside the abstract volume which is going to be mounted
     * @param mountLocation The location where the abstract volume should be mounted
     * @param listener (null allowed)
     * @param exitOnUnmount if set true, this instance of java will be terminated when the
     * volume is unmounted ( forcefully by external application or by inkovinf {@link JPfmMount#unMount() }\ )
     * @return A JPfmMount object representing a mount location of
     * mounted abstract volume (if no errors occur)
     * @throws MountException
     */
    @Blocking
    public final static synchronized JPfmMount mount(
            final JPfmReadOnlyFileSystem toMount,
            String mountLocation,
            final UnderprivilegedFormatterListener underprivilegedListener,
            final boolean exitOnUnmount) throws MountException {
        return mount(toMount, mountLocation, underprivilegedListener, exitOnUnmount, VolumeVisibility.GLOBAL);
    }

    @Blocking
    public final static synchronized JPfmMount mount(
            final JPfmReadOnlyFileSystem toMount,
            String mountLocation,
            final UnderprivilegedFormatterListener underprivilegedListener,
            final boolean exitOnUnmount,
            final VolumeVisibility visibility) throws MountException {
        return mount(toMount, mountLocation, null, underprivilegedListener, exitOnUnmount, visibility);
    }

    @Blocking
    public final static synchronized JPfmMount mount(
            final JPfmReadOnlyFileSystem toMount,
            String mountLocation,
            MountFlags mountFlags,
            final UnderprivilegedFormatterListener underprivilegedListener,
            final boolean exitOnUnmount,
            final VolumeVisibility visibility) throws MountException {


        if(mountFlags==null)mountFlags=new MountFlags.Builder().setReadOnly().build();
        
        if(toMount instanceof JPfmFileSystem){
            return mount((JPfmFileSystem)toMount, mountLocation, new MountFlags.Builder().setReadOnly().build(), underprivilegedListener);
        }

        int jpfmSuppliedMountFlag = 0;
        jpfmSuppliedMountFlag |= checkMountLocation(mountLocation);
        if((jpfmSuppliedMountFlag & pfmMountFlagFolder) !=0){
            //we need a slash char at end of mountLocation for folder
            if(mountLocation.charAt(mountLocation.length()-1)!=File.separatorChar){
                mountLocation = mountLocation + File.separatorChar;
            }
        }

        jpfmSuppliedMountFlag |= mountFlags.getMountFlag();

        performPreMountingChecks();
        
        final JPfmMount mount = new JPfmMount();
        mount.formatter = toMount;
        mount.mountLocation = mountLocation;

        ThreadGroup threadGroup = new ThreadGroup(toMount.getClass().getSimpleName() + "@" + mountLocation);
        mount.threadGroup = threadGroup;
        //check if mount location is valid by checking formatter handle value

        FormatterListener listener = new FormatterListener(exitOnUnmount, mount);
        mount.formatterListener = listener;

        FileAttributesProvider root = toMount.getRootAttributes();
        if (root == null) {
            throw new NullPointerException("Root\'s FileAttributesProvider should never be null");
        }

        final Object lock = new Object();
        SuccessListener successListener = new SuccessListener(mount, lock);
        listener.addListener(successListener);
        listener.addListener(underprivilegedListener);//successlistener needs to be first
        listener.addListener(toMount.mountStateListener);

        mount.formatterHandle = mount.mountNewReadOnly(
                toMount,
                mount.mountLocation,
                root,
                listener,
                threadGroup,
                "JPfm."+toMount.getClass().getSimpleName(),
                jpfmSuppliedMountFlag,
                visibility.getProcessId()
                );
        if (mount.formatterHandle < 0) {
            throw new MountException("Couldn't get handle; reason=" + mount.formatterHandle);
        }

        synchronized(successListener.lock){
            while(successListener.wasSuccessful()==0){
                try{
                    successListener.lock.wait();
                }catch(InterruptedException exception){
                    exception.printStackTrace();
                }
            }
        }

        if(successListener.wasSuccessful()==2){
            return mount;
        }
        throw new MountException(successListener.event.getMessage());
    }

    /**
     * Concurrent read-write-modifiable formatters can be mounted.
     * System.exit is called when this volume is unmounted.
     * Other things same as JPfmMount.mount(jpfm.JPfmFileSystem, java.lang.String, jpfm.MountFlags, jpfm.UnderprivilegedFormatterListener, boolean)
     * @param mountFlags Can be null. If null, mounting is done in readonly mode
     * @param underprivilegedListener Can be null
     * @see JPfmMount#mount(jpfm.JPfmFileSystem, java.lang.String, jpfm.MountFlags, jpfm.UnderprivilegedFormatterListener, boolean)
     */
    @NonBlocking
    public final synchronized static JPfmMount mount(
            final JPfmFileSystem toMount,
            String mountLocation,
            MountFlags mountFlags,
            final UnderprivilegedFormatterListener underprivilegedListener
        ) throws MountException {
        if(mountFlags==null)mountFlags=new MountFlags.Builder().setReadOnly().build();
        return mount(toMount, mountLocation,'\0', mountFlags, underprivilegedListener, true, VolumeVisibility.GLOBAL);
    }
    /**
     * Concurrent read-write-modifiable formatters can be mounted.
     * @param toMount the concurrent formatter which should be used to list contents of folders and read files
     * inside the abstract volume which is going to be mounted
     * @param mountLocation The location where the abstract volume should be mounted
     * @param driveLetter This is independent of mount location, as specific to windows type of operating systems.
     * Mouting on as drives requires admin priveledges. It should not be used as far as possible. Set it to  '\0' if not required.
     * It is possible to have a virtual folder mounted on both places, that is mountlocation and the drive specified.
     * @param mountFlags properties such as read only, writable, system visible etc can be specified using mountflags. Can be set to null, if null mounting done in readonly mode.
     * @param listener (null allowed)
     * @param exitOnUnmount if set true, this instance of java will be terminated when the
     * volume is unmounted ( forcefully by external application or by inkovinf {@link JPfmMount#unMount() }\ )
     * @return A JPfmMount object representing a mount location of
     * mounted abstract volume (if no errors occur). The execution is blocked
     * util it is confirmed that the volume was mounted safely.
     * @throws MountException
     */
    @Blocking(getReasonWhyItDoesNotMatter="It is helpful")
    public final synchronized static JPfmMount mount(
            final JPfmFileSystem toMount,
            String mountLocation,
            final char driveLetter,
            MountFlags mountFlags,
            final UnderprivilegedFormatterListener underprivilegedListener,
            final boolean exitOnUnmount,
            VolumeVisibility visibility) throws MountException {

        int jpfmSuppliedMountFlag = 0;
        if(!mountFlags.isDesktop()){
            jpfmSuppliedMountFlag |= checkMountLocation(mountLocation);
            if((jpfmSuppliedMountFlag & pfmMountFlagFolder) == pfmMountFlagFolder){
                if(!mountFlags.isFolder()){
                    throw new IllegalArgumentException("Conflict between arguments and reality : MountFlags claim that mountLocation is not a folder, but this is not the case.");
                }
                //we need a slash char at end of mountLocation for folder
                if(mountLocation.charAt(mountLocation.length()-1)!=File.separatorChar){
                    mountLocation = mountLocation + File.separatorChar;
                }
            }
            if(mountFlags == null)mountFlags = new MountFlags.Builder().setSystemVisible().build();
            jpfmSuppliedMountFlag|=mountFlags.getMountFlag();

            if(driveLetter!= '\0'){
                //do a os type check as well
                boolean valid = false;
                try{
                    File checkDriveLetter = new File(driveLetter+":\\"); // this will surely fail on linux
                    if(checkDriveLetter.exists())valid = false;
                    else valid=true;
                }catch(Exception ay){
                    valid = true;
                }if(!valid)
                    throw new MountException("Cannot mount on "+driveLetter+":\\");
            }
        }

        performPreMountingChecks();

        JPfmMount mount = new JPfmMount();
        mount.formatter = toMount;
        mount.mountLocation = mountLocation;
        mount.volumeVisibility = visibility;

        ThreadGroup threadGroup = new ThreadGroup(toMount.getClass().getSimpleName() + "@" + mountLocation);
        mount.threadGroup = threadGroup;
        //check if mount location is valid by checking formatter handle value

        FormatterListener listener = new FormatterListener(exitOnUnmount, mount);
        mount.formatterListener = listener;
        listener.addListener(underprivilegedListener);
        
        final Object lock = new Object();
        SuccessListener successListener = new SuccessListener(mount, lock);
        listener.addListener(successListener);
        listener.addListener(toMount.mountStateListener);
        
        mount.formatterHandle = mount.mountNewConcurrent(
                toMount,
                mount.mountLocation,
                driveLetter,
                listener,
                threadGroup,
                "JPfm."+toMount.getClass().getSimpleName(),
                jpfmSuppliedMountFlag,
                toMount.getVolumeFlags().getVolumeFlags(),//checked for nullness
                visibility.getProcessId()
            );
        if (mount.formatterHandle < 0) {
            throw new MountException("Couldn't get handle; reason=" + mount.formatterHandle);
        }

        synchronized(successListener.lock){
            while(successListener.wasSuccessful()==0){
                try{
                    successListener.lock.wait();
                }catch(InterruptedException exception){
                    exception.printStackTrace();
                }
            }
        }
        
        if(successListener.wasSuccessful()==2)return mount;
        throw new MountException(successListener.event.getMessage());
    }

    private static final void performPreMountingChecks() throws MountException{
        int error = 0;
        if (!jpfmApiCreated) {
            jpfmApiCreated = (error = createJPfmApi()) == 0;
        }
        if (error == 1) {
            throw new MountException("Jpfm class missing or corrupt");
        }
        if (error == 2) {
            throw new MountException("Pismo file mount incorrectly installed or not installed");
        }
        if(error > 2 || error < 0) {
            throw new MountException("Unknown error occured. Error = "+error);
        }
    }

    /**
     * Unmounts the volume. For remounting a new JPfmMount instance has to be created
     * If the volume had already been unmounted, then this simply returns
     * @throws UnmountException
     */
    public synchronized final void unMount() throws UnmountException {
        if(wasUnmountedByMe)return;
        unMountAndRelease(formatterHandle);
        wasUnmountedByMe = true;
    }

    /**
     * @return true if the formatter is in a mounted to the location 
     * specified and is in a useable state
     */
    public synchronized final boolean isMounted() {
        return isAlive(formatterHandle);
    }

    private final native boolean isAlive(long formatterHandle);

    private final static void printObject(Object obj, int lineNumber) {
        if (lineNumber != 0) {
            System.out.print("Message from native code (" + lineNumber + ") : ");
        }
        System.out.println(obj);
    }

    private final static FileDescriptor createNewFileDescriptor(){
        // env->NewObject gives weird errors,
        // it is required that each and every call be replaces
        // by such a function. Reason for error is unknown.
        return new FileDescriptor();
    }

    /*@Deprecated private final static FormatterEvent createNewFormatterEvent(int event, String message){
        FormatterEvent formatterEvent = new FormatterEvent(event, message);
        return formatterEvent;
    }*/

    private final static FormatterEvent createNewFormatterEvent(int event, String message, long openId){
        return new FormatterEvent(
                event,
                message+FileDescriptor.makeFileDescriptorString(openId)
        );
    }

    private final static FormatterEvent createNewSystemErrorFormatterEvent(
            int event,
            String message,
            int lineNumber,
            String fileName,
            long errorCode,
            JPfmMount mount){
        Throwable cause = convertErrorToThrowable(mount,errorCode);
        cause.setStackTrace(new StackTraceElement[]{
            new StackTraceElement("", "", fileName, lineNumber)
        });
        return new FormatterEvent(
                event,
                message,
                cause,
                mount
        );
    }

    private final static Throwable convertErrorToThrowable(JPfmMount mount, long errorCode){
        return new SystemErrorException(errorCode,convertErrorCodeToString(errorCode));
    }

    private final static FormatterEvent createNewExceptionFormatterEvent(Throwable throwable, int lineNumber, String fileName){
        ExceptionFormatterEvent formatterEvent = new ExceptionFormatterEvent(throwable,lineNumber,fileName);
        return formatterEvent;
    }

    private final static native String convertErrorCodeToString(long errorCode);

    /**
     * @return The thread group with which all native methods are associated
     */
    public final ThreadGroup getThreadGroup() {
        return threadGroup;
    }

    public final FormatterListener getFormatterListener() {
        return formatterListener;
    }

    @Override
    public final String toString() {
        if(mountId!=0)
            return this.getThreadGroup().getName()+" (mountid="+mountId+")";
        return this.getThreadGroup().getName();
    }

    /**
     * Gives a system wide unique id for representing this mount.<br/>
     * Default value of mountId is zero and represents a invalid mount,
     * or a mount operation which is in progres and has not finished yet.
     * This method will surely return valid values after a
     * {@link jpfm.FormatterEvent.EVENT#SUCCESSFULLY_MOUNTED } event
     * was passed to the formatter listener. <br/>
     * This can be used to find appropriate mount and then pass
     * control messages as described in {@link jpfm.operations.Control }
     * If possible mountId {@link JPfmMount#getMountId() }  should be used
     * to compare two JPfmMount instance instead of mountLocation.
     * Mount location is not unique. More than one mount can be made on a single
     * mount location.
     * For example, on a given location, ptramfs could be mounted,
     * and then followed by jpfm.monitoredfs.MonitoredFileSystem .
     * In such cases, the fileystem which was mounted later is visible.
     * So, in this case jpfm.monitoredfs.MonitoredFileSystem would be visible.
     * If pfm unmount utility is used, jpfm.monitoredfs.MonitoredFileSystem is unmounted.
     * But ptramfs is still not unmounted. Unmounting again would unmount
     * ptramfs . If the mount location was originally a file it would now change back
     * into a file.
     * @see jpfm.operations.Control
     * @return
     */
    public long getMountId() {
        return mountId;
    }

    @Override
    public final int hashCode() {
        return (int)mountId;
    }

    @Override
    public final boolean equals(Object obj) {
        if(!(obj instanceof JPfmMount))return false;
        if(((JPfmMount )obj).mountId==0)
            return super.equals(obj);
        if(this.mountId==0)return false;
        return ((JPfmMount )obj).mountId == this.mountId;
    }

    public final boolean isAValidMount(){
        return mountId != 0;
    }

    public final VolumeVisibility getVolumeVisibility(){
        return volumeVisibility;
    }
    
    // called from native side
    private void setMountId(long mountId) {
        this.mountId = mountId;
    }
    
    private final native int unMountAndRelease(long formatterHandle);

    private final static native void destroyAll();

    private static native int createJPfmApi();
    //retunrs formatterHandle

    private final native long mountNewReadOnly(
            JPfmReadOnlyFileSystem toMount,
            String mountLocation,
            FileAttributesProvider rootDirectory,
            FormatterListener listener,
            ThreadGroup threadGroup,
            String formatterName,
            int jpfmSuppliedMountFlag,
            int processId) throws MountException;

    private final native long mountNewConcurrent(
            JPfmFileSystem toMount,
            String mountLocation,
            char mountNewConcurrent,
            FormatterListener listener,
            ThreadGroup threadGroup,
            String formatterName,
            int jpfmSuppliedMountFlag,
            int volumeFlags,
            int visibleProcessId) throws MountException;

    /*private static int checkMountLocation(java.nio.file.Path mountLocation) throws IllegalMountLocationException{
        try{
            if(!mountLocation.exists())
                throw new IllegalMountLocationException("Mount location does not exist");
            if(java.nio.file.attribute.Attributes.readBasicFileAttributes(mountLocation).isDirectory())
                return pfmMountFlagFolder;
            //how to check for desktop ??
        }catch(Exception a){
            IllegalMountLocationException exp
                    = new IllegalMountLocationException(a.getMessage());
            exp.setStackTrace(a.getStackTrace());
            throw exp;
        }return 0;
    }*/

    private static int checkMountLocation(String mountLocationString) throws IllegalMountLocationException{
        try{
            File mountLocation = new File(mountLocationString);
            if(!mountLocation.exists())
                ;//throw new IllegalMountLocationException("Mount location does not exist. MountLocation = "+mountLocationString);
            if(mountLocation.isDirectory()){            
                return pfmMountFlagFolder;
            }
            //how to check for desktop ??
        }catch(Exception a){
            IllegalMountLocationException exp
                    = new IllegalMountLocationException(a.getMessage());
            exp.setStackTrace(a.getStackTrace());
            throw exp;
        }return 0;
    }

    /*private static final int pfmMountFlagReadOnly          = 0x0001;
    private static final int pfmMountFlagSystemVisible     = 0x0002;
    private static final int pfmMountFlagWorldRead         = 0x0004;
    private static final int pfmMountFlagWorldWrite        = 0x0008;
    private static final int pfmMountFlagUncOnly           = 0x0010;
    private static final int pfmMountFlagVerbose           = 0x0020;*/
    private static final int pfmMountFlagFolder            = 0x0040;
    /*private static final int pfmMountFlagForceUnbuffered   = 0x0080;
    private static final int pfmMountFlagForceBuffered     = 0x0100;*/
    private static final int pfmMountFlagDesktop           = 0x0200;


    public static final class FormatterDispatchHandleGetter{

        private FormatterDispatchHandleGetter() {
        }

        public final long getHandle(final JPfmMount jPfmMount ){
            return jPfmMount.formatterHandle;
        }
    }

    private static final class SuccessListener implements UnderprivilegedFormatterListener {
        private final JPfmMount mount;
        private final Object lock;
        private int result = 0;
        private FormatterEvent event = null;

        public SuccessListener(final JPfmMount mount,final Object lock) {
            this.mount = mount;
            this.lock = lock;
        }

        public void eventOccurred(FormatterEvent event) {
            this.event = event;
            if(event.getEventType()==FormatterEvent.EVENT.SUCCESSFULLY_MOUNTED){
                mount.formatterListener.removeListener(this);
                synchronized(lock){
                    lock.notifyAll();
                    result = 2;
                }
                return;
            }
            if(event.getEventType()==FormatterEvent.EVENT.MOUNT_CREATE_FAILED
                || event.getEventType()==FormatterEvent.EVENT.ERROR ||
                    event.getEventType()==FormatterEvent.EVENT.DETACHED){
                mount.formatterListener.removeListener(this);
                synchronized(lock){
                    lock.notifyAll();
                    result = 1;
                }
                return;
            }
        }

        public final int wasSuccessful(){
            synchronized(lock){
                return result ;
            }
        }

        public final FormatterEvent getEvent(){
            synchronized(lock){
                if(result == 0)return null;
                return event;
            }
        }

    }

}
