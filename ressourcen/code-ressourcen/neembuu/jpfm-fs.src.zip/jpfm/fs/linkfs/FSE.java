/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs.linkfs;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileId;
import jpfm.FileType;
import jpfm.JPfmReadable;
import jpfm.annotations.Blocking;
import jpfm.annotations.NonBlocking;
import jpfm.operations.Write;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.util.ReadCompletionHandler;

/**
 *
 * @author Shashank Tulsyan
 */
public class FSE implements FileAttributesProvider, JPfmReadable {
    private Path path;
    private FSE parent;
    private FileDescriptor fileDescriptor = new FileDescriptor();
    private final boolean isRoot;

    private AsynchronousFileChannel fc;

    public FSE(Path pth, FSE parent) {
        isRoot = false;
        this.path = pth;
        this.parent = parent;
    }

    public FSE(Path pth) { //for root
        isRoot = true;
        this.path = pth;
        this.parent = null;
    }

    /*package private*/ synchronized void setParent(FSE parent){
        this.parent = parent;

    }

    /*package private*/ synchronized void setPath(Path path) {
        this.path = path;
    }




    public void open(){
        if(fc!=null)return;
        try{
            fc = AsynchronousFileChannel.open(getPath(), 
                    StandardOpenOption.READ,StandardOpenOption.WRITE);
        }catch(Exception any){any.printStackTrace();}
    }

    public void close(){
        try{
            fc.close();
            fc=null;
        }catch(Exception any){
            any.printStackTrace();
        }
    }
    
    final void setFileDescriptor(FileId fd){
        if(!fd.isValid()) this.fileDescriptor = new FileDescriptor();
        // we do not have access priveledges to setInvalid function
        else this.fileDescriptor.set(fd);
    }
    public final Path getPath(){
        return path;
    }

    public FileType getFileType() {
        if(Files.isDirectory(path))return FileType.FOLDER;
        if(Files.isRegularFile(path))return FileType.FILE;
        if(Files.isSymbolicLink(path))return FileType.NONE;
        return FileType.NONE;
    }

    public FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    public long getFileSize() {
        if(getFileType()==FileType.FILE){
            try{
                return Files.size(path);
            }catch(Exception any){
                any.printStackTrace();
            }
        }return 0;
    }

    public long getCreateTime() {
        try{
            BasicFileAttributeView bfa =
                  Files.getFileAttributeView(path, BasicFileAttributeView.class);
            return bfa.readAttributes().creationTime().toMillis();
        }catch(Exception any){
            any.printStackTrace();
            return 0;
        }
            
    }

    public long getAccessTime() {
        try{
            BasicFileAttributeView bfa =
                  Files.getFileAttributeView(path, BasicFileAttributeView.class);
            return bfa.readAttributes().lastAccessTime().toMillis();
        }catch(Exception any){
            any.printStackTrace();
            return 0;
        }
    }

    public long getWriteTime() {
        try{
            BasicFileAttributeView bfa =
                  Files.getFileAttributeView(path, BasicFileAttributeView.class);
            return bfa.readAttributes().lastModifiedTime().toMillis();
        }catch(Exception any){
            any.printStackTrace();
            return 0;
        }
    }

    public long getChangeTime() {
        return getWriteTime();
    }

    public String getName() {
        if(isRoot)return "";
        return getPath().getFileName().toString();
    }

    public FileDescriptor getParentFileDescriptor() {
        if(parent==null)return null;
        return parent.getFileDescriptor();
    }

    public FileFlags getFileFlags() {
        FileFlags.Builder builder = new FileFlags.Builder();
        /*PosixFileAttributes bfa;
        try{
            bfa = java.nio.file.attribute.Attributes.readPosixFileAttributes(
                        getPath());
        }catch(Exception any){
            any.printStackTrace();
            return null;
        }
        Iterator<PosixFilePermission> it = bfa.permissions().iterator();
        boolean canWrite = false;
        while(it.hasNext()){
            PosixFilePermission next = it.next();
            if(next == PosixFilePermission.OTHERS_EXECUTE){
                builder.setExecutable();
            }
            if(next == PosixFilePermission.OTHERS_WRITE){
                canWrite = true;
            }
        }
        if(!canWrite){
            builder.setReadOnly();
        }*/
        return builder.build();
    }

    @NonBlocking
    public final void setSize(long newSize)throws Exception{
        if(fc==null)open();
        fc.write(ByteBuffer.allocate(0), newSize);
    }


    @NonBlocking
    public final void write(Write write)throws Exception{
        if(fc==null)open();
        fc.write(write.getByteBuffer(), write.getFileOffset());
    }

    @NonBlocking
    @SuppressWarnings(value="unchecked")
    public final void read(final ReadRequest read) throws Exception{
        if(fc==null)open();
        fc.read(read.getByteBuffer(), read.getFileOffset(), read, ReadCompletionHandler.INSTANCE);
    }

    @Blocking
    public final int read(long offset, ByteBuffer directByteBuffer) {
        throw new UnsupportedOperationException("Blocking read not supported.");
    }

    @Override
    public String toString() {
        if(this.getPath()==null)return super.toString();
        //if(parent==null)
            return this.getPath().toAbsolutePath().toString();
        //return this.getPath().relativize(parent.getRoot().getPath()).toString();
    }

    public final FSE getRoot(){
        if(isRoot)return this;
        return parent.getRoot();
    }

}
