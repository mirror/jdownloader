/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs.linkfs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Iterator;
import jpfm.AccessLevel;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileControlFlag;
import jpfm.FileId;
import jpfm.FileType;
import jpfm.JPfm;
import jpfm.JPfmError;
//import jpfm.JPfmFileSystem;
//import jpfm.JPfmMount;
//import jpfm.JPfmBasicFileSystem;
import jpfm.MountListener;
import jpfm.fs.AsynchronousFileSystem;
import jpfm.fs.Type.ASYNCHRONOUS;
import jpfm.mount.Mount;
import jpfm.mount.MountFlags;
import jpfm.mount.MountParams.ParamType;
import jpfm.mount.MountParamsBuilder;
import jpfm.mount.Mounts;
import jpfm.operations.Capacity;
import jpfm.operations.Close;
import jpfm.operations.Control;
import jpfm.operations.Delete;
import jpfm.operations.FlushFile;
import jpfm.operations.FlushMedia;
import jpfm.operations.List;
import jpfm.operations.MediaInfo;
import jpfm.operations.Move;
import jpfm.operations.MoveReplace;
import jpfm.operations.Open;
import jpfm.operations.Read;
import jpfm.operations.Replace;
import jpfm.operations.SetSize;
import jpfm.operations.Write;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public final class LinkFS
        implements AsynchronousFileSystem
        /*extends JPfmFileSystem*/ {
    private final Path pathToReflect;
    private final HashMap<FileId,FSE> fmap = new HashMap<FileId,FSE>();
    private final FSE root;
    
    public LinkFS(Path path) throws IOException {
        //super(VolumeFlags.SIMPLE_FLAG);
        this.pathToReflect = path;
        root = new FSE(path);
    }

    public final Path getPathToReflect() {
        return pathToReflect;
    }


    
    public final void capacity(final Capacity capacity) throws Exception {
        capacity.complete(JPfmError.SUCCESS, 1024*1024*100, 1024*1024*50);
    }

    @Override
    public final void close(final Close close) throws Exception {
        //System.out.println(close);
    }

    @Override
    public final void control(final Control control) throws Exception {
        System.out.println(control);
        control.complete(JPfmError.FAILED, 0);
    }

    @Override
    public final void delete(final Delete delete) throws Exception {
        System.out.println(delete);
        delete.complete(JPfmError.ACCESS_DENIED);
    }

    @Override
    public final void flushFile(final FlushFile flushFile) throws Exception {
        System.out.println(flushFile);
        flushFile.complete(JPfmError.SUCCESS);
    }

    @Override
    public final void flushMedia(final FlushMedia flushMedia) throws Exception {
        //System.out.println(flushMedia);
        flushMedia.complete(JPfmError.SUCCESS,FlushMedia.INDEFINITE_FLUSH_DELAY);
    }

    @Override
    public final void list(final List list) throws Exception {
        //System.out.println("+++list+++");
        //System.out.println(list);
        //System.out.println(fmap);
        FSE fap = null;
        fap = fmap.get(list.getFileId());//(Node)getFileAttributes(list.getFileId());
        if(fap==null){
            list.complete(JPfmError.NOT_FOUND, true);
            //System.out.println(" not found ");
            //System.out.println("----list----");
            return;
        }
        if(fap.getFileType()!=FileType.FOLDER){
            list.complete(JPfmError.ACCESS_DENIED, true); // not a file
            System.out.println("access denied ");
            System.out.println("----list----");
            return;
        }
        

        Iterator<Path> it = 
                Files.newDirectoryStream(fap.getPath()).iterator();
        while(it.hasNext()){
            FSE nextFse = new FSE(it.next(),fap);
            //filedescriptor for these FSE will be set when they are opened
            //but we set a fake one
            nextFse.setFileDescriptor(FileId.INVALID);

            //now time to set this fse to the native directory list
            //System.out.println("adding "+nextFse);
            list.add(nextFse);

            //this fse shall not be added to 
        }
        
        //System.out.println("----list----");
        list.complete(JPfmError.SUCCESS, true);
        //todo
    }

    /*@Override
    public final void listEnd(ListEnd listEnd) throws Exception {
        //todo
    }*/

    @Override
    public final void mediaInfo(final MediaInfo mediaInfo) throws Exception {
        System.out.println(mediaInfo);
        mediaInfo.complete(JPfmError.SUCCESS,null,"LinkFS");
    }

    @Override
    public final void move(final Move move) throws Exception {
        System.out.println(move);
        //FSE moveDestination = new FSE(pathToReflect);
        FSE fileToMove = (FSE)getFileAttributes(move.getSourceFileId());
        if(fileToMove==null){
            move.complete(JPfmError.NOT_FOUND,false,null,null,null,null);
            return;
        }
        FSE fileToMoveDestinationParent = null;
        
        Path destinationPath=pathToReflect;
        Path destinationParentPath=pathToReflect;
        for (int i = 0; i < move.getTargetName().length; i++) {
            try{
                destinationPath = destinationPath.resolve(move.getTargetName()[i]);
                if(i<move.getTargetName().length-1)
                    destinationParentPath = destinationParentPath.resolve(move.getTargetName()[i]);
            }catch(InvalidPathException ipe){
                ipe.printStackTrace(System.out);
                move.complete(JPfmError.ACCESS_DENIED,false,null,null,null,null);
                return;
            }
        }
        destinationPath = destinationPath.toAbsolutePath();
        destinationParentPath = destinationParentPath.toAbsolutePath();

        Iterator<FSE>itmap = fmap.values().iterator();
        while(itmap.hasNext() && (fileToMoveDestinationParent==null)){
            FSE fse = itmap.next();
            if(fse.getPath().equals(destinationParentPath)){
                 fileToMoveDestinationParent = fse;break;
            }
        }
        if(fileToMoveDestinationParent==null){
            move.complete(JPfmError.NOT_FOUND, Files.exists(destinationPath), fileToMove, fileToMove.getName(), AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
            return;
        }

        fileToMove.setParent(fileToMoveDestinationParent);

        if(Files.exists(destinationPath)){
            move.complete(JPfmError.SUCCESS,true,fileToMove,fileToMove.getName(),AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
            return;
        }
        try{
            Files.move(fileToMove.getPath(), destinationPath,StandardCopyOption.ATOMIC_MOVE);
        }catch(Exception any){
            any.printStackTrace(System.out);
            move.complete(JPfmError.FAILED,false,fileToMove,fileToMove.getName(),AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
        }

        fileToMove.setPath(destinationPath);
        //moveDestination==null definitely
        fileToMove.setFileDescriptor(move.getNewExistingFileId());
        move.complete(JPfmError.SUCCESS,false,fileToMove,fileToMove.getName(),AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
    }

    @Override
    public final void moveReplace(final MoveReplace moveReplace) throws Exception {
        System.out.println(moveReplace);
        moveReplace.complete(JPfmError.ACCESS_DENIED);
    }

    @Override
    public final void open(final Open open) throws Exception {
        //if(makrOpen.getFileType() == FileType.NONE) ==> this makrOpen is a create operation
            /*System.out.print("\t\tcreate ");
            System.out.println(makrOpen.getNewCreateFileDescriptor());
            System.out.print("\t\texisting ");
            System.out.println(makrOpen.getNewExistingFileDescriptor());*/
        Path path = pathToReflect;
        Path parentPath = pathToReflect;
        for (int i = 0; i < open.getName().length; i++) {
            try{
                path  = path.resolve(open.getName()[i]);
            }catch(InvalidPathException ipe){
                //ipe.printStackTrace(System.out);
                open.complete(JPfmError.BAD_NAME, false, AccessLevel.READ_DATA, FileControlFlag.NONE, null);
                return;
            }
            if(i<open.getName().length - 1)
                parentPath = path.resolve(open.getName()[i]);
        }
        path = path.toAbsolutePath();
        parentPath = parentPath.toAbsolutePath();
        FSE fileap = null;// = getFileAttributes(path);
        FSE fapParent = null;

        if(open.getName().length == 0){//check root
            fileap = root;
            if(fmap.size()==0){
                FileId rootFileId = open.getNewExistingFileId();
                root.setFileDescriptor(rootFileId);
                fmap.put(rootFileId, root);                
            }
        }
        else{
            Iterator<FSE>itmap = fmap.values().iterator();
            while(itmap.hasNext() && (fileap==null && fapParent == null) ){
                FSE fse = itmap.next();
                if(fse.getPath().equals(path)){
                    fileap = fse;
                }
                if(fse.getPath().equals(parentPath)){
                    fapParent = fse; 
                }
            }
        }
        //If the indicated file does not exist and the newCreateOpenId parameter is zero then the
        //formatter should return pfmErrorNotFound.
        //If the indicated file does not exist and the newCreateOpenId parameter is non-zero
        //then the formatter should create the file.
        boolean existed = true;
        if(fileap==null){
            if(!Files.exists(path)){//indicated file does not exist
                if(!open.getNewCreateFileId().isValid()){//the newCreateOpenId parameter is zero
                    open.complete(JPfmError.NOT_FOUND, true,AccessLevel.OWNER, FileControlFlag.FORCE_UNBUFFERED, null);
                    return;
                }else{//newCreateOpenId parameter is non-zero => create
                    if(fapParent==null){
                        //parent does not exist, not possible to create file
                        open.complete(JPfmError.BAD_NAME, true,AccessLevel.OWNER, FileControlFlag.FORCE_UNBUFFERED, null);
                        return;
                    }
                    fileap = new FSE(path, fapParent);
                    try{
                        if(open.getFileType()==FileType.FILE){
                            Files.createFile(path);
                        }else if(open.getFileType()==FileType.FOLDER){
                            Files.createDirectory(path);
                        }else {
                            open.complete(JPfmError.ACCESS_DENIED,false,null,null,null);
                            return;
                        }
                    }catch(Exception any){
                        if(!open.isCompleted())open.complete(JPfmError.ACCESS_DENIED,false,null,null,null);
                        return;
                    }
                    fmap.put(fileap.getFileDescriptor().getFileId(), fileap);
                    existed = false;
                }
                fileap.setFileDescriptor(open.getNewCreateFileId() );
            }else {
                fileap = new FSE(path, fapParent);
                fileap.setFileDescriptor(open.getNewExistingFileId());
                fmap.put(fileap.getFileDescriptor().getFileId(), fileap); existed = true;
            }
            
        }else if(fileap.getFileDescriptor() == null) {
            fileap.setFileDescriptor(open.getNewExistingFileId());
        }

        System.out.print("\t\topenfds{");

        System.out.print(fileap.getFileDescriptor());
        if(fileap!=root)
            System.out.print(fileap.getParentFileDescriptor());
        System.out.println("}openfds");

        // todo : specify actual access level
        open.complete(JPfmError.SUCCESS, existed, AccessLevel.OWNER, FileControlFlag.FORCE_UNBUFFERED, fileap);
    }

    @Override
    public final void read(final Read read) throws Exception {
        FSE fileToRead = (FSE)getFileAttributes(read.getFileId());
        if(fileToRead==null){
            read.complete(JPfmError.NOT_FOUND,0,LinkFSReadCompleter.INSTANCE);
            return;
        }
        fileToRead.read(read);
        //todo
    }

    @Override
    public final void replace(final Replace replace) throws Exception {
        System.out.println(replace);
        replace.complete(JPfmError.ACCESS_DENIED,null,null,null);
    }

    @Override
    public final void setSize(final SetSize setSize) throws Exception {
        System.out.println(setSize);
        FSE fileToResize = (FSE)getFileAttributes(setSize.getFileId());
        if(fileToResize==null){
            setSize.complete(JPfmError.NOT_FOUND);
            return;
        }
        fileToResize.setSize(setSize.getFileSize());
        setSize.complete(JPfmError.SUCCESS);
        //setSize.complete(JPfmError.ACCESS_DENIED);
    }

    @Override
    public final void write(final Write write) throws Exception {
        FSE fileToWrite = (FSE)getFileAttributes(write.getFileId());
        if(fileToWrite==null){
            write.complete(JPfmError.NOT_FOUND,0,null);
            return;
        }
        fileToWrite.write(write);
    }

    @Override
    public final FileAttributesProvider getFileAttributes(FileId fileid) {
        System.out.println("++fmap++");
        System.out.println(fmap);
        System.out.println("--fmap--");
        System.out.println("getAttribs for "+fileid);
        return fmap.get(fileid);
        //return Util.getFileAttributes(files, descriptor);
    }

    /*protected <FS extends BasicFileSystem> void cascadeMount(String[] mountLocation, FileSystemInstanceProvider<FS> fsProvider) {
        throw new UnsupportedOperationException("Not supported yet.");
    }*/

    public FileAttributesProvider open(String[] filePath) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void open(FileAttributesProvider fap) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public DirectoryStream list(FileId folderToList) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void close(FileId file) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void delete(FileId fileToDelete) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public long capacity() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public FileAttributesProvider getRootAttributes() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public ASYNCHRONOUS getType() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /*protected FSE getFileAttributes(Path path) {
        for(Iterator<FSE> it = files.iterator(); it.hasNext();) {
            FSE fileAttributesProvider = it.next();
            if(fileAttributesProvider instanceof File){
                if(
                        ((File)fileAttributesProvider).getPath().equals(path)
                        ){
                    return fileAttributesProvider;
                }
            }else if(
                        ((Node)fileAttributesProvider).getPath().equals(path)
                    ){
                return fileAttributesProvider;
            }
        }return null;
    }*/

    /*private final Path getAsPath(final String[]fileName){
        Path ret = root.getPath();
        for (int i = 0; i < fileName.length; i++) {
            ret = ret.resolve(fileName[i]);
        }return ret;
    }*/

    private static final class LinkFSReadCompleter implements Completer {
        private static LinkFSReadCompleter INSTANCE = new LinkFSReadCompleter();
        private LinkFSReadCompleter(){}
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[] getStackTrace() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }


}
