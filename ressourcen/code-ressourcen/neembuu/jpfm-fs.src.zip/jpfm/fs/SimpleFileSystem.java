/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or ied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   SeFileSystem.java
 * Author: Shashank Tulsyan
 */
package jpfm.fs;

import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileId;
/*import jpfm.JPfmFileSystem;
import jpfm.JPfmBasicFileSystem;*/
import jpfm.VolumeFlags;
import jpfm.fs.Type.ASYNCHRONOUS;
import jpfm.operations.Capacity;
import jpfm.operations.Close;
import jpfm.operations.Control;
import jpfm.operations.Delete;
import jpfm.operations.FlushFile;
import jpfm.operations.FlushMedia;
import jpfm.operations.List;
import jpfm.operations.MediaInfo;
import jpfm.operations.Move;
import jpfm.operations.MoveReplace;
import jpfm.operations.Open;
import jpfm.operations.Read;
import jpfm.operations.Replace;
import jpfm.operations.SetSize;
import jpfm.operations.Write;

/**
 * Abstract volumes are case insensitive,
 * In future will have write capabilities as well. For now this is same
 * as {@link SeReadOnlyFileSystem }
 * @author Shashank Tulsyan
 */
public class SimpleFileSystem
        implements AsynchronousFileSystem
        //extends JPfmFileSystem
    {

    public DirectoryStream rootDirectoryStream;


    public SimpleFileSystem(final VolumeFlags volumeFlags, DirectoryStream rootDirectoryStream) {
        //super(volumeFlags);
        this.rootDirectoryStream = rootDirectoryStream;
    }

    @Override
    public void capacity(Capacity capacity) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void close(Close close) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void control(Control control) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void delete(Delete delete) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void flushFile(FlushFile flushFile) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void flushMedia(FlushMedia flushMedia) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void list(List list) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void mediaInfo(MediaInfo mediaInfo) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void move(Move move) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void moveReplace(MoveReplace moveReplace) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void open(Open open) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void read(Read read) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void replace(Replace replace) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void setSize(SetSize setSize) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void write(Write write) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FileAttributesProvider getFileAttributes(FileId fileDescriptor) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
    /*public <FS extends JPfmBasicFileSystem> void cascadeMount(String[] mountLocation, FileSystemInstanceProvider<FS> fsProvider) {
        throw new UnsupportedOperationException("Not supported yet.");
    }*/

    public ASYNCHRONOUS getType() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
