/*
 *  Copyright 2010 ShashankTulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs;

import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.LinkedList;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileId;
import jpfm.FileType;
//import jpfm.JPfmBasicFileSystem;
import jpfm.MountListener;
import jpfm.fs.Type.BASIC;
import jpfm.mount.Mount;
import jpfm.mount.MountParams;
import jpfm.mount.MountParamsBuilder;
import jpfm.mount.Mounts;
import jpfm.operations.Read;
import jpfm.volume.VeryBigFile;

/**
 * Demonstrates infitely deep directory structure
 * @author Shashank Tulsyan
 */
public class InfinitelyDeepFS
        implements
            DirectoryStream,
            FileAttributesProvider,
            BasicFileSystem{
    LinkedList<FileAttributesProvider> root;
    FileDescriptor fileDescriptor = new FileDescriptor();
    VeryBigFile veryBigFile;

    public InfinitelyDeepFS() {
        root = new LinkedList<FileAttributesProvider>();
        root.add(this);
        veryBigFile = new VeryBigFile(this);
        root.add(veryBigFile);
    }



    @Override
    public FileAttributesProvider getRootAttributes() {

        return this;
    }

    @Override
    public FileAttributesProvider open(String[] filePath) {
        if(filePath[filePath.length-1].equals(veryBigFile.getName()))
            return veryBigFile;
        return this;
    }

    @Override
    public void open(FileAttributesProvider descriptor) {
        
    }

    @Override
    public FileAttributesProvider getFileAttributes(FileId fileDescriptor) {
        if(veryBigFile.getFileDescriptor().implies(fileDescriptor))
            return veryBigFile;
        return this;
    }

    @Override
    public DirectoryStream list(FileId folderToList) {
        return this;
    }

    //@Override
    public int read(FileId file, long offset, ByteBuffer directByteBuffer) {
        return veryBigFile.read(offset, directByteBuffer);
    }

    @Override
    public void close(FileId file) {
        return;
    }

    @Override
    public void delete(FileId fileToDelete) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public long capacity() {
        return 0;
    }

    public Iterator<FileAttributesProvider> iterator() {
        return root.iterator();
    }

    public FileType  getFileType() {
        return FileType.FOLDER ;
    }

    public FileDescriptor getFileDescriptor() {
        return  fileDescriptor;
    }

    public long getFileSize() {
        return 0;
    }

    public long getCreateTime() {
        return 0;
    }

    public long getAccessTime() {
        return 0;
    }

    public long getWriteTime() {
        return 0;
    }

    public long getChangeTime() {
        return 0;
    }

    public String getName() {
        return "directory";
    }

    public FileDescriptor getParentFileDescriptor() {
        return fileDescriptor;
    }

    @Override
    public FileFlags getFileFlags() {
        return new FileFlags.Builder().build();
    }

    @Override
    public void read(Read read) throws Exception {
        veryBigFile.read(read);
    }

    @Override
    public Mount cascadeMount(BasicCascadableProvider basicCascadable) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public BASIC getType() {
        return null;
    }

    /*@Override
    public <FS extends JPfmBasicFileSystem> void cascadeMount(String[] mountLocation, FileSystemInstanceProvider<FS> fsProvider) {
        throw new UnsupportedOperationException("Not supported yet.");
    }*/

}
