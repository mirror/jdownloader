/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   SplitFS.java
 * Author: Shashank Tulsyan
 */
package jpfm.fs.splitfs;

import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileId;
import jpfm.FileType;
import jpfm.FormatterEvent;
import jpfm.JPfmError;
import jpfm.MountListener;
import jpfm.annotations.NonBlocking;
import jpfm.fs.BasicCascadableProvider;
import jpfm.fs.BasicFileSystem;
import jpfm.fs.ReadOnlyRawFileData;
import jpfm.fs.Type.BASIC;
import jpfm.mount.Mount;
import jpfm.operations.AlreadyCompleteException;
import jpfm.operations.Read;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public final class CascadableSplitFS
        implements
            BasicFileSystem,
            DirectoryStream {

    private ReadOnlyRawFileData[] partFiles = null;
    private long[] fileSizes = null;
    private long[] cumulativeSize = null;
    private Root root = null;
    private File file = null;
    private long volumeSize = 0;
    //private final String startName;
    //private final Path directory;

    static {
        //JPfmBasicFileSystem.registerFileSystem(SplitFSInstanceProvider.getInstance());
    }

    public static final class CascadableSplitFSProvider implements BasicCascadableProvider {
        private final Set<FileAttributesProvider> filesCascadingOver;
        private final String suggestedName;

        public CascadableSplitFSProvider(
                Set<FileAttributesProvider> filesCascadingOver,
                String suggestedName){
            this.filesCascadingOver = filesCascadingOver;
            this.suggestedName = suggestedName;
        }

        public BasicFileSystem getFileSystem(Set<ReadOnlyRawFileData> dataProviders, FileDescriptor parentFD) {
            return new CascadableSplitFS(dataProviders,suggestedName, parentFD);
        }

        public Set<FileAttributesProvider> filesCascadingOver() {
            return filesCascadingOver;
        }

        public int suggestDataGlimpseSize() {
            return 0;
        }

        public String suggestedName() {
            return suggestedName;
        }
        
    }

    public CascadableSplitFS(
            Set<ReadOnlyRawFileData> datas, String suggestedName,
            FileDescriptor parentFD) {
        partFiles = datas.toArray(new ReadOnlyRawFileData[datas.size()]);
        Arrays.sort(partFiles, new Comparator<ReadOnlyRawFileData>(){

            public int compare(ReadOnlyRawFileData o1, ReadOnlyRawFileData o2) {
                return o1.getName().compareTo(o2.getName());
            }

        });

        if (!getAllFileSizes());//should we do something for this error?

        // all names should follow the hjsplit nomenclature
        String name = partFiles[0].getName();

        root = new Root(suggestedName,parentFD,this);
        file = new File(volumeSize, name.substring(0, name.lastIndexOf('.')), root);

        System.out.println("++++++++++Cumulative Size info++++++++++++");
        for (int i = 0; i < cumulativeSize.length; i++) {
            System.out.println("["+(i+1)+"]"+cumulativeSize[i]);
        }
        System.out.println("---------Cumulative Size info------------");
    }

    public final boolean getAllFileSizes() {
        volumeSize = 0;
        synchronized (this) {
            if (partFiles == null) {
                return false;
            }
            fileSizes = new long[partFiles.length];
            cumulativeSize = new long[partFiles.length];
            for (int i = 0; i < partFiles.length; i++) {
                try {
                    fileSizes[i] = partFiles[i].getFileSize();
                    if(i==0) cumulativeSize[0]=0+fileSizes[0];
                    else cumulativeSize[i]=cumulativeSize[i-1]+fileSizes[i];
                    volumeSize += fileSizes[i];
                } catch (Exception a) {
                    a.printStackTrace();
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public FileAttributesProvider getRootAttributes() {
        return root;
    }

    @Override
    public FileAttributesProvider open(String[] filePath) {
        if (filePath.length > 1) {
            return null;
        }
        if (filePath.length == 0) {
            return root;//this line is not required
        }
        if (filePath[0].equalsIgnoreCase(file.getName())) {
            return file;
        }
        return null;
    }

    @Override
    public void open(FileAttributesProvider descriptor) {
    }

    @Override
    public FileAttributesProvider getFileAttributes(jpfm.FileId fileId) {
        if (root.implies(fileId)) {
            return root;
        }
        if (file.implies(fileId)) {
            return file;
        }
        return null;//should never happen, but actually there are applications (for instance tortoise svn) that will makrOpen file
    }

    @Override
    public DirectoryStream list(jpfm.FileId folderToList) {
        return this;
    }

    @Override
    public void close(jpfm.FileId file) {
        // not required in this case
    }

    @Override
    public long capacity() {
        if (volumeSize == 0) {
            if (!getAllFileSizes()) {
                return 0;
            }
        }
        return volumeSize;
    }

    @Override
    public void delete(FileId fileToDelete) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /*@Override
    public <FS extends JPfmBasicFileSystem> void cascadeMount(String[] mountLocation, FileSystemInstanceProvider<FS> fsProvider) {
        throw new UnsupportedOperationException("Not supported yet.");
    }*/

    public BASIC getType() {
        return null;
    }

    public Mount cascadeMount(BasicCascadableProvider basicCascadable) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private static final class SplitFSReadCompleter implements Completer {
        private static SplitFSReadCompleter INSTANCE = new SplitFSReadCompleter();
        private SplitFSReadCompleter(){}
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[] getStackTrace() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }


    //+++++++++++Directory Stream ++++++++
    public Iterator<FileAttributesProvider> iterator() {
        return new RootIterator(file);
    }

    public FileType getFileType() {
        return root.getFileType();
    }

    public FileDescriptor getFileDescriptor() {
        return root.getFileDescriptor();
    }

    public long getFileSize() {
        return root.getFileSize();
    }

    public long getCreateTime() {
        return root.getCreateTime();
    }

    public long getAccessTime() {
        return root.getAccessTime();
    }

    public long getWriteTime() {
        return root.getWriteTime();
    }

    public long getChangeTime() {
        return root.getChangeTime();
    }

    public String getName() {
        return root.getName();
    }
    //never invoked
    public FileDescriptor getParentFileDescriptor() {
        return root.getFileDescriptor();
    }

    public FileFlags getFileFlags() {
        return null;
    }

    @NonBlocking(usesJava1_7NIOClasses=true)
    @Override
    public void read(Read read) throws Exception {
        if (!file.implies(read.getFileId())) {
            read.complete(JPfmError.SUCCESS, 0, SplitFSReadCompleter.INSTANCE);
            return ;//0;
        }

        if (volumeSize == 0) {
            if (!getAllFileSizes()) {
                read.complete(JPfmError.END_OF_DATA, 0, SplitFSReadCompleter.INSTANCE);
                return ;//-1;
            }
        }

        long sizeSum = 0;
        /*
         * The offset of the first file that contains data required
         * to satisfy this read request.
         * Mostly a request lies in one split file only, but sometimes
         * it may lie at the end border of one and start of the next.
         */
        long firstFileOffset = 0;
        long currentFileSize = 0;

        int startIndex = -1;
        for (int i = 0; i < fileSizes.length && (startIndex == -1); i++) {
            currentFileSize = fileSizes[i];
            sizeSum += currentFileSize;
            if (sizeSum > read.getFileOffset()) {
                startIndex = i;
                firstFileOffset = sizeSum - currentFileSize;
            }
        }

        if (startIndex == -1) {
            read.complete(JPfmError.END_OF_DATA, 0, SplitFSReadCompleter.INSTANCE);
            return;//-1;
        }

        // we will handle only the first part of for the request
        if(read.getFileOffset() + read.getByteBuffer().capacity() > sizeSum) {
            /////////////////////////////////////////// request lies in single file///////////////////////
            // implies that request span in more than one file
            /////////////////////////////////////////// request lies in single file///////////////////////
            int lastIndex = startIndex;
            long lastOffset = read.getFileOffset() + read.getByteBuffer().capacity() - 1 ;

            for(int i = startIndex; i < cumulativeSize.length; i++){
                // 0->99 100->199 200->299
                //1) req = 198+>2  lastoffset = ->199 lies entirely in file 2
                //2) req = 198+>3 lastoffset = ->200 some part lies in file 3
                if(lastOffset < cumulativeSize[i]){
                    lastIndex = i; break;
                }
            }

            

            int[]expectedSize = new int[lastIndex-startIndex+1];

            //loop for finding expectedSize of individual splitted reads
            for (int i = startIndex; i <= lastIndex; i++) {
                if(i==startIndex) {
                    expectedSize[0] = (int)(cumulativeSize[i] - read.getFileOffset());
                }

            }

            for(int i = startIndex; i<=lastIndex; i++){
                if(i==startIndex) {
                    expectedSize[0] = (int)(cumulativeSize[i] - read.getFileOffset());
                }else {
                    // 0->99 100->199 200->299
                    //comparing offset with size, requires +1 for coversion of reference
                    //example when lastOffset is 200, and cumulative fileSize till there is 200,
                    // that would mean atleast one offset, that is 200, has to be read, instead of zero
                    if(lastOffset < cumulativeSize[i] ) {
                        expectedSize[i - startIndex] = (int)(lastOffset - cumulativeSize[i-1]  + 1);
                    }
                    else {
                        expectedSize[i - startIndex] = (int)(fileSizes[i]); //request spans over a entire file
                        // this case is unlikely to occur because files are usually very big,
                        // and every sane software requests small chunks (very small compared to file size)
                    }
                }
            }

            SplitRequestCompletionHandler new_splitreqcompletionHandler = new SplitRequestCompletionHandler(expectedSize,read);
            //System.out.println(new_splitreqcompletionHandler);
            read.setCompleter(new_splitreqcompletionHandler);

            int splitPoint = 0; sizeSum = 0 ;
            read.getByteBuffer().limit(read.getByteBuffer().capacity());//limit sometimes by default is 0
            //in such cases an exception is thrown. This is free ones mind from this trouble
            for(int i = startIndex; i<=lastIndex; i++) {
                // we slice to ensure independence of position of individual buffers
                // 0->99 100->199 200->299
                //1) req = 198+>2  lastoffset = ->199 lies entirely in file 2
                //2) req = 198+>3 ( 198->200 )  lastoffset = ->200 some part lies in file 3
                if(i==startIndex) {
                    read.getByteBuffer().limit(read.getByteBuffer().capacity());

                    //SplitedReadRequest part = new SplitedReadRequest(expectedSize[0], );
                    long referencePoint=0;
                    if(startIndex!=0)referencePoint = cumulativeSize[startIndex-1];


                    SplitedReadRequest part1 =

                            new SplitedReadRequest(
                                (
                                    ( (ByteBuffer)
                                        read.getByteBuffer().position(0).limit(
                                            (int)(
                                                cumulativeSize[startIndex] -
                                                read.getFileOffset()
                                            )
                                        )
                                    ).slice()
                                ), read.getFileOffset() - referencePoint,
                                new Integer(0), // index of request w.r.t. startIndex
                                new_splitreqcompletionHandler);

                    partFiles[startIndex].read(
                                part1
                    );
                } else {
                    read.getByteBuffer().limit(read.getByteBuffer().capacity());
                    SplitedReadRequest part2
                            = new SplitedReadRequest(
                                (ByteBuffer)(((ByteBuffer)read.getByteBuffer().position(splitPoint)).slice()).position(0),
                                0,
                                new Integer(i-startIndex), // index of request w.r.t. startIndex
                                new_splitreqcompletionHandler);
                    //System.out.println("part2="+part2);
                    partFiles[startIndex].read(
                                part2
                            );
                }
                splitPoint += expectedSize[i - startIndex];
            }
            read.getByteBuffer().position(0);
            //read.complete(splittedReadHandler);
        }else{
            /////////////////////////////////////////// request lies in single file///////////////////////
            
            try{
                partFiles[startIndex].read(
                        new jpfm.operations.readwrite.RequestWrapper(
                            read,
                            read.getFileOffset() - firstFileOffset)
                            //read//no need to use splitted read completion handler
                    //classic ReadCompletionHandler is sufficient and will also prevent
                    //unncessary object creation and memory usage
                );

            }catch(Exception exception){
                exception.printStackTrace(System.err);
                read.complete(JPfmError.FAILED,0,SplitFSReadCompleter.INSTANCE);
            }
        }
    }


//    private static final class SplittedReadHandler implements Future<Integer> {
//        private volatile boolean done = false;
//        private final Future[]futureReads;
//        private final int[]expectedReads;
//        private int final_result = 0;
//
//        public SplittedReadHandler(Future[] futureReads, int[] expectedReads) {
//            this.futureReads = futureReads;
//            this.expectedReads = expectedReads;
//        }
//        // this is implemented just the way sufficient
//        // the user of this is the Manager class inside jpfm.operations.ReadImpl,
//        // which checks isDone() before invoking get()
//        public final boolean cancel(boolean mayInterruptIfRunning) {
//            throw new UnsupportedOperationException("Not supported yet.");
//        }
//
//        public final boolean isCancelled() {
//            throw new UnsupportedOperationException("Not supported yet.");
//        }
//
//        public final boolean isDone() {
//            if(done)return true;
//            int result = 0; int futureRead_i = 0;
//            for (int i = 0; i < futureReads.length; i++) {
//                /*if(futureReads[i]==null){
//                    System.out.println("SplitFS 447");
//                    //continue;
//                }*/
//                if(!futureReads[i].isDone()){
//                    if(final_result != 0){
//                        for (int j = i; j < futureReads.length; j++){
//                            futureReads[j].cancel(true);
//                        }
//                        done = true;
//                        return true;
//                    }
//                    return false;
//                } else {
//                    try{
//                        futureRead_i = (Integer)futureReads[i].get();
//                    }catch(Exception an){
//                        an.printStackTrace();
//                    }
//                    if( futureRead_i < expectedReads[i] ){
//                        // the i_th read was lesser than expected value
//                        // so it is no point checking further
//                        // because the region holds value only as a continuous strip
//                        // it has no importance as a strip with voids.
//                        // the final result is the longest continuous strip from start
//                        final_result = result;
//                    } else {
//                        result += futureRead_i;
//                    }
//                }
//                final_result = result;
//            }
//            done = true;
//            return true;
//        }
//
//        public final Integer get() throws InterruptedException, ExecutionException {
//            if(!isDone())
//                throw new UnsupportedOperationException("Not done yet.");
//            return final_result;
//            /*int result = 0;
//            Integer toReturn = null;
//            for (int i = 0; i < futureReads.length; i++) {
//                result+=(Integer)futureReads[i].get();
//                if(futureReads[i]==null)continue;
//                if(toReturn==null){
//                    if(((Integer)futureReads[i].get()) < expectedReads[i])
//                        toReturn = result;
//                }else { //implies that the request further need to be cancled
//                    // it is useless concering with them
//                    // because a previous read was already less than the expected value
//                    futureReads[i].cancel(true);
//                }
//            }
//            return toReturn;*/
//        }
//
//        //should support
//        public final Integer get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
//            throw new UnsupportedOperationException("Not supported yet.");
//        }
//
//    }
    
    //not thread safe
    //in house implementation handled in single thread, so we do not bother with thread safety
    static final class SplitedReadRequest implements ReadRequest {
        private final ByteBuffer byteBuffer; //4
        private final long fileOffset; // 8
        private final AtomicBoolean completed = new AtomicBoolean(false);
        private final SplitRequestCompletionHandler splitRequestCompletionHandler;
        private final Integer myIndex;

        private final long creationTime = System.currentTimeMillis();
        private long completionTime = creationTime;

        public SplitedReadRequest(
                ByteBuffer byteBuffer,
                long fileOffset,
                Integer myIndex,
                SplitRequestCompletionHandler splitRequestCompletionHandler) {
            this.byteBuffer = byteBuffer;
            this.fileOffset = fileOffset;
            this.splitRequestCompletionHandler = splitRequestCompletionHandler;
            this.myIndex = myIndex;
        }

        @Override
        public String toString() {
            return "{offset="+fileOffset
                    + " ,size="+byteBuffer.capacity()
                    + " , myindex="+myIndex
                    + "}";
        }

        public void complete(JPfmError error, int actualRead, Completer completer) throws IllegalArgumentException, IllegalStateException {
            if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
                //we were expecting false, but it is true. implying it is already complete, throw an exception
                throw new AlreadyCompleteException();
            }
            completionTime = System.currentTimeMillis();
            if(error==JPfmError.SUCCESS)
                splitRequestCompletionHandler.completed(actualRead, myIndex);
            else
                splitRequestCompletionHandler.failed(new Throwable(error.toString()), myIndex);
        }

        public ByteBuffer getByteBuffer() {
            return byteBuffer;
        }

        public long getFileOffset() {
            return fileOffset;
        }

        public boolean isCompleted() {
            return completed.get();
        }

        public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
            complete(error,getByteBuffer().capacity(),null);
        }

        public void handleUnexpectedCompletion(Exception exception) {
            complete(JPfmError.FAILED, myIndex, splitRequestCompletionHandler);
        }

        public long getCreationTime() {
            return creationTime;
        }

        public long getCompletionTime() {
            if(!isCompleted())
                throw new IllegalStateException("Not completed yet");
            return completionTime;
        }

        public JPfmError getError() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void setCompleter(Completer completehandler) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public boolean canComplete(Completer completehandler) {
            return true;
        }
        
        public Completer getCompleter() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }

    //----------Directory Stream ---------
    private static final class RootIterator implements Iterator<FileAttributesProvider> {

        private File file;
        private boolean served = false;

        public RootIterator(File file) {
            this.file = file;
        }

        public boolean hasNext() {
            return !served;
        }

        public File next() {
            if (served) {
                return null;//should never happen
            }
            served = true;
            return file;
        }

        //never called
        public void remove() {
            throw new UnsupportedOperationException("Not supported yet.");
        }
    }

    public static boolean canManage(String name, java.nio.ByteBuffer volumeRawData, FileChannel volumeFileChannel) {
        if (name.endsWith(".001")) {
            return true;
        }
        return false;
    }

    /*public static JPfmBasicFileSystem create(
            String name,
            FileChannel volumeFileChannel,
            Path directory) {
        return new SplitFS(name, null, volumeFileChannel, directory);
    }*/

    private static String make3DigitString(int n) {
        int noDig = (int) Math.log10(n) + 1;
        String ret = "";
        int j = 0;
        for (; j < 3 - noDig; j++) {
            ret = ret + '0';
        }
        ret += n;
        return ret.toString();
    }


    private static class Unlocker
            implements MountListener {

        CountDownLatch latch;

        public Unlocker(CountDownLatch latch) {
            this.latch = latch;
        }

        public void eventOccurred(FormatterEvent event) {
            //occurred
            if (event.getEventType() == FormatterEvent.EVENT.DETACHED) {
                latch.countDown();
            }
        }
    }
}
