/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs.splitfs;

import java.nio.channels.CompletionHandler;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.JPfmError;
import jpfm.operations.Read;
import jpfm.operations.readwrite.Completer;

/**
 *
 * @author Shashank Tulsyan
 */
public final class SplitRequestCompletionHandler
        implements CompletionHandler<Integer, Integer>,Completer<Read>{
    private final int[]expectedReadSizes;
    private final int[]actualReadSizes;
    private final Read read;

    private final AtomicBoolean completed = new AtomicBoolean(false);

    /*package private*/SplitRequestCompletionHandler(final int[] expectedReadSizes,final Read read) {
        this.expectedReadSizes = expectedReadSizes;
        this.read = read;
        actualReadSizes = new int[expectedReadSizes.length];


        // we assume that atomic read requests wil be small
        // and never as big 2GB. 

        for (int i = 0; i < actualReadSizes.length; i++) {
            actualReadSizes[i]=Integer.MAX_VALUE;
        }
    }

    // assumptions :
    // completed and failed either one will be called only once for every splitted request
    // no other interfering program will interfer and fire fake completed/failed calls
    @Override
    public final void completed(final Integer result,final Integer indexOfRequestWrtStartIndex) {
        if(completed.get())return;
        //System.out.println("result"+result+" indexOfRequestWrtStartIndex="+indexOfRequestWrtStartIndex);
        actualReadSizes[indexOfRequestWrtStartIndex] = result;
        check();
    }

    @Override
    public final void failed(final Throwable exc,final Integer indexOfRequestWrtStartIndex) {
        if(completed.get())return;
        //System.out.println("failed result indexOfRequestWrtStartIndex="+indexOfRequestWrtStartIndex);
        actualReadSizes[indexOfRequestWrtStartIndex] = -2;
        check();
    }


    private void check(){
        int bytesFilledTillNow = 0;
        //completion in all successful cases will be a dicreet event
        //when an error occurs on the i_th split req, out of n reqs.
        //we are expected to return data obtained only till i-1_th req,
        //during this process completed might still be continued to be called
        //by i+1, i+2 ... and n-1 splits.
        for (int i = 0; i < actualReadSizes.length; i++) {
            if(actualReadSizes[i]==expectedReadSizes[i]){
                bytesFilledTillNow+=expectedReadSizes[i];
            }else if(actualReadSizes[i]<=0){//implies that an intermediate
                //request completed with failure and thus it is pointless
                //checking the others

                /////////////////////completing/////////////////////
                //System.out.println("completing");
                if(completed.compareAndSet(/*expect*/false,/*update*/ true)){
                    //actual !=expect
                    //=> already completed
                    return;
                }else{
                    if(bytesFilledTillNow==0)
                        read.complete(JPfmError.getJPfmErrorForNothingRead(),bytesFilledTillNow,this);
                    read.complete(JPfmError.SUCCESS,bytesFilledTillNow,this);
                    return;
                }
                /////////////////////completing/////////////////////
            }else {
                return;
            }
        }
        // implies completed with full success
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete,
            //an exception is not throwm because this is a security measure by the driver.
            //It will invoke forceComplete after invoking this to ensure if this function failed
            //it does not matter anymore, the driver just wants to quickly free the pending read request
            if(read.isCompleted()){
                //will surely happen ...  but still :P
                return;
            }
        }
        //thread safe hence forth
        //System.out.println("completing with "+read.getByteBuffer().capacity());
        //System.out.println("+++++buffercontents+++++");
        byte[]n=new byte[read.getByteBuffer().capacity()];
        for (int i = 0; i < expectedReadSizes.length; i++) {
            n[i]=read.getByteBuffer().get(i);
        }
        //System.out.println(new String(n));
        //System.out.println("-----buffercontents-----");
        read.complete(JPfmError.SUCCESS,read.getByteBuffer().capacity(),this);
    }

    public final Read getActualReadRequest() {
        return read;
    }

    @Override
    public final int getBytesFilledTillNow(Read pendingRequest) {
        if(pendingRequest!=this.read){
            throw new IllegalArgumentException("This SplitRequestCompletionHandler handles only requests that it" +
                    "was associated with during it\'s creation. Attempting to get info on some other pendingRequest");
        }
        int bytesFilledTillNow = 0;
        for (int i = 0; i < actualReadSizes.length; i++) {
            if(actualReadSizes[i]==expectedReadSizes[i]){
                bytesFilledTillNow+=expectedReadSizes[i];
            }else{
                break;
            }
        }
        return bytesFilledTillNow;
    }

    @Override
    public final void completeNow(Read pendingRequest) {
        if(pendingRequest!=this.read){
            throw new IllegalArgumentException("This SplitRequestCompletionHandler handles only requests that it" +
                    "was associated with during it\'s creation. Attempting to complete some other pendingRequest");
        }
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, 
            //an exception is not throwm because this is a security measure by the driver.
            //It will invoke forceComplete after invoking this to ensure if this function failed
            //it does not matter anymore, the driver just wants to quickly free the pending read request
        }
        //thread safe hence forth
        int bytesFilledTillNow = getBytesFilledTillNow(pendingRequest);
        if(bytesFilledTillNow==0)
            read.complete(JPfmError.getJPfmErrorForNothingRead(),bytesFilledTillNow,this);
        //read.complete(JPfmError.SUCCESS,bytesFilledTillNow,this);
        //the above ^^ would be meaningful if short read is supported
        //since it is not, we use the line below.
        //It has been found experimentally, but not ensured by us otherwise,
        //that the buffer passed is already zeroed. So the region unfilled
        //will not have possibly dangerous corrupt data, but zeros.
        read.complete(JPfmError.SUCCESS,read.getByteBuffer().capacity(),this);
    }

    @Override
    public final String toString() {
        return read.toString()+" "+getExpectedReadSize();
    }

    private String getExpectedReadSize(){
        String l="";
        for (int i = 0; i < expectedReadSizes.length; i++) {
            l = l +" "+ expectedReadSizes[i];
        }return l;
    }

    public StackTraceElement[] getStackTrace() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}