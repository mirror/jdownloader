/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   File.java
 * Author: Shashank Tulsyan
 */
package jpfm.fs.splitfs;

import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileType;

/**
 *
 * @author Shashank Tulsyan
 */
public class File
        extends FileDescriptor
        implements FileAttributesProvider {

    private final long size;
    private final String name;

    public File(long size, String name, Root parent) {
        super();
        this.size = size;
        this.name = name;
        this.parent = parent;
    }
    private final Root parent;

    public FileType getFileType() {
        return FileType.FILE;
    }

    public FileDescriptor getFileDescriptor() {
        return this;
    }

    public long getFileSize() {
        return size;
    }

    public long getCreateTime() {
        return 0;
    }

    public long getAccessTime() {
        return 0;
    }

    public long getWriteTime() {
        return 0;
    }

    public long getChangeTime() {
        return 0;
    }

    public String getName() {
        return name;
    }

    public FileDescriptor getParentFileDescriptor() {
        return parent.getFileDescriptor();
    }

    public FileAttributesProvider getTreeElementProperty() {
        return this;
    }

    public FileFlags getFileFlags() {
        return new FileFlags.Builder().setExecutable().setArchive().setNoIndex().setOffline().build();
    }


}
