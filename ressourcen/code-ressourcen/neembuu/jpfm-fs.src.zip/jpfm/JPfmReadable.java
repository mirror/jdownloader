/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   JPfmReadable.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.io.Closeable;
import java.nio.ByteBuffer;
import jpfm.annotations.Blocking;
import jpfm.annotations.MightBeBlocking;
import jpfm.operations.ReadImpl;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.volume.CascadableAbstractFile;

/**
 *
 * @author Shashank Tulsyan
 */
public interface JPfmReadable<R extends ReadRequest> extends Closeable{
    /**
     * Open is called every time the file is opened and also on other occasions .
     * The number of calls made to this function is greater than the number of times this 
     * file was opened or the number of live handles to this file.
     * However close function is called only once. <br/>
     * When this function is called, all resources required to serve data for this file must be opened.
     * If they are already open nothing needs to be done.
     */
    public void open();


    /**
     * This is called when all instances of the file have been closed.
     * The memory allocated and handles can be freed and FileDescriptor can be saved or forgotten whichever
     * is desired. (removing reference to FileDescriptor will free 40 bytes of memory  )
     * The implementation of this function for cascadable files is different 
     * from non-cascadable ones as it also checks {@link CascadableAbstractFile#isOpenByCascading() }.
     */
    public void close();

    @MightBeBlocking
    public void read(ReadRequest readRequest)throws Exception;
}
