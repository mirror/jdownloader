/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.jdk7;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.CompletionHandler;
import java.nio.channels.FileLock;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.FileAttributesProvider;
import jpfm.JPfmReadable;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.volume.AbstractFile;

/**
 *
 * @author Shashank Tulsyan
 */
public class JPfmAsynchronousFileChannel extends AsynchronousFileChannel {
    private final AbstractFile file;

    private final AtomicBoolean open = new AtomicBoolean(false);

    public JPfmAsynchronousFileChannel(AbstractFile file) {
        this.file = file;
    }


    @Override
    public long size() throws IOException {
        return file.getFileSize();
    }

    @Override
    public AsynchronousFileChannel truncate(long size) throws IOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void force(boolean metaData) throws IOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public <A> void lock(long position, long size, boolean shared, A attachment, CompletionHandler<FileLock, ? super A> handler) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Future<FileLock> lock(long position, long size, boolean shared) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FileLock tryLock(long position, long size, boolean shared) throws IOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    @SuppressWarnings(value="unchecked")
    public <A> void read(ByteBuffer dst, long position, A attachment, CompletionHandler<Integer, ? super A> handler) {
        try{
            file.read(new JPfmReadRequest(dst, position, attachment, handler));
        }catch(Exception any){
            handler.failed(any, attachment);
        }
    }

    @Override
    public Future<Integer> read(ByteBuffer dst, long position) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public <A> void write(ByteBuffer src, long position, A attachment, CompletionHandler<Integer, ? super A> handler) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Future<Integer> write(ByteBuffer src, long position) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void close() throws IOException {
        open.set(false);
        file.close();
    }

    public boolean isOpen() {
        return open.get();
    }

}
