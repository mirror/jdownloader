/*
 *  Copyright 2010 admin.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.jdk7;

import java.nio.ByteBuffer;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.JPfmError;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author admin
 */
public class JPfmReadRequest<A> implements ReadRequest {
    private final ByteBuffer byteBuffer;
    private final long fileOffset;
    private final A attachment;
    private final CompletionHandler<Integer, ? super A> completionHandler;
    private final AtomicBoolean completed = new AtomicBoolean(false);
    private JPfmError error;

    private final long creationTime;
    private int completionTime;

    public JPfmReadRequest(
            ByteBuffer byteBuffer,
            long fileOffset,
            A attachment,
            CompletionHandler<Integer, ? super A> completionHandler) {
        this.byteBuffer = byteBuffer;
        this.fileOffset = fileOffset;
        this.attachment = attachment;
        this.completionHandler = completionHandler;
        creationTime = System.currentTimeMillis();
    }

    public ByteBuffer getByteBuffer() {
        return  byteBuffer;
    }

    public Completer getCompleter() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setCompleter(Completer completehandler) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean canComplete(Completer completehandler) {
        return true;
    }

    public long getFileOffset() {
        return  fileOffset;
    }

    public void complete(JPfmError error, int actualRead, Completer completer)  {

        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw new IllegalStateException("Already complete");
        }

        this.error = error;

        if(error==JPfmError.SUCCESS)
            completionHandler.completed(actualRead, attachment);
        else {
            completionHandler.failed(error.getAsThrowable(), attachment);
        }

    }

    public boolean isCompleted() {
        return completed.get();
    }

    public void handleUnexpectedCompletion(Exception exception) {
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw new IllegalStateException("Already complete");
        }

        completionHandler.failed(exception, attachment);
    }

    public long getCreationTime() {
        return creationTime;
    }

    public long getCompletionTime() {
        return completionTime + creationTime;
    }

    public JPfmError getError() {
        return error;
    }

    public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
        complete(error, getByteBuffer().capacity() , null);
    }

}
