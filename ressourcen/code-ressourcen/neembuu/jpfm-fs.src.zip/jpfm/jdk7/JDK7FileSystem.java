/*
 *  Copyright 2010 admin.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.jdk7;

import java.io.IOException;
import java.nio.file.FileStore;
import java.nio.file.FileSystem;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.WatchService;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.nio.file.spi.FileSystemProvider;
import java.util.Collection;
import java.util.Set;
import jpfm.UnmountException;
import jpfm.fs.BasicFileSystem;
import jpfm.mount.Mount;

/**
 *
 * @author Shashank Tulsyan
 */
public class JDK7FileSystem extends FileSystem {
    private final BasicFileSystem fileSystem;
    private final Collection<Mount> mounts;

    public JDK7FileSystem(
            final BasicFileSystem fileSystem,
            final Collection<Mount> mounts
            ) {
        this.fileSystem = fileSystem;
        this.mounts = mounts;
    }    

    @Override
    public FileSystemProvider provider() {
        return JPfmFileSystemProvider.getInstance();
    }

    @Override
    public void close() throws IOException {
        // somehow unmount all instances
        for(Mount mount : mounts){
            try{
                mount.unMount();
            }catch(UnmountException exception){
                IOException ioe = new IOException(exception);
                throw ioe;
            }
        }
    }

    @Override
    public boolean isOpen() {
        for(Mount mount : mounts){
            if(mount.isMounted()){
                return true;
            }
        }return false;
    }

    @Override
    public boolean isReadOnly() {
        return true;//fileSystem.isReadOnly();
    }

    @Override
    public String getSeparator() {
        //
        //throw new UnsupportedOperationException("Not supported yet.");
        return null;
    }

    @Override
    public Iterable<Path> getRootDirectories() {
        // this would be just one for us.
        return null;
    }

    @Override
    public Iterable<FileStore> getFileStores() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Set<String> supportedFileAttributeViews() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Path getPath(String first, String... more) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public PathMatcher getPathMatcher(String syntaxAndPattern) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public UserPrincipalLookupService getUserPrincipalLookupService() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public WatchService newWatchService() throws IOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
