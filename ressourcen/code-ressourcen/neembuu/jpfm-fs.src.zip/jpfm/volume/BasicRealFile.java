/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   BasicRealFile.java
 * Author: Shashank Tulsyan
 */

package jpfm.volume;

import java.io.IOException;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributeView;
import java.util.concurrent.atomic.AtomicInteger;
import jpfm.DirectoryStream;
import jpfm.JPfmError;
import jpfm.annotations.NonBlocking;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.util.ReadCompletionHandler;

/**
 * @author Shashank Tulsyan
 */
@NonBlocking
final class BasicRealFile
        extends
            BasicCascadableAbstractFile
        implements
            RealFile {

    AsynchronousFileChannel fileChannel;Path realFile;
    private boolean cannotClose = false;

    private final AtomicInteger cascadeReferenceCount = new AtomicInteger(0);

    private static Path check(Path toCheck){
        if(!Files.exists(toCheck)){
            throw new IllegalArgumentException("Specified file does not exist. Path="+toCheck);
        }
        try{
            if(Files.getFileAttributeView(toCheck,BasicFileAttributeView.class).readAttributes().isDirectory()){
                throw new IllegalArgumentException("Specified file is a folder. Path="+toCheck);
            }
        }catch(IOException ioe){
            throw new IllegalArgumentException(ioe);
        }
        return toCheck;
    }

    public BasicRealFile(Path realFile, DirectoryStream fileContainer) throws IOException {
        super(check(realFile).getFileName().toString(),0,fileContainer,CommonFileAttributesProvider.DEFAULT);
        fileChannel = AsynchronousFileChannel.open(realFile, StandardOpenOption.READ);
        super.fileSize = fileChannel.size();this.realFile = check(realFile);
    }
    
    public BasicRealFile(Path realFile) throws IOException {
        this(realFile,null);
    }

    public synchronized void close() {
        if(cannotClose)return;
        try{
            fileChannel.close();
        }catch(Exception any){
            System.out.println("Error in closing channel. This error can be ignored ");
            any.printStackTrace();
        }
        return;
    }

    @NonBlocking(usesJava1_7NIOClasses=true)
    @SuppressWarnings(value="unchecked")
    public void read(ReadRequest read) throws Exception {
        if(!fileChannel.isOpen()){
            try{
                fileChannel = AsynchronousFileChannel.open(realFile, StandardOpenOption.READ);
            }catch(Exception any){
                //return JPfmBasicFileSystem.READ_END_OF_FILE;
                read.complete(JPfmError.END_OF_DATA, 0,new BasicRealFileCompleter());
                return;
            }
        }
        fileChannel.read(read.getByteBuffer(), read.getFileOffset(), read, ReadCompletionHandler.INSTANCE);
    }
    

    public void open() {
        
    }

    public final String getSourceFile() {
        return realFile.toAbsolutePath().toString();
    }




    private static final class BasicRealFileCompleter implements Completer {
        private final StackTraceElement[]stackTrace;
        private BasicRealFileCompleter(){
            stackTrace = new Throwable().getStackTrace();
        }
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[] getStackTrace() {
            return stackTrace;
        }

    }

    @Override
    public String toString() {
        return BasicRealFile.class.getName()+"{"+super.toString()+"}";
    }

}
