/*
 *  Copyright 2010 admin.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import jpfm.DirectoryStream;
import jpfm.JPfmError;
import jpfm.annotations.Blocking;
import jpfm.annotations.MightBeBlocking;
import jpfm.annotations.NonBlocking;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.util.ExceptionCompleter;

/**
 * It is same as BasicRealFile.
 * But used internally if runtime is below java7.
 * Wrap it around
 * File:   BasicRealFile.java
 * @author Shashank Tulsyan
 */
@Blocking
final class BasicRealFile_PreJava7
        extends BasicCascadableAbstractFile implements RealFile {
    RandomAccessFile randomAccessFile;
    File realFile;
    private boolean cannotClose = false;

    private final Object readLock = new Object();

    public BasicRealFile_PreJava7(File realFile, DirectoryStream fileContainer) throws IOException {
        super(realFile.getName(),0,fileContainer,CommonFileAttributesProvider.DEFAULT);
        super.fileSize = realFile.length();
        this.realFile = realFile;
        randomAccessFile = new RandomAccessFile(realFile, "r");
    }

    public BasicRealFile_PreJava7(File realFile) throws IOException {
        this(realFile,null);
    }

    /**
     * Suppose you opened a file and then eventually closed it when
     * close was called. Now suppose a mount was made on this file, sometime
     * after you opened the file, that is, the file is a virtual folder from now.
     * In such a case you cannot open this file again, because no file exists.
     * If you had not closed the file, you could have used it even after
     * a mount was made on it.
     * If you setCannotClose(true), then fileChannel is not closed even if all instances
     * of this file have been closed.
     * @param cannotClose
     */
    @Override
    public synchronized void setCannotClose(boolean cannotClose) {
        this.cannotClose = cannotClose;
    }

    @Override
    public synchronized void close() {

        //dispatchReadRequestsInOtherThread.close();

        if(cannotClose){
            return;
        }
        try{
            randomAccessFile.close();
            randomAccessFile = null;
        }catch(IOException exception){
            exception.printStackTrace(System.err);
        }
        

    }

    @NonBlocking(usesJava1_7NIOClasses=false)
    @Blocking(getReasonWhyItDoesNotMatter="Each request executed in other thread by DispatchReadRequestsInOtherThread if wrapped around DispatchReadRequestsInOtherThread")
    @MightBeBlocking(
        reason="Blocking inspite of each request being dispatched in"+
            "separated thread, if some type of fileSystem is mounted "+
            "on original source file, making it impossible to open extra read channels on that file.")
    @Override
    public void read(ReadRequest read) throws Exception {
        // Although we are already in a thread other than open, close
        // and other filesystem function, we share the read thread
        // with other files, so it would be best if we work in another
        // thread
        // dispatchReadRequestsInOtherThread.read(read);
        // this results in calling of readImpl
        // but from other thread, so if you are trying to
        // understand how this works, imply continue reading from
        // {@link #readImpl(ReadRequest) }
    
        // we shall attempt to make a separate
        // RandomAccessFile for each atomic request.
        // If it fails, it probably means that the mount
        // has been made on the source file itself.
        // In this case we try using the already open channel.
        // In the source of the file is real, then the blocking
        // nature of this function will not be apparent,
        // else it might give user a really bad experience.

        try{
            final RandomAccessFile perReadRandomAccessFile
                    = new RandomAccessFile(realFile, "r");

            /*new Thread(getName()+"_offset="+read.getFileOffset()){

                @Override
                public void run() {*/ // removed since DispatchReadRequestInOtherThread
            // has approach selection capability now
                    try{
                        perReadRandomAccessFile.seek(read.getFileOffset());
                        byte[]b= new byte[read.getByteBuffer().capacity()];
                        int actualRead = perReadRandomAccessFile.read(b);
                        read.getByteBuffer().put(b);
                        read.complete(
                            actualRead==-1 ? JPfmError.END_OF_DATA : JPfmError.SUCCESS,
                            actualRead,
                            null);
                        return;
                    }catch(IOException exception){
                        read.complete(
                            JPfmError.FAILED,
                            0, new ExceptionCompleter(exception));
                        return;
                    }
                /*}

            }.start();
            return;*/
        }catch(Exception any){
            // It probably means that the mount
            // has been made on the source file itself.
            any.printStackTrace();
            synchronized(readLock){
                try{
                    if(read.isCompleted())return;
                    randomAccessFile.seek(read.getFileOffset());
                    byte[]b= new byte[read.getByteBuffer().capacity()];
                    int actualRead = randomAccessFile.read(b);
                    read.getByteBuffer().put(b);
                    read.complete(
                        actualRead==-1 ? JPfmError.END_OF_DATA : JPfmError.SUCCESS,
                        actualRead,
                        null);
                    return;
                }catch(IOException ioe){
                    read.complete(
                            JPfmError.FAILED,
                            0, new ExceptionCompleter(ioe));
                    return;
                }
            }
        }
    }
    
    @Override
    public synchronized void open() {
        if(randomAccessFile==null){
            try{
                randomAccessFile = new RandomAccessFile(realFile, "r");
            }catch(Exception any){
                throw new RuntimeException(any);
            }
        }
        
    }

    @Override
    public String getSourceFile() {
        return realFile.getAbsolutePath();
    }

    @Override
    public String toString() {
        return BasicRealFile_PreJava7.class.getName()+"{"+super.toString()+"}";
    }
    
}