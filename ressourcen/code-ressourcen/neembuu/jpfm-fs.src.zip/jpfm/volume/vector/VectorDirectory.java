/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume.vector;

import jpfm.DirectoryStream;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.volume.CommonFileAttributesProvider;
import jpfm.volume.utils.StringMaker;

/**
 *
 * @author Shashank Tulsyan
 */
public class VectorDirectory
        extends VectorNode {
    protected String name;
    protected VectorNode parent;

    public VectorDirectory(String name, VectorNode parent) {
        this.name = name;
        this.parent = parent;
    }

    public VectorDirectory(String name, VectorNode parent, int initialCapacity, int capacityIncrement, CommonFileAttributesProvider attributesProvider) {
        //store = new Vector<DE>(initialCapacity, capacityIncrement);
        super(initialCapacity,capacityIncrement,attributesProvider);
        this.name = name;
        this.parent = parent;
    }

    public VectorDirectory(String name, VectorNode parent, CommonFileAttributesProvider attributesProvider) {
        super(10, 0, attributesProvider);
        this.parent = parent;
        this.name = name;
    }

    public final String getName() {
        return name;
    }

    public final FileDescriptor getParentFileDescriptor() {
        return parent.getFileDescriptor();
    }

    @Override
    public String toString() {
        return StringMaker.createString(this,super.fileDescriptor.toString());
        //return super.toString();
    }

    public VectorNode getParent() {
        return parent;
    }

    public FileFlags getFileFlags() {
        return new FileFlags.Builder().setExecutable().build();
    }
}
