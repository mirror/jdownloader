/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   VectorFileContainer.java
 * Author: Shashank Tulsyan
 */
package jpfm.volume.vector;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;

/**
 *
 * @author Shashank Tulsyan
 */
public interface VectorFileContainer
        extends
            DirectoryStream,
            FileAttributesProvider
        /*Modifiable//FileContainer<VFC, FileAttributesProvider>*/ {

    public long getDirectorySize();

    /**
     * @param name of the file/folder
     * @return Returns the file/folder with the given name in this directory.
     * Sub directories are not checked
     */
    public FileAttributesProvider get(String name);

    // <editor-fold defaultstate="collapsed" desc="Copied from java.util.Vector">
    boolean add(FileAttributesProvider e);

    void add(int index, FileAttributesProvider element);

    boolean addAll(Collection<? extends FileAttributesProvider> c);

    boolean addAll(int index, Collection<? extends FileAttributesProvider> c);

    void addElement(FileAttributesProvider obj);

    int capacity();

    void clear();

    Object clone();

    boolean contains(Object o);

    boolean containsAll(Collection<?> c);

    void copyInto(Object[] anArray);

    FileAttributesProvider elementAt(int index);

    Enumeration<FileAttributesProvider> elements();

    void ensureCapacity(int minCapacity);

    FileAttributesProvider firstElement();

    FileAttributesProvider get(int index);

    int indexOf(Object o);

    int indexOf(Object o, int index);

    void insertElementAt(FileAttributesProvider obj, int index);

    boolean isEmpty();

    Iterator<FileAttributesProvider> iterator();

    FileAttributesProvider lastElement();

    int lastIndexOf(Object o);

    int lastIndexOf(Object o, int index);

    ListIterator<FileAttributesProvider> listIterator();

    ListIterator<FileAttributesProvider> listIterator(int index);

    FileAttributesProvider remove(int index);

    boolean remove(Object o);

    boolean removeAll(Collection<?> c);

    void removeAllElements();

    boolean removeElement(Object obj);

    void removeElementAt(int index);

    boolean retainAll(Collection<?> c);

    FileAttributesProvider set(int index, FileAttributesProvider element);

    void setElementAt(FileAttributesProvider obj, int index);

    void setSize(int newSize);

    int size();

    List<FileAttributesProvider> subList(int fromIndex, int toIndex);

    Object[] toArray();

    <T> T[] toArray(T[] a);

    void trimToSize();// </editor-fold>
}
