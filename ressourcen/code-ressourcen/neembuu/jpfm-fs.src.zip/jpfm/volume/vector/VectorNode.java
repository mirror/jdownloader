/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume.vector;

import java.util.Iterator;
import java.util.Vector;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileType;
import jpfm.volume.CommonFileAttributesProvider;

/**
 *
 * @author Shashank Tulsyan
 */
public abstract class VectorNode 
        extends Vector<FileAttributesProvider>
        implements VectorFileContainer{

    protected final FileDescriptor fileDescriptor = new FileDescriptor();
    protected long createTime = 0;
    protected long accessTime = 0;
    protected long writeTime = 0;
    protected long changeTime = 0;

    public VectorNode(){
        super();
    }
    public VectorNode(int initialCapacity, int capacityIncrement, CommonFileAttributesProvider attributesProvider) {
        //store = new Vector<DE>(initialCapacity, capacityIncrement);
        super(initialCapacity,capacityIncrement);
        createTime = attributesProvider.getCreateTime();
        accessTime = attributesProvider.getAccessTime();
        writeTime = attributesProvider.getWriteTime();
        changeTime = attributesProvider.getChangeTime();
    }

    public VectorNode(CommonFileAttributesProvider attributesProvider) {
        this(10, 0, attributesProvider);
    }



    public long getDirectorySize() {
        long ret = 0;
        for (FileAttributesProvider element : this) {
            if (element instanceof VectorFileContainer) {
                ret += ((VectorFileContainer)element).getDirectorySize();
            } else {
                ret += element.getFileSize();
            }
        }
        return ret;
    }

    @Override
    public final FileType getFileType() {
        return FileType.FOLDER;
    }

    @Override
    public final FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    @Override
    public final long getFileSize() {
        return 0;
    }

    @Override
    public long getCreateTime() {
        return createTime;
    }

    @Override
    public long getAccessTime() {
        return accessTime;
    }

    @Override
    public long getWriteTime() {
        return writeTime;
    }

    @Override
    public long getChangeTime() {
        return changeTime;
    }

    /**
     * Check only the directory and not it's subdirectories.
     * Implementors of AccountDirectory might want to override
     * this method to add additional functionality.
     *
     * @param name
     * @return
     */
    public FileAttributesProvider get(String name, FileType fileType) {
        synchronized(this){
            // ensure that files are not added as we are searching
            Iterator<FileAttributesProvider> it = iterator();
            while(it.hasNext()){
                FileAttributesProvider next = it.next();
                if(next.getName().equalsIgnoreCase(name)){
                    if(fileType!=null){//also check filetype if specified
                        if(next.getFileType()==fileType)
                            return next;
                        else continue;
                    }
                    return next;
                }
            }
        }
        return null;
    }

    @Override
    public FileAttributesProvider get(String name) {
        return get(name,null);
    }
    
}
