/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume;

import jpfm.FileDescriptor;
import jpfm.annotations.NonBlocking;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.util.DispatchReadRequestsInOtherThread;

/**
 * A cascadable file is one which can be opened by both actual native filesystem
 * and also by this application instance directly (instead of first making it visible to filesystem
 * and then java requesting the native filesystem for handles to this file). <br/>
 * Cascading refers to mounting layers of virtual filesystem forming a virtual filesystem stack.
 * Cascading is intrinsically supported at the native filesystem level. Files in the native filesystem can be mounted
 * and then files inside the virtual filesystem can be mounted, thus virtual filesystem stack of arbitrary depth can be made.
 * However, when a virtual filesystem stack consists of filesystems written soley in java, then, all of them
 * are virtual stacked in the same java process, and only one filesystem is visible at the native level.
 * This saves a lot of system resources as all filesystem reside in a single process.
 * This is faster as the filesystem invocation calls are mostly in java and optimized by the vm, also
 * the calls go to the kernel level and back to userspace only once instead of a number of times.
 * 
 * @author Shashank Tulsyan
 */
@NonBlocking
public interface CascadableAbstractFile extends ReferenceProvider,AbstractFile {
    
    @Override
    void close();

    /**
     * All handles of a file might have been closed by the native filesystem. 
     * In such a case for the filedescriptor of this file {@link FileDescriptor#isOpen() } will return false.
     * This is to check if handles opened by this java process directly might still be open. 
     * The implementation of {@link AbstractFile#close()} function for cascadable files is different 
     * from non-cascadable ones as it also {@link #isOpenByCascading() }.
     * @return true iff atleast one cascade reference to this file is still open 
     */
    boolean isOpenByCascading();

    @Override
    void open();

    @Override
    @NonBlocking
    void read(ReadRequest read) throws Exception;

    /**
     * Suppose you opened a file and then eventually closed it when
     * close was called. Now suppose a mount was made on this file, sometime
     * after you opened the file, that is, the file is a virtual folder from now.
     * In such a case you cannot open this file again, because no file exists.
     * If you had not closed the file, you could have used it even after
     * a mount was made on it.
     * If you setCannotClose(true), then fileChannel is not closed even if all instances
     * of this file have been closed.
     * @param cannotClose
     */
    void setCannotClose(boolean cannotClose);

}
