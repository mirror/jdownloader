/*
 * Copyright 2011 Shashank Tulsyan.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jpfm.volume;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import jpfm.DirectoryStream;
import jpfm.AccessLevel;
import jpfm.FileId;
import jpfm.fs.ReadOnlyRawFileData;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.operations.readwrite.SimpleReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public abstract class BasicCascadableAbstractFile 
        extends BasicAbstractFile
        implements CascadableAbstractFile {
    
    private boolean cannotClose = false;
    private final AtomicInteger cascadeReferenceCount = new AtomicInteger(0);

    protected BasicCascadableAbstractFile(String name, long fileSize, DirectoryStream parent) {
        super(name, fileSize, parent);
    }

    protected BasicCascadableAbstractFile(String name, long fileSize, DirectoryStream parent, CommonFileAttributesProvider attributesProvider) {
        super(name, fileSize, parent, attributesProvider);
    }  
    
    @Override
    public boolean isOpenByCascading() {
        return cascadeReferenceCount.get()>0;
    }

    @Override
    public void setCannotClose(boolean cannotClose) {
        this.cannotClose = cannotClose;
    }

    @Override
    public ReadOnlyRawFileData getReference(FileId fileId, AccessLevel level) {
        cascadeReferenceCount.incrementAndGet();
        return new ROFileData(this, 10);
    }
    
    
    private static final class ROFileData implements ReadOnlyRawFileData {
        private final BasicCascadableAbstractFile basicRealFile;
        private final int suggestedDataGlimpseSize;
        private final AtomicBoolean open = new AtomicBoolean(false);

        public ROFileData(BasicCascadableAbstractFile basicRealFile, int suggestedDataGlimpseSize) {
            this.basicRealFile = basicRealFile;
            this.suggestedDataGlimpseSize = suggestedDataGlimpseSize;
            //opne the files, thsi will start the threads.
            basicRealFile.open();
            open.set(true);
        }

        @Override
        public ByteBuffer getDataGlimpse() {
            checkOpen();
            ByteBuffer buffer;
            if(suggestedDataGlimpseSize==0)
                buffer = ByteBuffer.allocate(10);
            else buffer =
                ByteBuffer.allocate(suggestedDataGlimpseSize);
            SimpleReadRequest srr
                    =  new SimpleReadRequest(buffer, 0);
            try{
                read(srr);
            }catch(Exception any){
                return buffer;
            }
            while(!srr.isCompleted()){
                try{
                    Thread.sleep(100);
                }catch(Exception any){

                }
            }
            return buffer;
        }

        @Override
        public String getName() {
            checkOpen();
            return basicRealFile.getName();
        }

        @Override
        public void read(ReadRequest readRequest) throws Exception {
            checkOpen();
            basicRealFile.read(readRequest);
        }

        @Override
        public long getFileSize() {
            checkOpen();
            return basicRealFile.getFileSize();
        }

        @Override
        public boolean isOpen() {
            return open.get();
        }
        
        private void checkOpen(){
            if(!isOpen()){
                throw new IllegalStateException("This ReadOnlyRawFileData has been closed, open a new one" );
            }
        }

        @Override
        public void close() {
            checkOpen();
            basicRealFile.cascadeReferenceCount.decrementAndGet();
        }
        
    }

}
