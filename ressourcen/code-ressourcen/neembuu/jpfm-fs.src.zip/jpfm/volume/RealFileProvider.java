/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume;

import java.io.IOException;
import jpfm.DirectoryStream;
import jpfm.SystemUtils;
import jpfm.operations.RequestHandlingApproach;
import jpfm.util.DispatchReadRequestsInOtherThread;

/**
 *
 * @author Shashank Tulsyan
 */
public final class RealFileProvider {

    public static RealFile getNonBlockingRealFile(
            String fileAbsolutePath)  throws IOException  {
        return getNonBlockingRealFile(fileAbsolutePath,null);
    }
    public static RealFile getNonBlockingRealFile(
                String fileAbsolutePath,
                DirectoryStream parent) throws IOException  {
        if(!SystemUtils.IS_JAVA_1_7){

            return new DispatchReadRequestsInOtherThread.Wrapper(
                            new BasicRealFile_PreJava7(new java.io.File(fileAbsolutePath)),
                                RequestHandlingApproach.BLOCKING,
                                parent);
        }else {
            // full written to avoid import
            // an permanent import to jdk7 classes would make the
            // class unresolvable in jdk6 and lower
            java.nio.file.Path path = java.nio.file.Paths.get(fileAbsolutePath);
            return new BasicRealFile(path, parent);
        }
    }
}
