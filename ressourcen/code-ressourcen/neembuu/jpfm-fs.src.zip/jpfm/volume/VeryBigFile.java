/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume;

import java.nio.ByteBuffer;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileType;
import jpfm.JPfmError;
import jpfm.annotations.NonBlocking;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public final class VeryBigFile
        extends FileDescriptor
        implements FileAttributesProvider , AbstractFile {
    public static final long SIZE = ((long)Integer.MAX_VALUE) * 5000;//Long.MAX_VALUE/10000;
    private final DirectoryStream parent ;
    private final String name;

    public VeryBigFile(DirectoryStream parentFileDescriptor) {
        this(parentFileDescriptor,"veryBigFile.youCannotOpenThisInAnything");
    }

    public VeryBigFile(DirectoryStream parentFileDescriptor, String name) {
        this.parent = parentFileDescriptor;
        this.name = name;
    }



    public FileType  getFileType() {
        return FileType.FILE ;
    }

    public FileDescriptor getFileDescriptor() {
        return this;
    }

    public long getFileSize() {
        return SIZE;
    }

    public long getCreateTime() {
        return 0;
    }

    public long getAccessTime() {
        return 0;
    }

    public long getWriteTime() {
        return 0;
    }

    public long getChangeTime() {
        return 0;
    }

    public String getName() {
        return name;
    }

    public FileDescriptor getParentFileDescriptor() {
        return parent.getFileDescriptor();
    }

    public FileAttributesProvider getTreeElementProperty() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @NonBlocking(usesJava1_7NIOClasses=false)
    public int read(long offset, ByteBuffer directByteBuffer) {
        int i=0;
        while(directByteBuffer.hasRemaining()){
            directByteBuffer.put((byte)(offset+i)); i++;
        }return directByteBuffer.capacity();
    }

    public void close() {
        
    }

    public DirectoryStream getParent() {
        return (DirectoryStream)parent;
    }

    public FileFlags getFileFlags() {
        return new FileFlags.Builder().build();
    }

    @NonBlocking(usesJava1_7NIOClasses=false)
    public void read(ReadRequest read) {
        System.gc();
        int i = 0;
        while(read.getByteBuffer().hasRemaining()){
            read.getByteBuffer().put((byte)(read.getFileOffset()+i)); i++;
        }
        read.complete(JPfmError.SUCCESS, read.getByteBuffer().capacity(), VeryBigFileCompleter.INSTANCE);
    }

    public void open() {
        
    }

    @Override
    public String toString() {
        return "VeryBigFile{"+super.toString()+"}";
    }

    private static final class VeryBigFileCompleter implements Completer {
        private static VeryBigFileCompleter INSTANCE = new VeryBigFileCompleter();
        private VeryBigFileCompleter(){}
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[] getStackTrace() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }

}
