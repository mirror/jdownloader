/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume;

import jpfm.DirectoryStream;
import jpfm.JPfmError;
import jpfm.operations.readwrite.ReadRequest;

/**
 * This is used for testing purposes only.
 * @author Shashank Tulsyan
 */
public final class RandomlyBlockingFile extends BasicAbstractFile {

    public static final String NAME = "randomfilefortesting.txt";

    public RandomlyBlockingFile(DirectoryStream parent) {
        super(
            NAME,
            (int)(Math.random()*1024*1024*10), // anything between 0 to 10MB
            parent
        );
    }

    public void open() {
        
    }

    public void close() {
        
    }

    public void read(ReadRequest read) throws Exception {
        if(Math.random()>0.5){
            System.out.println("Ignoring request ->"+read);
            //while(true)Thread.sleep(1000);
        }
        int i = 0;
        while(read.getByteBuffer().hasRemaining()){
            read.getByteBuffer().put((byte)(read.getFileOffset()+i)); i++;
        }
        read.complete(JPfmError.SUCCESS, read.getByteBuffer().capacity(), null);
    }

}
