/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   BasicAbstractFileWrap.java
 * Author: Shashank Tulsyan
 */
package jpfm.volume;

import jpfm.DirectoryStream;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileType;
import jpfm.volume.utils.StringMaker;

/**
 * One important fact about BasicAbstractFileWrap is that it cannot
 * be resized internally.
 * The difference in BasicAbstractFileWrap is that it can successfully
 * wrap other abstract file. Normal BasicAbstractFile will always
 * return it's own FileDescriptor and therefore cannot be used to wrap other
 * files.
 * @see BasicAbstractFile
 * @author Shashank Tulsyan
 */
public abstract class BasicAbstractFileWrap
        implements
            AbstractFile {

    protected final AbstractFile abstractFile;
    private final DirectoryStream parent;

    protected BasicAbstractFileWrap(AbstractFile abstractFile) {
        this(abstractFile,abstractFile.getParent());
    }

    protected BasicAbstractFileWrap(AbstractFile abstractFile, DirectoryStream parent) {
        this.abstractFile = abstractFile;
        this.parent = parent;
    }

    @Override
    public final FileType getFileType() {
        return FileType.FILE;
    }

    @Override
    public final FileDescriptor getFileDescriptor() {
        return abstractFile.getFileDescriptor();
    }

    @Override
    public long getFileSize() {
        return abstractFile.getFileSize();
    }

    @Override
    public long getCreateTime() {
        return abstractFile.getCreateTime();
    }

    @Override
    public long getAccessTime() {
        return abstractFile.getAccessTime();
    }

    @Override
    public long getWriteTime() {
        return abstractFile.getWriteTime();
    }

    @Override
    public long getChangeTime() {
        return abstractFile.getChangeTime();
    }

    @Override
    public String getName() {
        return abstractFile.getName();
    }

    @Override
    public FileDescriptor getParentFileDescriptor() {
        return getParent().getFileDescriptor();
    }

    @Override
    public DirectoryStream getParent() {
        return abstractFile.getParent();
    }

    @Override
    public String toString() {
        return StringMaker.createString(this,super.toString());
    }

    @Override
    public FileFlags getFileFlags() {
        return new FileFlags.Builder().build();
    }

/*    protected DirectoryStream parent;
    protected long createTime = 0;
    protected long accessTime = 0;
    protected long writeTime = 0;
    protected long changeTime = 0;*/
}
