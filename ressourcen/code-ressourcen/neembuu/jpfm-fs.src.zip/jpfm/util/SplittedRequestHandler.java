/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */
package jpfm.util;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import jpfm.JPfmError;
import jpfm.operations.AlreadyCompleteException;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public final class SplittedRequestHandler implements Completer<ReadRequest> {

    private final ReadRequest readRequestToSplit;
    private final ConcurrentLinkedQueue<SplittedRequest> splits = new ConcurrentLinkedQueue<SplittedRequest>();
    private int splitedTill = 0;
    private final Logger logger;
    private boolean completed = false;

    private SplittedRequestHandler(final ReadRequest readRequestToSplit, Logger l) {
        this.readRequestToSplit = readRequestToSplit;
        logger = l;
    }

    /*public static SplittedRequestHandler createSplittedRequestHandler(
            final ReadRequest readRequestToSplit) {
        return createSplittedRequestHandler(readRequestToSplit, Logger.getLogger(SplittedRequestHandler.class.getName()));
    }*/
    
    public static SplittedRequestHandler createSplittedRequestHandler(final ReadRequest readRequestToSplit, Logger logger) {
        synchronized (readRequestToSplit) {
            final SplittedRequestHandler handler = new SplittedRequestHandler(readRequestToSplit,logger);
            /*if(readRequestToSplit.getCompleter()!=null){
            throw new IllegalArgumentException("Readrequest already has a completer");
            }*/
            readRequestToSplit.setCompleter(handler);
            return handler;
        }
    }

    public boolean isSplittingCompleted() {
        return (splitedTill == readRequestToSplit.getByteBuffer().capacity());
    }

    public static int NUMBER_OF_VALUES = 30;

    public static final String generatePeekString(ByteBuffer byteBuffer) {

        StringBuilder sb = new StringBuilder(30 * 2 + 10);
        sb.append('{');
        for (int i = 0; i < NUMBER_OF_VALUES && i < byteBuffer.capacity(); i++) {
            sb.append(Integer.toHexString(byteBuffer.get(i)));
            sb.append(',');
        }
        sb.append('}');
        sb.append('{');
        byte[] b = new byte[NUMBER_OF_VALUES];
        byteBuffer.position(0);
        byteBuffer.get(b, 0,
                Math.min(NUMBER_OF_VALUES, byteBuffer.capacity()));
        for (int i = 0; i < b.length; i++) {
            if (!Character.isLetterOrDigit((char) b[i])) {
                b[i] = 32;
            }
        }
        sb.append(new String(b).replace('\n', ' '));
        sb.append('}');
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(1000);
        builder.append("SplittedRequest{\n");
        for (SplittedRequest request : splits) {
            builder.append(request);
            builder.append('\n');
        }
        builder.append("}");
        return super.toString();
    }

    public ProfileableReadRequest split(long nextEnding) {
        logger.log(Level.INFO, "nextEnding={0} splittedtill={1}", new Object[]{nextEnding, splitedTill});
        logger.log(Level.INFO, null, new Throwable());
        if (splitedTill == readRequestToSplit.getByteBuffer().capacity()) {
            throw new IllegalStateException("Requests fully splitted");
        }
        if (readRequestToSplit.getFileOffset() + splitedTill -1 > nextEnding) {
            throw new IllegalStateException(
                    "Requests for this split portion already created. "
                    + "ReadRequestToSplit=" + readRequestToSplit
                    + " nextEnding requested=" + nextEnding
                    + " splittedTill="+splitedTill);
        }
        // request = 150----->250 capacity = 101
        // avail   = 100----->200 201------>300
        // splits =>     150->200 201->250
        //                 sz=51     sz=50
        synchronized (this) {

            ByteBuffer bb = ByteBuffer.allocate(
                    (int) (nextEnding
                    - (readRequestToSplit.getFileOffset() + splitedTill)
                    + 1 // ending is inclusive
                    ));

            SplittedRequest splittedRequest = new SplittedRequest(bb, readRequestToSplit.getFileOffset() + splitedTill, splits.size());
            splitedTill += bb.capacity();
            splits.add(splittedRequest);
            logger.log(Level.INFO,"Currently created split"+ splittedRequest.toString());
            return splittedRequest;
        }
    }

    private void partiallyCompleted() {
        if (!isSplittingCompleted()) {
            return;
        }

        synchronized (splits) {
            if (!completed) {
                for (SplittedRequest splittedRequest : splits) {
                    if (!splittedRequest.isCompleted()) {
                        return;
                    }
                    if (splittedRequest.getError() != JPfmError.SUCCESS) {
                        logger.log(Level.SEVERE, "unsuccessful completion for splittreq {0}", splittedRequest);
                        // zero fill the region
                        ByteBuffer tmp = (ByteBuffer) splittedRequest.getByteBuffer().position(0).limit(splittedRequest.getByteBuffer().capacity());
                        tmp.put(new byte[tmp.capacity()]);//zero fill
                        // because data here is questionable
                    }
                }
                completed = true;
            } else {
                return; // the thread of other split request completed this for us.
            }
            if (completed) {
                complete();
            }
        }
    }

    private void complete() {
        // request might have been forcefully completed by the filesystem
        // for security reasons
        synchronized (readRequestToSplit) {
            //if(!readRequestToSplit.isCompleted()){
            //copy back everything from individual splits to original
            ByteBuffer toFill = readRequestToSplit.getByteBuffer();
            toFill.rewind();
            toFill.limit(toFill.capacity());
            logger.log(Level.INFO, "Mixing splits");
            logger.log(Level.INFO, "buff={0}", toFill.toString());
            logger.log(Level.INFO, "number of splits={0}", splits.size());
            int i = 1;
            int k = 0;
            for (ReadRequest rr : splits) {
                //toFill.put(rr.getByteBuffer());
                // TODO : use ByteBuffer.put instead
                append(toFill, k, rr.getByteBuffer());
                k += rr.getByteBuffer().capacity();
                logger.log(Level.INFO, "split {0}->{1} ->{2}",
                        new Object[]{i, rr.isCompleted(), generatePeekString(rr.getByteBuffer())});
                i++;
            }
            logger.log(Level.INFO, "result={0}", generatePeekString(toFill));
            logger.log(Level.INFO, "-------Mixing splits");

            try {
                readRequestToSplit.complete(
                        JPfmError.SUCCESS,
                        readRequestToSplit.getByteBuffer().capacity(),
                        this);
            } catch (AlreadyCompleteException ace) {
                logger.log(Level.SEVERE, "someone else completed " + this, ace);
                // we cannot throw this exception
                // as that particular request might be still incomplete
                // wheras the parent request might be completed
            }
            //}
        }
    }

    private void append(ByteBuffer destination, int position, ByteBuffer content) {
        for (int i = position; i < position + content.capacity(); i++) {
            destination.put(i, content.get(i - position));
        }

    }

    public int getBytesFilledTillNow(ReadRequest pendingRequest) {
        int bytesFilledTillNow = 0;
        synchronized (splits) {
            for (SplittedRequest splittedRequest : splits) {
                if (splittedRequest.isCompleted()) {
                    bytesFilledTillNow += splittedRequest.getByteBuffer().capacity();
                } else {
                    return bytesFilledTillNow;
                }
            }
            return bytesFilledTillNow;
        }
    }

    public void completeNow(ReadRequest pendingRequest) {
        if (pendingRequest != readRequestToSplit) {
            throw new IllegalArgumentException("This completer does not handling the given pending request");
        }
        readRequestToSplit.complete(JPfmError.SUCCESS, readRequestToSplit.getByteBuffer().capacity(), this);
    }

    public StackTraceElement[] getStackTrace() {
        LinkedList<StackTraceElement> l = new LinkedList<StackTraceElement>();
        int i = 0;
        for (SplittedRequest sr : splits) {
            if (sr.getStackTrace() == null) {
                l.add(new StackTraceElement("---------", "null stacktrace", "--------", i));
            } else {
                l.addAll(Arrays.asList(sr.getStackTrace()));
            }
            l.add(new StackTraceElement("--separator--", "-----this was " + (i + 1) + "split----", "--------", i));
            l.add(new StackTraceElement("-------------", "---------", "--------", i));
            i++;
        }
        return l.toArray(new StackTraceElement[0]);
    }

    public final class SplittedRequest implements ReadRequest, PropertyCarryingReadRequest,ProfileableReadRequest {

        private final ByteBuffer bb;
        private final long fileOffset;
        private final int splitNumber;
        private AtomicInteger completed = new AtomicInteger(JPfmError.INVALID_JPFM_ERROR_CODE);
        private StackTraceElement[] stackTrace;
        private final ConcurrentLinkedQueue properties =
                new ConcurrentLinkedQueue();

        @Override
        @SuppressWarnings(value="unchecked")
        public final PropertyCarryingReadRequest addProperty(Object property) {
            properties.add(property);return this;
        }
        
        public ReadRequest getParentReadRequest(){
            return SplittedRequestHandler.this.readRequestToSplit;
        }

        @Override
        public final Object[] getProperties() {
            return properties.toArray();
        }

        private String properties() {
            StringBuilder k = new StringBuilder(100);
            for (Object l : properties) {
                k.append("{");
                k.append(l);
                k.append("}");
            }
            return k.toString();
        }

        private SplittedRequest(final ByteBuffer bb, final long fileOffset, final int splitNumber) {
            this.bb = bb;
            this.fileOffset = fileOffset;
            this.splitNumber = splitNumber;
        }

        public final int getSplitNumber() {
            return splitNumber;
        }

        @Override
        public String toString() {
            return "{FileOffset=" + fileOffset + " ending=" + (fileOffset + bb.capacity() - 1)
                    + " capacity=" + bb.capacity() + " completed=" + completed.get() + "}"+properties();
        }

        public final void setStackTrace(StackTraceElement[] stackTrace) {
            this.stackTrace = stackTrace;
        }

        public final StackTraceElement[] getStackTrace() {
            return stackTrace;
        }

        public ByteBuffer getByteBuffer() {
            return bb;
        }

        public long getFileOffset() {
            return fileOffset;
        }

        public void complete(JPfmError error, int actualRead, Completer completer) throws IllegalArgumentException, IllegalStateException {
            synchronized (readRequestToSplit) {
                stackTrace = new Exception().getStackTrace();
                if (!completed.compareAndSet(/*expect*/JPfmError.INVALID_JPFM_ERROR_CODE,/*update*/ error.getErrorCode())) {
                    //if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
                    //we were expecting false, but it is true. implying it is already complete, throw an exception
                    throw new AlreadyCompleteException();
                }
                SplittedRequestHandler.this.partiallyCompleted();
            }
        }

        public boolean isCompleted() {
            return completed.get() != JPfmError.INVALID_JPFM_ERROR_CODE;
        }

        public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
            complete(error, getByteBuffer().capacity(), null);
        }

        public void handleUnexpectedCompletion(Exception exception) {
            if (!completed.compareAndSet(/*expect*/JPfmError.INVALID_JPFM_ERROR_CODE,/*update*/ JPfmError.FAILED.getErrorCode())) {
                SplittedRequestHandler.this.partiallyCompleted();
            } else {
                // already completed so ignore
            }
        }

        public long getCreationTime() {
            return SplittedRequestHandler.this.readRequestToSplit.getCreationTime();
        }

        public long getCompletionTime() {
            return SplittedRequestHandler.this.readRequestToSplit.getCreationTime();
        }

        public JPfmError getError() throws IllegalStateException {
            return JPfmError.convertErrorCode(completed.get());
        }

        public void setCompleter(Completer completehandler) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public boolean canComplete(Completer completehandler) {
            return true;
        }

        @Override
        public boolean removeProperty(Object property) {
            return properties.remove(property);
        }

        @Override
        public final int getRequestCount() {
            return 
                ((ProfileableReadRequest)SplittedRequestHandler.this.readRequestToSplit).getRequestCount();
        }

        @Override
        public final long getTotalDataRequestedTillThisRequest() {
            return 
                ((ProfileableReadRequest)SplittedRequestHandler.this.readRequestToSplit).getTotalDataRequestedTillThisRequest();
        }

        private final AtomicInteger traversedCount = new AtomicInteger();
        
        @Override
        public final AtomicInteger getTraversedCount() {
            return traversedCount;
        }
    }
}
