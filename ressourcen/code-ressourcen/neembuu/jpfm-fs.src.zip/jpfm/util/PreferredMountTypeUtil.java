/*
 * Copyright 2012 Shashank Tulsyan.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jpfm.util;

import jpfm.SystemUtils;
import jpfm.mount.Mount;

/**
 *  
 * @author Shashank Tulsyan
 */
public final class PreferredMountTypeUtil {
    public static boolean isFolderAPreferredMountLocation(){
        if(SystemUtils.IS_OS_WINDOWS){
            return false;
        }else return true;
    }
    
    public static String getActualMountLocation(Mount m){
        String ml = m.getMountLocation().toString();
        if(SystemUtils.IS_OS_WINDOWS){
            return ml;
        }else if(SystemUtils.IS_OS_MAC){
            return ml;
        }//else if(SystemUtils.IS_OS_LINUX){
        // assume linux
            if(ml.endsWith("/")) ml = ml.substring(0,ml.length()-1);
            return "/media/"+ml.substring(ml.lastIndexOf('/')+1)+"/";
        /*}
        return ml;*/
    }
}
