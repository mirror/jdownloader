/*
 *  Copyright (C) 2010 Shashank Tulsyan
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jpfm.util;

import java.nio.ByteBuffer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public final class ContentPeek {
    public static final int NUMBER_OF_VALUES  = 30;
    public static String generatePeekString(ReadRequest request){
        if(!request.isCompleted())throw new IllegalStateException("request not completed");
        return generatePeekString(request.getByteBuffer());
    }
    public static String generatePeekString(ByteBuffer byteBuffer){        
        StringBuilder sb = new StringBuilder(30*2+10);
        sb.append('{');
        for (int i = 0; i < NUMBER_OF_VALUES && i < byteBuffer.capacity(); i++) {
            sb.append(Integer.toHexString(byteBuffer.get(i)));
            sb.append(',');
        }
        sb.append('}');
        sb.append('{');
        byte[]b=new byte[NUMBER_OF_VALUES];
        byteBuffer.position(0);
        byteBuffer.get(b, 0,
                Math.min(NUMBER_OF_VALUES, byteBuffer.capacity())
            );
        for (int i = 0; i < b.length; i++) {
            if(!Character.isLetterOrDigit((char)b[i]))
                b[i]=32;
        }
        sb.append(new String(b).replace( '\n', ' '));
        sb.append('}');
        return sb.toString();
    }
}
