/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.util;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.FileId;
import jpfm.JPfmError;
import jpfm.operations.AlreadyCompleteException;
import jpfm.operations.Read;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public final class ReadUtils {
    public static void completedSuccessfully(ReadRequest readRequest, Completer c){
        readRequest.complete(JPfmError.SUCCESS, readRequest.getByteBuffer().capacity(), c);
    }

    public static void completedSuccessfully(ReadRequest readRequest){
        System.out.println("completing="+readRequest);
        readRequest.complete(JPfmError.SUCCESS, readRequest.getByteBuffer().capacity(), null);
    }

    public static long endingOffset(ReadRequest readRequest){
        return readRequest.getFileOffset()+readRequest.getByteBuffer().capacity()-1;
    }

    public static int requestSize(ReadRequest readRequest){
        return readRequest.getByteBuffer().capacity();
    }

    public static void handleUnexpectedCompletion(ReadRequest read, Exception exception) {
        read.complete(JPfmError.FAILED);
    }

    /**
     * Shorten a read if it is requesting beyond the file size and correctly
     * report end of file after filling the request appropriately.
     * If the request lies in range, the original request itself is returned
     * unmodified.
     * If after trimming a read request of zero or negative size is left
     * then null is returned. In such cases the caller should simply complete
     * {@link jpfm.operations.Read#complete(jpfm.JPfmError, int, jpfm.operations.readwrite.Completer)  }
     * the request with actualRead value equal to zero.
     * @param toTrim Request to trim if required
     * @param fileSize Current size of the file
     * @return trimmed read request or the same read request or null as the case may be
     */
    public static Read trimReadBeyondFileSize(Read toTrim, long fileSize){
        if(endingOffset(toTrim) >= fileSize){
            int trimedcapacity = (int)(
                    requestSize(toTrim) - (endingOffset(toTrim) - (fileSize-1) )
                );
            if(trimedcapacity<=0)return null;
            TrimmedRead trimedRead = new TrimmedRead(toTrim, trimedcapacity);
            System.out.println("trimming "+toTrim+ "filesize="+fileSize
                    + " result-="+trimedRead);
            return trimedRead;
        }else {
            return toTrim;
        }
    }

    private static final class TrimmedRead implements Read {
        private final Read toTrim;
        private final ByteBuffer trimmedByteBuffer;
        private final AtomicBoolean completed = new AtomicBoolean(false);

        public TrimmedRead(Read toTrim, int trimmedSize) {
            this.toTrim = toTrim;
            trimmedByteBuffer = ByteBuffer.allocate(trimmedSize);
        }

        public FileId getFileId() {
            return toTrim.getFileId();
        }

        public Completer getCompleter() {
            return toTrim.getCompleter();
        }

        public long getCreationTime() {
            return toTrim.getCreationTime();
        }

        public void handleUnexpectedCompletion(Exception exception) {
            ReadUtils.handleUnexpectedCompletion((ReadRequest) this, exception);
        }

        public boolean isCompleted() {
            return toTrim.isCompleted();
        }

        public ByteBuffer getByteBuffer() {
            return trimmedByteBuffer;
        }

        public long getFileOffset() {
            return toTrim.getFileOffset();
        }

        public void complete(JPfmError error, int actualRead, Completer completer) throws IllegalArgumentException, IllegalStateException {
            if(!completed.compareAndSet(/*expect*/false,/*update*/true)){
            //if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
                //we were expecting false, but it is true. implying it is already complete, throw an exception
                throw AlreadyCompleteException.createNew(getCompleter(),completer);
            }
            toTrim.getByteBuffer().put(trimmedByteBuffer);
            if(error == JPfmError.SUCCESS)
                toTrim.complete(JPfmError.END_OF_DATA,actualRead,completer);
            else
                toTrim.complete(error,actualRead,completer);
        }

        public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
            complete(error,trimmedByteBuffer.capacity(),null);
        }

        public long getCompletionTime() {
            return toTrim.getCompletionTime();
        }

        public JPfmError getError() throws IllegalStateException {
            return toTrim.getError();
        }

        public void setCompleter(Completer completehandler) {
            toTrim.setCompleter(completehandler);
        }

        public boolean canComplete(Completer completehandler) {
            return toTrim.canComplete(completehandler);
        }
    }
}
