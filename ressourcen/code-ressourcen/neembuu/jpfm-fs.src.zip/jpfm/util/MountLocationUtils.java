/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.util;

import java.io.File;
import javax.swing.JOptionPane;
import jpfm.SystemUtils;

/**
 *
 * @author Shashank Tulsyan
 */
public final class MountLocationUtils {
    public static boolean isValidAndSafe(String mountLocation){
        File f = new File(mountLocation);
        if(!f.exists())return false;
        if(SystemUtils.IS_OS_WINDOWS){
            return !f.isDirectory();
        }
        return f.isDirectory();
    }


    public static String getNewMountLocation(String[]args){
        final String mountLocation;
        if(args.length==0){
            System.out.println("First parameter should be mount location");
            System.out.println("opening browsing window because no parameters were passed");
            javax.swing.JFileChooser fileChooser = new javax.swing.JFileChooser();
            fileChooser.setFileSelectionMode(javax.swing.JFileChooser.FILES_AND_DIRECTORIES);
            int retVal = fileChooser.showOpenDialog(null);
            if(retVal == javax.swing.JFileChooser.APPROVE_OPTION){
                mountLocation = fileChooser.getSelectedFile().getAbsoluteFile().getPath();//throws exception
            }else {
                JOptionPane.showMessageDialog(null, "No mount location selected"
                        + "Exiting...." );
                System.exit(1);
                return null;
            }
        }else {
            mountLocation = args[0];
        }
        if(!MountLocationUtils.isValidAndSafe(mountLocation)){
            JOptionPane.showMessageDialog(null, "Mount location selected is not appropirate. "
                    + "\nIt might require admin priveledges to mount on the given location"
                    + "\nOr the file does not exists at all."
                    + "Exiting..." );
            System.exit(1);
            return null;
            
        }
        return mountLocation;
    }
}
