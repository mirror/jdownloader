/*
 *  Copyright 2010 admin.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.util;

import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author admin
 */
public class ExceptionCompleter implements Completer<ReadRequest> {
    private final StackTraceElement[]stackTrace;
    public ExceptionCompleter(Throwable t){
        StackTraceElement[] calltrace =  new Throwable().getStackTrace();
        stackTrace =
                new StackTraceElement[
                    t.getStackTrace().length
                    + 1
                    + calltrace.length
                    + 1
                ];
        for (int i = 0; i < t.getStackTrace().length; i++) {
            stackTrace[i] = t.getStackTrace()[i];
        }
        stackTrace[t.getStackTrace().length] = new
                StackTraceElement("+++++++++Reason for failure+++++++++", " "," ",0);
        
        for (int i = t.getStackTrace().length + 1;
            i < stackTrace.length - 1; i++) {
            stackTrace[i] = calltrace[i - (t.getStackTrace().length + 1) ];
        }

        stackTrace[stackTrace.length - 1] = new
                StackTraceElement("---------Reason for failure---------", " "," ",0);

    }
    public int getBytesFilledTillNow(ReadRequest pendingRequest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void completeNow(ReadRequest pendingRequest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public StackTraceElement[] getStackTrace() {
        return stackTrace;
    }
}
