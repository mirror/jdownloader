/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.util;

import java.nio.ByteBuffer;
import jpfm.JPfmError;
import jpfm.annotations.MightBeBlocking;
import jpfm.common.ReadableRegion;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public class ShiftReadableRegion implements ReadableRegion {
    private final ReadableRegion region;
    private final long offset_starting;
    private final long offset_ending;

    private ShiftReadableRegion(ReadableRegion region, long offset_starting, long offset_ending) {
        this.region = region;
        this.offset_starting = offset_starting;
        this.offset_ending = offset_ending;
    }

    public final long starting() {
        return region.starting();
    }

    public final long ending() {
        return region.ending();
    }

    @MightBeBlocking
    public void read(ReadRequest read) {
        ShiftReadRequest readRequest = new ShiftReadRequest();
        //read.getByteBuffer().put(region.re);
    }

    public static ShiftReadableRegion shift(
            ReadableRegion region, 
            long offset_starting, 
            long offset_ending
            ){
        if(region==null)throw new IllegalStateException();
        // todo:
        // checking starting and ending

        ShiftReadableRegion region1 = new ShiftReadableRegion(region, offset_starting, offset_ending);
        return region1;

    }

    private class ShiftReadRequest implements ReadRequest {
        public ByteBuffer getByteBuffer() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public long getFileOffset() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void complete(JPfmError error, int actualRead, Completer completer) throws IllegalArgumentException, IllegalStateException {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public Completer getCompleter() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void setCompleter(Completer completehandler) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public boolean canComplete(Completer completehandler) {
            return true;
        }

        public boolean isCompleted() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void handleUnexpectedCompletion(Exception exception) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public long getCreationTime() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public long getCompletionTime() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public JPfmError getError() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
            complete(error,getByteBuffer().capacity(),null);
        }

    }

}
