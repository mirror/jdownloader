package jpfm.util;

import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author Shashank Tulsyan
 */
public interface ProfileableReadRequest extends PropertyCarryingReadRequest {

    int getRequestCount();

    long getTotalDataRequestedTillThisRequest();

    AtomicInteger getTraversedCount();
    
}
