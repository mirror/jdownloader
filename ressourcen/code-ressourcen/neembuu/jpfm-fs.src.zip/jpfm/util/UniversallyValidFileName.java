/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */
package jpfm.util;

/**
 *
 * @author Shashank Tulsyan
 */
public final class UniversallyValidFileName {
    
    public static String makeUniversallyValidFileName(final String n){
        final char[]ca=n.toCharArray();
        for(int i =0;i<ca.length;i++){
            if(!isValidCharacter(ca[i])){
                ca[i]=' ';
            }
        }
        return new String(ca);
    }
    
    public static boolean isUniversallyValidFileName(final String n){
        final char[]ca=n.toCharArray();
        for(int i =0;i<ca.length;i++){
            if(!isValidCharacter(ca[i])){
                return false;
            }
        }
        return true;
    }
    
    private static boolean isValidCharacter(char c){
        if(Character.isLetter(c))return true;
        if(Character.isDigit(c))return true;
        
        switch(c){
            case '*':
            case '/':
            case ':':
            case '<':
            case '>':
            case '?':
            case '\\':
            case '|':
                
            case '\"':
            case '\'':
                
            case '+':
            case '[':
            case ']':
                return false;
        }
        
        return true;
    }
}
