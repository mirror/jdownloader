/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.util;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.JPfmError;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public class WaitingReadRequest implements ReadRequest {

    private final ByteBuffer byteBuffer;
    private final long fileOffset;
    private final AtomicBoolean completed = new AtomicBoolean(false);

    private final long creationTime = System.currentTimeMillis();
    private int completionTime = 0;

    private int result = 0;
    private JPfmError error;

    private final Object lock = new Object();

    public WaitingReadRequest(ByteBuffer byteBuffer, long fileOffset) {
        this.byteBuffer = byteBuffer;
        this.fileOffset = fileOffset;
    }

    public int read() {
        while(!isCompleted()){
            synchronized(lock){
                try{
                    lock.wait();
                }catch(InterruptedException exception){

                }
            }
        }
        return result;
    }

    public JPfmError getError() {
        return JPfmError.FAILED;
    }

    public ByteBuffer getByteBuffer() {
        return  byteBuffer;
    }

    public long getFileOffset() {
        return  fileOffset;
    }

    public void complete(JPfmError error, int actualRead, Completer completer) throws IllegalArgumentException, IllegalStateException {
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw new IllegalStateException("already completed");
        }completionTime = (int)(System.currentTimeMillis() - creationTime);
        this.error = error;
        result = actualRead;
        lock.notifyAll();
    }

    public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
        complete(error,getByteBuffer().capacity(),null);
    }

    public boolean isCompleted() {
        return completed.get();
    }

    public void handleUnexpectedCompletion(Exception exception) {
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw new IllegalStateException("already completed");
        }completionTime = (int)(System.currentTimeMillis() - creationTime);
        this.error = JPfmError.FAILED;
    }

    public long getCreationTime() {
        return creationTime;
    }

    public long getCompletionTime() {
        return completionTime + creationTime;
    }

    public void setCompleter(Completer completehandler) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Completer getCompleter() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean canComplete(Completer completehandler) {
        return true;
    }

}
