/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package neembuu.vfs.file;

import jpfm.DirectoryStream;
import neembuu.diskmanager.DiskManager;
import neembuu.vfs.connection.NewConnectionProvider;
import neembuu.vfs.progresscontrol.ThrottleFactory;

/**
 *
 * @author Shashank Tulsyan
 */
public final class SeekableConnectionFileParams {
    private final String fileName;
    private final long size;
    private final DirectoryStream parent;
    private final NewConnectionProvider connectionProvider;
    private final DiskManager diskManager;
    private final ThrottleFactory throttleFactory;
    private final TroubleHandler troubleHandler;

    private SeekableConnectionFileParams(
            Builder b) {
        this.fileName = b.fileName;
        this.size = b.size;
        this.parent = b.parent;
        this.connectionProvider = b.connectionProvider;
        this.diskManager = b.diskManager;
        this.throttleFactory = b.throttleFactory;
        this.troubleHandler = b.troubleHandler;
    }

    public TroubleHandler getTroubleHandler() {
        return troubleHandler;
    }
    
    public NewConnectionProvider getConnectionProvider() {
        return connectionProvider;
    }

    public DiskManager getDiskManager() {
        return diskManager;
    }

    public String getFileName() {
        return fileName;
    }

    public DirectoryStream getParent() {
        return parent;
    }

    public long getSize() {
        return size;
    }

    public ThrottleFactory getThrottleFactory() {
        return throttleFactory;
    }
    
    
    public static final class Builder {
        private String fileName;
        private long size;
        private DirectoryStream parent;
        private NewConnectionProvider connectionProvider;
        private DiskManager diskManager;
        private ThrottleFactory throttleFactory;
        private TroubleHandler troubleHandler;

        public Builder setNewConnectionProvider(NewConnectionProvider connectionProvider) {
            this.connectionProvider = connectionProvider;
            return this;
        }

        public Builder setTroubleHandler(TroubleHandler troubleHandler) {
            this.troubleHandler = troubleHandler;
            return this;
        }

        public Builder setDiskManager(DiskManager diskManager) {
            this.diskManager = diskManager;
            return this;
        }

        public Builder setFileName(String fileName) {
            this.fileName = fileName;
            return this;
        }

        public Builder setParent(DirectoryStream parent) {
            this.parent = parent;
            return this;
        }

        public Builder setFileSize(long size) {
            this.size = size;
            return this;
        }

        public Builder setThrottleFactory(ThrottleFactory throttleFactory) {
            this.throttleFactory = throttleFactory;
            return this;
        }
        
        public SeekableConnectionFileParams build(){
            if(fileName==null){
                throw new IllegalArgumentException("File name is a compulsary parameter");
            }if(size<=0){
                throw new IllegalArgumentException("Filesize less or than equal to zero");
            }if(throttleFactory==null){
                throw new IllegalArgumentException("Throttle factory is a compulsary parameter. "
                        + "Try using GeneralThrottle");
            }if(diskManager==null){
                throw new IllegalArgumentException("DiskManager is a compulsary parameter. "
                        + "Try using DiskManagers.getDefaultManager");
            }if(parent==null){
                throw new IllegalArgumentException("No parent specified");
            }if(connectionProvider == null){
                throw new IllegalArgumentException("NewConnectionProvider is a compulsary parameter. ");
            }if(troubleHandler==null){
                throw new IllegalArgumentException("TroubleHandler is a compulsary parameter. ");
            }
            return new SeekableConnectionFileParams(this);
        }
    }
    
}
