/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package neembuu.vfs.file;

/**
 *
 * @author Shashank Tulsyan
 */
public interface DownloadCompletedListener {
    void completed();
}
