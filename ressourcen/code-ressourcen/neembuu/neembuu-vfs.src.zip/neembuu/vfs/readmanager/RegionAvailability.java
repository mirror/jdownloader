package neembuu.vfs.readmanager;

/**
 *
 * @author Shashank Tulsyan <shashaanktulsyan@gmail.com>
 */
public interface RegionAvailability {
    
}
