/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package neembuu.rangearray;

/**
 * Range array property should implement this interface to show some text 
 * in the gui tooltip when mouse is over that particular region.
 * @author Shashank Tulsyan <shashaanktulsyan@gmail.com>
 */
public interface ToolTipTextProvider {
    String getToolTipText();
}
