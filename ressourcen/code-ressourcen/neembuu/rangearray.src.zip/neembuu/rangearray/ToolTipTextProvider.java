/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package neembuu.rangearray;

/**
 *
 * @author Shashank Tulsyan <shashaanktulsyan@gmail.com>
 */
public interface ToolTipTextProvider {
    String getToolTipText();
}
