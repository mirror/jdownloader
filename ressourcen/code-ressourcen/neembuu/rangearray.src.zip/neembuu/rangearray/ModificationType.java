/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package neembuu.rangearray;

/**
 *
 * @author Shashank Tulsyan
 */
public enum ModificationType {    
    CS1,CS2,CS3,CS4,CS5_1,CS5_2,CS5_3,CS5_4,CS6,CS7,CS8,CS9,
    FILE_SIZE_CHANGED,
    ELEMENT_INTRINSICALLY_EXPANDED,
    EXPANDING_ELEMENT_COLLIDED
}
