/*
 *  Copyright (C) 2010 Shashank Tulsyan
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package neembuu.vfs.file;

/**
 *
 * @author Shashank Tulsyan
 */

import java.io.File;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import jpfm.AccessLevel;
import jpfm.DirectoryStream;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileId;
import jpfm.FileType;
import jpfm.annotations.NonBlocking;
import jpfm.fs.ReadOnlyRawFileData;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.util.UniversallyValidFileName;
import jpfm.volume.OpenCloseListener;
import neembuu.diskmanager.DiskManagers;
import neembuu.rangearray.DissolvabilityRule;
import neembuu.rangearray.RangeArray;
import neembuu.rangearray.RangeArrayFactory;
import neembuu.rangearray.RangeArrayParams;
import neembuu.rangearray.UIRangeArrayAccess;
import neembuu.util.logging.LoggerUtil;
import neembuu.vfs.connection.NewConnectionProvider;
import neembuu.vfs.connection.jdimpl.JD_DownloadManager;
import neembuu.vfs.connection.sampleImpl.DownloadManager;
import neembuu.vfs.progresscontrol.ThrottleFactory;
import neembuu.vfs.readmanager.TotalFileReadStatistics;
import neembuu.vfs.readmanager.impl.SeekableConnectionFileImplBuilder;
import neembuu.vfs.test.FileNameAndSizeFinderService;
import neembuu.vfs.test.MonitoredSeekableHttpFilePanel;

/**
 *
 * @author Shashank Tulsyan
 */
public class MonitoredHttpFile 
        implements SeekableConnectionFile{

    private final RangeArray requestedRegion = RangeArrayFactory.newDefaultRangeArray(
            new RangeArrayParams.Builder().
                addDissolvabilityRule(
                    DissolvabilityRule.LINEAR_EXPANSIONS_ONLY).build()
            );
    
    public MonitoredSeekableHttpFilePanel filePanel;
    private static final Logger LOGGER = LoggerUtil.getLightWeightLogger(); //Logger.getLogger(name);

    private final SeekableConnectionFile vfile ;

    public MonitoredHttpFile(
            SeekableConnectionFile scf,
            NewConnectionProvider newConnectionProvider){
        LOGGER.info("newC"+newConnectionProvider);
        this.vfile = scf;
        this.newConnectionProvider = newConnectionProvider;
        filePanel = new MonitoredSeekableHttpFilePanel(this);
        requestedRegion.setFileSize(scf.getFileSize());
    }

    private ReadRequest previous = null;

    private final NewConnectionProvider newConnectionProvider;

    @Override
    @NonBlocking
    public final void read(ReadRequest read) throws Exception {
        
        vfile.read(read);
        requestedRegion.addElement(
                read.getFileOffset(), 
                read.getFileOffset()+read.getByteBuffer().capacity()-1,
                null);
    }

    @Override
    public TroubleHandler getTroubleHandler() {
        return vfile.getTroubleHandler();
    }
    
    public final RangeArray getRequestedRegion() {
        return requestedRegion;
    }
    
    public final String getSourceDescription(){
        return newConnectionProvider.getSourceDescription();
    }

    public JPanel getFilePanel() {
        return filePanel;
    }
    
    public static Logger getLogger(){
        return LOGGER;
    }

    @Override
    public DownloadConstrainHandler getDownloadConstrainHandler() {
        return vfile.getDownloadConstrainHandler();
    }
    
    @Override
    public void setAutoCompleteEnabled(boolean autoCompleteEnabled) {
        vfile.setAutoCompleteEnabled(autoCompleteEnabled);
    }

    @Override
    public boolean isAutoCompleteEnabled() {
        return vfile.isAutoCompleteEnabled();
    }
    
    @Override
    public UIRangeArrayAccess getRegionHandlers() {
        return vfile.getRegionHandlers();
    }

    @Override
    public TotalFileReadStatistics getTotalFileReadStatistics() {
        return vfile.getTotalFileReadStatistics();
    }


    @Override
    public void addOpenCloseListener(OpenCloseListener closeListener) {
        vfile.addOpenCloseListener(closeListener);
    }

    @Override
    public void removeOpenCloseListener(OpenCloseListener closeListener) {
        vfile.removeOpenCloseListener(closeListener);
    }

    @Override
    public void close() {
        vfile.close();
    }

    @Override
    public boolean isOpenByCascading() {
        return vfile.isOpenByCascading();
    }

    @Override
    public void open() {
        vfile.open();
    }

    @Override
    public void setCannotClose(boolean cannotClose) {
        vfile.setCannotClose(cannotClose);
    }

    @Override
    public ReadOnlyRawFileData getReference(FileId fileId, AccessLevel level) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FileType getFileType() {
        return vfile.getFileType();
    }

    @Override
    public FileDescriptor getFileDescriptor() {
        return vfile.getFileDescriptor();
    }

    @Override
    public long getFileSize() {
        return vfile.getFileSize();
    }

    @Override
    public long getCreateTime() {
        return vfile.getCreateTime();
    }

    @Override
    public long getAccessTime() {
        return vfile.getAccessTime();
    }

    @Override
    public long getWriteTime() {
        return vfile.getWriteTime();
    }

    @Override
    public long getChangeTime() {
        return vfile.getChangeTime();
    }

    @Override
    public String getName() {
        return vfile.getName();
    }

    @Override
    public FileDescriptor getParentFileDescriptor() {
        return vfile.getParentFileDescriptor();
    }

    @Override
    public FileFlags getFileFlags() {
        return vfile.getFileFlags();
    }

    @Override
    public DirectoryStream getParent() {
        return vfile.getParent();
    }
    
    @Override
    public void setParent(DirectoryStream ds){
        vfile.setParent(ds);
    }
    
    @Override
    public void addDownloadCompletedListener(DownloadCompletedListener dcl) {
        vfile.addDownloadCompletedListener(dcl);
    }

    @Override
    public void removeDownloadCompletedListener(DownloadCompletedListener dcl) {
        vfile.removeDownloadCompletedListener(dcl);
    }
    
    public static final class Builder_Test {
        private String fileName = null; 
        private long fileSize = -1;
        private String storagePath = null;
        private DirectoryStream parent = null;
        private NewConnectionProvider newConnectionProvider = null;
        private String url = null;
        private TroubleHandler troubleHandler = null;
        
        public Builder_Test(){
            
        }

        public Builder_Test setFileName(String fileName) {
            this.fileName = fileName;
            return this;
        }

        public Builder_Test setNewConnectionProvider(NewConnectionProvider newConnectionProvider) {
            this.newConnectionProvider = newConnectionProvider;
            return this;
        }

        public Builder_Test setParent(DirectoryStream parent) {
            this.parent = parent;
            return this;
        }

        public Builder_Test setTroubleHandler(TroubleHandler troubleHandler) {
            this.troubleHandler = troubleHandler;
            return this; 
        }

        public Builder_Test setFileSize(long size) {
            this.fileSize = size;return this;
        }

        public Builder_Test setStoragePath(String storagePath) {
            this.storagePath = storagePath;return this;
        }

        public Builder_Test setUrl(String url) {
            this.url = url;return this;
        }
        
        public MonitoredHttpFile build()throws Exception {
            if(storagePath==null || parent==null){
                throw new IllegalArgumentException("Required parameters storagePath and/or parent not initialized");
            }
            if(newConnectionProvider==null){
                if(url==null)
                    throw new IllegalStateException("newConnectionProvider==null url==null");
                else {
                    newConnectionProvider =
                            //new DownloadManager(url);
                            new JD_DownloadManager(url);
                    long size_obt ;

                    FileNameAndSizeFinderService.SIZE_AND_NAME size_and_name = 
                            FileNameAndSizeFinderService.getSingleton().getSizeAndName(url);
                    size_obt = size_and_name.fileSize;
                    this.fileName = size_and_name.fileName;
                    LOGGER.log(Level.INFO, "Filename={0} FileSize={1}", new Object[]{fileName,fileSize});
                    if(size_obt ==-1){
                        throw new IllegalStateException("could not determine size" );
                    }
                    fileSize = size_obt;
                }
            }else {
                if(fileSize<=0){
                    throw new IllegalStateException("fileSize zero or negative");
                }
                if(fileName==null){
                    throw new IllegalArgumentException("name==null");
                }
                if(!UniversallyValidFileName.isUniversallyValidFileName(fileName)){
                    throw new IllegalArgumentException("name not universally valid. name="+fileName);
                }
            }
            
            
            File f = new File(storagePath);
            if(f.exists()){
                if(!f.isDirectory()){
                    throw new IllegalArgumentException("Storage path is not a directory");
                }
            }else {
                throw new IllegalArgumentException("Storage path does not exists");
            }
            
            SeekableConnectionFileParams fileParams
                    = new SeekableConnectionFileParams.Builder()
                        .setFileName(fileName)
                        .setFileSize(fileSize)
                        .setParent(parent)
                        .setNewConnectionProvider(newConnectionProvider)
                        .setDiskManager(DiskManagers.getDefaultManager(storagePath))
                        .setThrottleFactory(ThrottleFactory.General.SINGLETON)
                        .setTroubleHandler(troubleHandler)
                        .build();
            
            SeekableConnectionFile scf
                    = SeekableConnectionFileImplBuilder.build(fileParams);
            
            return new MonitoredHttpFile(scf,newConnectionProvider);
        }
    }
    
    
    
}
