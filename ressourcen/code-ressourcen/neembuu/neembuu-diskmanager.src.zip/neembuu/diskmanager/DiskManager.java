/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package neembuu.diskmanager;

/**
 * 1 global disk manager is required. It supplies a {@link FileStorageManager} for each
 * file being downloaded. Read the function of {@link FileStorageManager} to understand
 * why we have these interfaces.
 * @author Shashank Tulsyan <shashaanktulsyan@gmail.com>
 */
public interface DiskManager {
    FileStorageManager makeNewFileStorageManager(
            String fileName,
            ResumeStateCallback callback);
}
