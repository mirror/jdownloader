/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   JPfmFSFinder.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.nio.channels.FileChannel;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import jpfm.fs.splitfs.SplitFS;

/**
 * Would be used to allow mounting initiated using pismo quick mount feature.
 * But it would not be a good idea to have a javaformatter. That can make
 * quickmount of other archives slow as well. That is why this is not supported.
 * @author Shashank Tulsyan
 */
public final class JPfmFSFinder {

    /**
     * In an instance originating from native side only one formatter exists
     */
    private static Class<? extends JPfmBasicFileSystem> formatterClass = null;

    public static boolean canManage(
            String name,
            java.nio.ByteBuffer volumeRawData,
            java.nio.channels.FileChannel volumeFileChannel) {
        //todo : find and then also check if it has the correct
        //implementation of create

        //formatterClass = SplitFS.class;
        return true;
    }

    public static boolean serve(
            String name,
            String mountLocation,
            java.io.FileDescriptor fileDescriptor) {
//        create(
//            String name,
//            java.nio.ByteBuffer volumeRawData,
//            FileChannel volumeFileChannel,
//            Path directory){

        if (formatterClass == null) {
            return false;
        }


        Method createMethod = null;
        try {
            createMethod = formatterClass.getDeclaredMethod(
                    "create",
                    String.class,
                    FileChannel.class,
                    String.class);
        } catch (Exception any) {
            any.printStackTrace();
            return false;
        }

        /*Path mountPath = null;
        try {
            mountPath = Paths.get(mountLocation);
        } catch (Exception any) {
            any.printStackTrace();
            return false;
        }*/
        try {
            createMethod.invoke(null,
                    name,
                    // this might work only for read
                    new FileInputStream(fileDescriptor).getChannel(),
                    mountLocation/*mountPath*/);
        } catch (Exception any) {
            any.printStackTrace();
            // todo :
        }

        return true;

    }
}
