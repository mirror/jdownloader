/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

import jpfm.MachineUtils.MachineType;

/**
 *
 * @author Shashank Tulsyan
 */
public abstract class OperatingSystem {

    private final MachineType[]supportedArchitectures;
    private final String[]versionList;
    protected OperatingSystem(MachineType[]supportedArchitectures,String[]versionList) {
        this.supportedArchitectures = supportedArchitectures;
        this.versionList = versionList;
    }

    public final boolean supports(MachineType machineType){
        for (MachineType mt : supportedArchitectures) {
            if(mt.equals(machineType.toString()))
                return true;
        }return false;
    }

    public MachineType[]getSupportedArchitectures() {
        return supportedArchitectures;
    }

    public String[] getVersionList() {
        return versionList;
    }

    public abstract String getName();

    public static final class Windows extends OperatingSystem{
        private final String[]versionsList;
        /*package private*/ Windows(
                final MachineType[]supportedArchitectures,
                final String[]versionsList) {
            super(supportedArchitectures,versionsList);
            this.versionsList = versionsList;
        }

        public final String[]getVersionsList(){
            return versionsList.clone();
        }

        @Override
        public String getName() {
            return "Windows";
        }


    }

    public static final class Linux extends OperatingSystem{
        /*package private*/ Linux(
                final MachineType[]supportedArchitectures,
                final String[]distroList) {
            super(supportedArchitectures,distroList);
        }

        @Override
        public String getName() {
            return "*nix";
        }
    }

    public static final class Macintosh extends OperatingSystem{

        /*package private*/ Macintosh(
                final MachineType[]supportedArchitectures,
                final String[]versionsList) {
            super(supportedArchitectures,versionsList);
        }

        @Override
        public String getName() {
            return "Macintosh";
        }
    }
}