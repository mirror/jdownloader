/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   FormatterEvent.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * Wrapper of events usually send by native side
 * @author Shashank Tulsyan
 */
public class FormatterEvent {

    public static enum EVENT {

        SUCCESSFULLY_MOUNTED, MOUNT_CREATE_FAILED, ERROR, MESSAGE, WARNING, INCORRECT_IMPLEMENTATION, DETACHED, OTHER
    };
    final EVENT event;
    final String message;
    final Throwable throwable;
    final Object eventSource;

    protected FormatterEvent(int event, String message) {
        this(event,message,null,null);
    }
    protected FormatterEvent(int event, String message,Throwable cause, Object mount) {
        switch (event) {
            case 1:
                this.event = EVENT.ERROR;
                break;
            case 2:
                this.event = EVENT.MESSAGE;
                break;
            case 3:
                this.event = EVENT.WARNING;
                break;
            case 4:
                this.event = EVENT.INCORRECT_IMPLEMENTATION;
                break;
            case 5:
                this.event = EVENT.DETACHED;
                break;
            case 6:
                this.event = EVENT.SUCCESSFULLY_MOUNTED;
                break;
            case 7:
                this.event = EVENT.MOUNT_CREATE_FAILED;
                break;
            default:
                this.event = EVENT.OTHER;
                break;
        }
        this.message = message;
        this.throwable = cause;
        this.eventSource = mount;
    }

    protected FormatterEvent(EVENT event, String message) {
        this.event = event;
        this.message = message;
        this.throwable = null;
        eventSource = null;
    }

    /*package private*/ FormatterEvent(EVENT event, String message, Throwable throwable) {
        this.event = event;
        this.message = message;
        this.throwable = throwable;
        eventSource  = null;
    }

    public final Throwable getException() {
        return throwable;
    }

    public final EVENT getEventType() {
        return event;
    }

    public final String getMessage() {
        return message;
    }

    /*package private*/ final Object getEventSource() {
        return eventSource;
    }

    @Override
    public String toString() {
        if(throwable!=null){
            String toReturn = "{" + event + " : " + getMessage() + "}" +
                   ( (eventSource!=null)?"{EventSource : "+eventSource.toString()+"}":"" )+"{\n";

            ByteArrayOutputStream  baos = new ByteArrayOutputStream(1024);
            throwable.printStackTrace(new PrintStream(baos));
            toReturn = toReturn + baos.toString();
            /*StackTraceElement[] stes = throwable.getStackTrace();
            for (int i = 0; i < stes.length; i++) {
                StackTraceElement stackTraceElement = stes[i];
                toReturn = "\t"+toReturn + stackTraceElement.toString() + "\n";
            }*/
            toReturn = toReturn + "\n} " ;
            return toReturn;
        }
        return "{" + event + " : " + getMessage() + "}";
    }
}
