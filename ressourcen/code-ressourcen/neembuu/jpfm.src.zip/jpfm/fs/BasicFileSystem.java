/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs;

import jpfm.FileDescriptor;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileId;
//import jpfm.BasicFileSystem;
import jpfm.annotations.Blocking;
import jpfm.annotations.MightBeBlocking;
import jpfm.mount.Mount;
import jpfm.operations.Read;

/**
 * BasicFileSystem is a quick way to implement readonly
 * virtual filesystems in java. BasicFileSystem , {@link jpfm.fs.SimpleReadOnlyFileSystem }
 * or classes extending any of these can be used to quickly make
 * readonly virtual filesystems in java. Use of higher level implementation is encouraged
 * as it will not only save time, but also also keep the api user's code uninfluenced
 * by changes to jpfm api.
 * <br/>
 * <br/>
 * This is semi-concurrent, that is
 * All filesystem functions are
 * implemented as blocking in nature, with exception to read.
 * <br/><br/>
 * <u>Some advice :</u><ul>
 * <li>All BasicFileSystem functions (with exception to {@link #read(jpfm.operations.ReadImpl) } )
 * are intrinsically blocking in nature. That is, there is no way to implement them in NonBlocking fashion.
 * Therefore {@link #open(filePath)} , {@link #getFileAttributes(null) },
 * {@link #close(jpfm.FileDescriptor) } , {@link #capacity() },
 * {@link #delete(jpfm.FileDescriptor) } , {@link #getRootAttributes() } and
 * {@link #list(jpfm.FileDescriptor) }  should be implemented in such a
 * way that it does not take much time to execute,
 * because the client application may be in <b>Not Responding</b> state during execution of these functions.
 * <li><u>ReadImpl requests (that is {@link #read(jpfm.operations.ReadImpl)  } )</u><br/>
 * If the implementor feels, might take some time for the request to be satisifed,
 * he should handle it in a separate thread or do it in a non-blocking java-nio fashion.
 * Implementing read in blocking fashion
 * might risk locking the client application in <b>Not Responding</b> state.
 * See {@link java.nio.channels.AsynchronousFileChannel } and
 * {@link neembuu.vfs.test.ThrottledRealFile } for inspiration.
 * <li>It would be good idea to shift to {@link AsynchronousFileSystem }
 * if non-blocking nature is required for all filesystem functions.
 * AsynchronousFileSystem provides all pismo file mount features.
 * <li>Cases in which you should use {@link AsynchronousFileSystem } would be
 * for example : FTPFileSystem . See {@link AsynchronousFileSystem#list(jpfm.operations.List) }
 * for exact reason why an FTPFileSystem would be implemented using non blocking list
 * implementation.
 * </ul>
 * <br/><br/>
 * <u>JPfm annotations</u>
 * Keep an eye on the type of annotation on methods, it is one of :
 * <ul>
 * <li> {@link jpfm.annotations.NonBlocking}
 * <li> {@link jpfm.annotations.Blocking}
 * <li> {@link jpfm.annotations.MightBeBlocking}
 * </ul>
 * Try to annotate your functions, and also note the annotation made of JPfm library functions,
 * as it will keep you consious why a method has been implemented as blocking, what are assumptions made,
 * why it must be implemented in non blocking fashion, when it is safe to
 * ignore .... so on so forth.
 * @see #read(jpfm.operations.ReadImpl)
 * @see AsynchronousFileSystem
 * @author Shashank Tulsyan
 */
public interface BasicFileSystem {
    /**
     * The for filepath  /directory1/file1.bin
     * filePath[] = {"directory1", "file1.bin"} <br/>
     * <br/>
     * The filedescriptor is set as open after this method
     * successfully returns. Just after that,
     * {@link #open(jpfm.FileDescriptor) } is called.
     * It is in {@link #open(jpfm.FileDescriptor) } that you
     * should call open() of any JPfmReadable. <br/>
     * Here you are supposed to simply return the
     * appropriate FileAttributesProvider, nothing more.
     * @param filePath The path of the file or folder being opened
     * @return FileAttributesProvider associated with the given filePath
     * or null if no such file exists in the Volume
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that open consumes negligible time to complete")
    FileAttributesProvider open(String[] filePath);

    /**
     * This is always called after opening of the file, if and only if
     * the file is being opened for the first time.
     * This method should be used to call open() function
     * of all JPfmReadables .
     * @param FileAttributesProvider
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that open consumes negligible time to complete")
    void open(FileAttributesProvider fap);

    /**
     * Invoked for file whose existence in the abstract volume was
     * recently confirmed. This is used for serializingOpen operation.
     *
     *
     * This has no concurrent counterpart and is also used in {@link BasicFileSystem } .
     * Just as all blocking fileystem method this method should be implemented in such a
     * way that it does not take much time to execute,
     * because the client application may be in <b>Not Responding</b> state during execution of this.
     * <br/>
     * The FileAttributesProvider is not cached by the JPfm.
     * This provides the freedom for the FileAttributes to be saved in
     * any desired fashion : in RAM, harddisk or database;
     * which would probably be more efficient
     * (and memory saving) that JPfm handling all this.
     * <br/>
     * Even the FileDescriptor is not cached by JPfm, it only
     * maintains certain Id to differentiate between files.
     * <br/>
     * The correct way to know if a given
     * FileAttributesProvider correspondes to the
     * FileDescriptor passed is  to get the fileDescriptor FileAttributesProvider being checked
     * by {@link FileAttributesProvider#getFileDescriptor()} and then
     * using {@link FileDescriptor#implies(jpfm.FileDescriptor) } passing it the
     * fileDescriptor of the file being reopened.
     * If {@link FileDescriptor#implies(jpfm.FileDescriptor) } returns true
     * then that FileAttributesProvider should be returned.
     * If no FileAttributesProvider in this volume satify this criteria
     * null can be returned. (this implies that the file existed but not any more)
     *
     * @param fileDescriptor The fileDescriptor corresponding to a
     * file
     * @return The FileAttributesProvider associated with the given
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that getFileAttributes consumes negligible time to complete, and files metainfo is not backed by a slow source.")
    FileAttributesProvider getFileAttributes(FileId fileDescriptor);

    /**
     * @param folderToList The FileDescriptor of the folder whoes contents are to be listed
     * Null may be returned
     * @return DirectoryStream that provides an iterator over the abstract list of files
     * and folders in this folderToList
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that list consumes negligible time to complete, as the folder is not a remote one, or folder contents have been cached")
    DirectoryStream list(FileId folderToList);

    /**
     * This is called when all instances of the file have been closed.
     * The memory allocated and handles can be freed and FileDescriptor can be saved or forgotten whichever
     * is desired. (removing reference to FileDescriptor will free 40 bytes of memory  )
     * @param file The filedescriptor of the file who's resources (if any) can be freed/that is file can be closed
     */
    @Blocking(getReasonWhyItDoesNotMatter="Calls to close in any java.io or java.nio library do not block")
    void close(FileId file);

    /**
     * This is called when user/an application tries to delete a file.
     * Implementing this is would allow deletion of malicious files.
     * It is would be a better idea not to check if the file is being read, before deleting it,
     * because this way malicious files cannot be locked.
     * Files on virtual filesystem are unreal, so it does not matter if they are deleted, they can
     * be very easily re-added to the filesystem.
     *
     * <br/><br/><br/><br/>
     * <b><u>Additional reference from PFM docs</u></b><br/><br/>
     * <i>Please note : Native implementation is different from java implementation. The description
     * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
     * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
     * <br/><br/>
     * <b>Deleted Files</b><br/>
     * The PFM Protocol handles file deletion using a unix model,
     * where deletion applies to file names as opposed to underlying
     * file data. After a file has been deleted, the file data must
     * remain accessible until the file is finally closed.<br/><br/>
     * The unix file deletion model requires extra code for some formatters.
     * For other formatters it is trivially supported. Regardless,
     * it is a requirement for formatters and is utilized by the driver.<br/><br/>
     * Formatter developers should understand that the NT file system
     * model is more complex than is apparent to casual
     * users of the Win32 API. Using a unix model for
     * file delete allows the driver to achieve a high level
     * of application compatibility in a more portable and
     * supportable way than if the native NT delete model were
     * directly supported by the protocol.
     *
     * @param file The filedescriptor of the file whoes resources (if any) can be freed/that is file can be closed
     */
    @Blocking
    void delete(FileId fileToDelete);

    /**
     * The total size of the volume.
     * For read only volume it is the sum of size of each file in the volume.
     * This is only informative and incorrect implementation will not cause funtional failuers in readonly volume/formatter.
     * @return The total size of the volume, that is the sum of size of each file in the volume
     */
    @Blocking
    long capacity();

    @MightBeBlocking(reason="Function is abstract")
    void read(Read read)throws Exception;

    @MightBeBlocking(reason="used only once")
    FileAttributesProvider getRootAttributes();

    /**
     * This is not a necessary filesystem functionality that implementors need to provide.
     * UnsupportedOperationException may be safely thrown.
     * <br/>
     * In neembuu virtual filesystem, this operation can be very slow.
     * This is because before cascade mounting, some amount of data might
     * be required to be there.
     * <br/>
     * Mountlocation (relative to the host filesystem mount location root)
     * is decided by the host filesystem, and is accessible
     * in the {@link Mount#getMountLocation() }
     * @throws UnsupportedOperationException
     * @param basicCascadable
     * @return
     */
    @Blocking(getReasonWhyItDoesNotMatter="This is not called from kernel side")
    Mount cascadeMount(BasicCascadableProvider basicCascadable)throws UnsupportedOperationException;

    /**
    * This functions is never called. The only reason for this is
    * to make it impossible (without hacks) to simultaneously implement
    * both {@link AsynchronousFileSystem} and {@link BasicFileSystem}.
    * A filesytem cannot be both Basic and Asynchronous .
    * Null may be returned.
    */
    Type.BASIC getType();

}
