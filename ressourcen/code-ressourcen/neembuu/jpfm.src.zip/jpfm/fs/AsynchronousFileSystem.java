/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs;

import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileId;
import jpfm.annotations.Blocking;
import jpfm.operations.Capacity;
import jpfm.operations.Close;
import jpfm.operations.Control;
import jpfm.operations.Delete;
import jpfm.operations.FileSystemOperation;
import jpfm.operations.FlushFile;
import jpfm.operations.FlushMedia;
import jpfm.operations.List;
import jpfm.operations.MediaInfo;
import jpfm.operations.Move;
import jpfm.operations.MoveReplace;
import jpfm.operations.Open;
import jpfm.operations.Read;
import jpfm.operations.Replace;
import jpfm.operations.SetSize;
import jpfm.operations.Write;

/**
 * Pismo File Mount which is a
 * operating system extension that enables access and modification to
 * user and program data through the file system interface of the operating system.
 * <br/>
 * AsynchronousFileSystem should be used when all filesystem functions are to be implemented in non-blocking fashion,
 * and/or writing and other forms of modifications are to allowed in the virtual filesystem.
 * Otherwise {@link BasicFileSystem} can be used.
 * There are 16 file system operations supported.<br/>
 * Each operation method can throw exception, but it would be wise to handle them, as it will be better for performance.
 * There are various examples available. Most filesystems are provided in jpfm-fs.jar in jpfm.fs package.
 * <br/>
 * <br/>
 * <u>Note</u> : All filesystem operations provide a {@link jpfm.FileDescriptor} or
 * {@link jpfm.FileId } which has to be used to locate the correct file. These can be very easily saved in collections, as they implement Comparable.
 * Also note that the FileDescriptor passed is not equal to the one which you have in the corresponding FileAttributesProvider.
 * To find correct FileAttributesProvider corresponding to a given FileDescriptor
 * {@link FileDescriptor#implies(jpfm.FileDescriptor) } method should be used.
 * That is to say {@link FileAttributesProvider#getFileDescriptor() } is not equal to
 * fileDescriptor in {@link FileSystemOperation}.
 * These should never be interchanged. The best thing to do would be to declare
 * FileDescriptor field in your FileAttributesProvider class as final. And always return it
 * on calls to {@link FileAttributesProvider#getFileDescriptor() }.
 * Similarly for FileId one should use {@link jpfm.FileId#implies(jpfm.FileDescriptor)  } <br/>
 * <br/>
 * <br/>
 * <br/>
 * <br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.
 * Users of this should understand that implementation might be backed by FUSE or some other
 * alternative to pismo file mount. Below we have included documentation from pismo only.
 * Differences (if any) with other implementation can be taken care of internally, but
 * some subtle difference might still appear.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ } <br/><br/>
 * Pismo File Mount is a operating system extension that
 * enables access and modification to user and program data through
 * the file system interface of the operating system. By exposing
 * data through the file system, problems can elegantly and
 * efficiently be solved that otherwise require less flexible
 * and more resource intensive solutions.
 * <br/>
 * Pismo File Mount works by enabling user mode file systems to
 * present file data through a virtual mount point on an existing local,
 * remote, or removable drive. The virtual mount point is created in
 * place on top of an existing file.
 * Typically the mount point file is an archive or data file whose data is
 * being exposed by the user mode file system,
 * but purely virtual file systems are also possible.
 * While mounted, the mount point file appears as a folder
 * whose contents are served by the user mode file system.
 * <br/>
 *
 * @see FileAttributesProvider
 * @see FileDescriptor
 * @see BasicFileSystem
 * @author Shashank Tulsyan
 */
public interface AsynchronousFileSystem {
    public void capacity(final Capacity capacity)throws Exception;
    public void close(final Close close)throws Exception;
    public void control(final Control control)throws Exception;
    public void delete(final Delete delete)throws Exception;
    public void flushFile(final FlushFile flushFile)throws Exception;
    public void flushMedia(final FlushMedia flushMedia)throws Exception;
    public void list(final List list)throws Exception;
    public void mediaInfo(final MediaInfo mediaInfo)throws Exception;
    public void move(final Move move)throws Exception;
    public void moveReplace(final MoveReplace moveReplace)throws Exception;
    public void open(final Open open)throws Exception;
    public void read(final Read read)throws Exception;
    public void replace(final Replace replace )throws Exception;
    public void setSize(final SetSize setSize)throws Exception;
    public void write(final Write write)throws Exception;
    @Blocking(getReasonWhyItDoesNotMatter="assuming that getFileAttributes consumes negligible time to complete, and files metainfo is not backed by a slow source.")
    public FileAttributesProvider getFileAttributes(FileId fileDescriptor);

    /**
     * This functions is never called. The only reason for this is
     * to make it impossible (without hacks) to simultaneously implement
     * both {@link AsynchronousFileSystem} and {@link BasicFileSystem}.
     * A filesytem cannot be both Basic and Asynchronous .
     * Null may be returned.
     * @return null
     */
    Type.ASYNCHRONOUS getType();
}
