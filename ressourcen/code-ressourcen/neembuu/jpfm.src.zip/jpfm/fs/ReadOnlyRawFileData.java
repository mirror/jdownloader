/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs;

import jpfm.operations.readwrite.ReadRequest;
import java.nio.ByteBuffer;
/**
 *
 * @author Shashank Tulsyan
 */
public interface ReadOnlyRawFileData {
    /**
     * DataGlimpse is basically a little data of this
     * file from zero offset. Before calling {@link #read(jpfm.operations.readwrite.ReadRequest) }
     * this should be used and on basis of this data alone it should be decided
     * whether the filesystem can handle the given file archive. <br/><br/>
     * Initially the use of {@link #read(jpfm.operations.readwrite.ReadRequest) } must be
     * avoided as far as possible because the file might be from an slow source.
     * @return
     */
    ByteBuffer getDataGlimpse();
    /**
     * @return the name of this file
     */
    String getName();
    void read(ReadRequest readRequest)throws Exception;
    long getFileSize();
    boolean isOpen();
    void close();
}
