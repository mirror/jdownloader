/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.mount;

import java.util.logging.Level;
import jpfm.JPfm;
import jpfm.MountException;
import jpfm.annotations.Blocking;

/**
 *
 * @author Shashank Tulsyan
 */
public final class Mounts {

    private static volatile MountProvider mountProvider = null;

    private Mounts() {
    }

    /**
     *
     *
     * <u>Note</u> : If {@link JPfm#setManager(jpfm.JPfm.Manager) } was not
     * invoked before calling this method, then the default manager is set
     * using {@link JPfm#setDefaultManager() }.
     * This returns only when mounting has been successful. Throws an exception
     * if mounting failed.
     * @param mountParams
     * @return
     * @throws jpfm.MountException
     */
    @Blocking(getReasonWhyItDoesNotMatter="Non blocking mounting would actually make things unnecessarily complex for programmer" )
    public static Mount mount(MountParams mountParams) throws jpfm.MountException {
        if(mountProvider==null){
            JPfm.Manager m = JPfm.setDefaultManager();
            m.getLogger().log(Level.INFO, "Using DefaultManager because no manager was set before invoking jpfm.mount.Mounts.mount(jpfm.mount.MountParams)");
        }
        return mountProvider.mount(mountParams);
    }

    /**
     * used by spi
     * @param mountProvider
     */
    public static synchronized void setMountProvider(
            JPfm jPfm,
            MountProvider mountProvider){
        if(jPfm==null)
            throw new IllegalArgumentException("Only jpfm.JPfm can call this method, or those who have a valid jpfm instance");
        if(!(jPfm instanceof JPfm))
            throw new IllegalArgumentException("Only jpfm.JPfm can call this method, or those who have a valid jpfm instance");
        Mounts.mountProvider = mountProvider;
    }

}
