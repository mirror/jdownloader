/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.mount;

import java.util.EnumMap;
import java.util.Map;
import jpfm.MountListener;
import jpfm.VolumeFlags;
import jpfm.VolumeVisibility;
import jpfm.fs.AsynchronousFileSystem;
import jpfm.fs.BasicFileSystem;
import jpfm.mount.MountParams.ParamType;

/**
 *
 * @author Shashank Tulsyan
 */
public final class MountParamsBuilder {
    private final Map<ParamType,Object> parammap
            = new EnumMap<ParamType, Object>(ParamType.class); //ConcurrentHashMap<ParamType, Object>();

    public MountParamsBuilder set(ParamType paramType, Object param){
        switch(paramType){
            case EXIT_ON_UNMOUNT:
                if(!(param instanceof Boolean)) throw new IllegalArgumentException("EXIT_ON_UNMOUNT takes only boolean values");
                break;
            case FILE_SYSTEM:
                if(!(param instanceof AsynchronousFileSystem)
                        && !(param instanceof BasicFileSystem) )
                    throw new IllegalArgumentException("FILE_SYSTEM should be an instance of either jpfm.fs.AsynchronousFileSystem or jpfm.fs.BasicFileSystem");
                break;
            case LISTENER:
                if(!(param instanceof MountListener))
                    throw new IllegalArgumentException("LISTENER should be an instance of jpfm.UnderprivilegedFormatterListener or null");
                break;
            case MOUNT_FLAGS:
                if(!(param instanceof MountFlags))
                    throw new IllegalArgumentException("MOUNT_FLAGS should be an instance of jpfm.mount.MountFlags or null");
                break;
            case MOUNT_LOCATION:
                boolean illegal = (!(param instanceof String)
                        && !(param instanceof java.io.File)
                        && !(param instanceof MountLocation)
                        );
                try{
                    if( (Class.forName("java.nio.file.Path").isInstance(param)) ){
                        illegal = false;
                    }
                }catch(ClassNotFoundException cnfe){
                    //cnfe.printStackTrace();
                    //ignore
                }
                if(illegal)
                    throw new IllegalArgumentException("MOUNT_LOCATION should be an instance of java.lang.String or java.io.File or java.nio.Path. This parameter should not be null.");
                parammap.put(paramType,param); // tostring works on all 4 :)
                return this;
                //break;
            case VOLUME_FLAGS:
                if(!(param instanceof VolumeFlags))
                    throw new IllegalArgumentException("VOLUME_FLAGS should be an instance of jpfm.VolumeFlags or null");
                break;
            case VOLUME_VISIBILITY:
                break;
        }

        parammap.put(paramType, param);
        return this;
    }

    public MountParams build(){
        // TODO :
        // write checks such that atleast
        if(parammap.get(ParamType.MOUNT_FLAGS)==null){
            parammap.put(ParamType.MOUNT_FLAGS,new MountFlags.Builder().build());
        }
        if(parammap.get(ParamType.MOUNT_LOCATION)==null){
            throw new IllegalArgumentException("No mountlocation specified");
        }
        if(parammap.get(ParamType.EXIT_ON_UNMOUNT)==null){
            parammap.put(ParamType.EXIT_ON_UNMOUNT,false);
        }
        if(parammap.get(ParamType.FILE_SYSTEM)==null){
            throw new IllegalArgumentException("No filesystem operations handler specified.");
        }
        if(parammap.get(ParamType.VOLUME_VISIBILITY)==null){
            parammap.put(ParamType.VOLUME_VISIBILITY,VolumeVisibility.GLOBAL);
        }
        if(parammap.get(ParamType.VOLUME_FLAGS)==null){
            parammap.put(ParamType.VOLUME_FLAGS,new VolumeFlags.Builder().build());
        }
        boolean exists = new java.io.File(parammap.get(ParamType.MOUNT_LOCATION).toString()).exists();
        if(!exists)
            throw new IllegalArgumentException("Mount location specified does not exists");
        return new MountParams(parammap);
    }
}
