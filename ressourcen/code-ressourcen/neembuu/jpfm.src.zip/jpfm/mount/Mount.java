/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.mount;

import jpfm.JPfm;
import jpfm.UnmountException;
import jpfm.VolumeVisibility;

/**
 *
 * @author Shashank Tulsyan
 */
public interface Mount {

    /**
     * @return Gives a system wide unique id for representing this mount.
     */
    MountId getMountId();

    /**
     * The location where the abstract volume appears in the
     * operating system's/native filesystem
     * @return the mount location
     */
    MountLocation getMountLocation();
    
    VolumeVisibility getVolumeVisibility();

    /**
     * @return true if the formatter is in a mounted to the location
     * specified and is in a usable state
     */
    boolean isMounted();

    /** 
     * Unmounts the volume. For remounting a new JPfmMount instance has to be created
     * If the volume had already been unmounted, then this simply returns
     * @throws UnmountException
     */
    void unMount() throws UnmountException;

    /**
     * The access to ThreadGroup is protected by ensuring that caller
     * provides the Manager instance which is 
     * @param manager
     * @return the threadgroup in which the native filesystem threads are running
     */
    ThreadGroup getThreadGroup(JPfm.Manager manager);

}
