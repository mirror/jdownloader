/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.mount;

import java.util.LinkedList;

/**
 *
 * @author Shashank Tulsyan
 */
public final class MountLocation {
    final String[]mountLocation;
    final char driveLetter;
    final boolean isCascadePath;

    public MountLocation(String mountLocation) {
        this(mountLocation,false);
    }

    public MountLocation(String mountLocation, boolean isCascadePath) {

        // TODO : add code to check file path validity
        // add code to check this split statement
        String[]tmot = split(mountLocation, java.io.File.separatorChar);
                //mountLocation.split(java.io.File.separator); 

        if(mountLocation.trim().charAt(1)==':'
                && Character.isLetter(mountLocation.trim().charAt(0))
                && tmot.length == 1){
            this.driveLetter = mountLocation.trim().charAt(0);
        }
        else this.driveLetter = '\0';
        this.isCascadePath = isCascadePath;
        this.mountLocation = tmot;
    }

    public MountLocation(String[] mountLocation, boolean isCascadePath) {
        this(mountLocation,'\0',isCascadePath);
    }

    public MountLocation(String[] mountLocation, char driveLetter, boolean isCascadePath) {
        this.mountLocation = mountLocation;
        this.driveLetter = driveLetter;
        this.isCascadePath = isCascadePath;
    }

    public java.io.File getAsFile(){
        return new java.io.File(mergePath());
    }

    public Object getAsPath(){ // jdk7 path
        try{
            Object l = Class.forName("java.nio.file.Paths").getDeclaredMethod("get", String.class).invoke(null, mergePath());
            return l;
        }catch(Exception any){
            throw new UnsupportedOperationException(any);
        }
    }

    @Override
    public final String toString() {
        return mergePath();
    }

    /**
     * Mounting on drives is not supported
     * everywhere, which is why, mountlocation and drive letter both are
     * used a mounts points. So in case of windows, mounted volume is
     * accessible from 2 places.
     * @return  '\0' if mount location is not a windows drive else the
     * mountlocation drive letter. 
     */
    public final char getDriveLetter() {
        return driveLetter;
    }

    public final String[]get(){
        return mountLocation;
    }

    private final String mergePath(){
        StringBuilder b = new StringBuilder();
        for(String s : mountLocation){
            b.append(s);
            b.append(java.io.File.separatorChar);
        }return b.toString();
    }

    private static String[] split(String path, char separator){
        LinkedList<String> l = new LinkedList<String>();
        int lastIndex = 0;
        for (
                int currentIndex = 0; 
                currentIndex < path.length(); 
                currentIndex++) {
            
            if(path.charAt(currentIndex)==separator){
                l.add(path.substring(lastIndex,currentIndex));
                lastIndex=currentIndex+1;
            }
        }
        l.add(path.substring(lastIndex));
        
        return l.toArray(new String[0]);
    }
}
