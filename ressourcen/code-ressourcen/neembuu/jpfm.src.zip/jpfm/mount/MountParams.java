/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.mount;

import java.util.Map;

/**
 *
 * @author Shashank Tulsyan
 */
public final class MountParams {


    public enum ParamType {
        /**
         * The filesytem which should be used to list contents of folders and read files.
         * Only instances of {@link jpfm.fs.AsynchronousFileSystem }
         * and {@link jpfm.fs.BasicFileSystem } allowed .
         * <br/><b>Null not allowed </b>
         */
        FILE_SYSTEM,
        /**
         * The location where the abstract volume should be mounted.
         * File path as a String, java.nio.file.Path, java.io.File or jpfm.mount.MountLocation are acceptable.
         * The path must represent an path accessible by native filesystem, it does not matter that
         * if the path lies inside a virtual filesystem, the main thing is  : <b>the file must exist.</b>. <br/>
         * If file does not exist an exception is thrown rather than attempting to create one.
         * There is a reason for this. For example, the mountlocation could be pointing to a non existing
         * file in cdrom. We cannot create this file, therfore the mount would fail.
         * So we leave the problem of assuring the validity to the users of this api.<br/>
         * One windows, files are preferred mount location as this does not require admin user privileges.
         * <br/><b>Null not allowed </b>
         */
        MOUNT_LOCATION,
        /**
         * only instances of {@link jpfm.mount.MountFlags } expected
         */
        MOUNT_FLAGS,
        /**
         * Only instances of {@link jpfm.UnderprivilegedFormatterListener } expected.
         * <br/><b>Null allowed </b>
         */
        LISTENER,
        /**
         * boolean expected.
         * If true means that System.exit will be invoked when the volume is unmounted.<br/>
         * Forcefully by external application or by invoking {@link jpfm.mount.Mount#unMount() }.
         * <br/><b>default value is false</b>
         */
        EXIT_ON_UNMOUNT,
        /**
         *
         * only instances of {@link jpfm.VolumeVisibility } expected
         * <br/><b>default value is  {@link jpfm.VolumeVisibility#GLOBAL } </b>
         */
        VOLUME_VISIBILITY,
        /**
         * Only instances of {@link jpfm.VolumeFlags } expected.
         * This is ignored in the case when {@link jpfm.fs.BasicFileSystem} is being mounted.
         * <br/><b>By default volumes are specified to be case insensitive. } </b>
         * Default value is {@link jpfm.VolumeFlags#SIMPLE_FLAG}
         */
        VOLUME_FLAGS
    }

    private final Map<ParamType, Object> parammap;

    MountParams(Map<ParamType, Object> parammap) {
        this.parammap = parammap;
    }



    public Object getParamValue(ParamType paramType){
        return parammap.get(paramType);
    }
}
