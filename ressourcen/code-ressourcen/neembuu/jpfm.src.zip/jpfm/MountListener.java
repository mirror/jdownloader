/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   MountListener.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.util.concurrent.CountDownLatch;

/**
 * These can be used to listener to various
 * messages (informative, error, warning ...)
 * from both native side and java side of jpfm.
 * The messages are wrapped around {@link FormatterEvent }.
 * On printing on screen it looks like this : <br/>
 * <pre>
 * Formatter Event {Mount = NeembuuVirtualFileSystem@j:\neembuu\virtual\monitored.nbvfs (mountid=7)}{MESSAGE : Just going to dispatch formatter.}
 * Formatter Event {Mount = NeembuuVirtualFileSystem@j:\neembuu\virtual\monitored.nbvfs (mountid=7)}{SUCCESSFULLY_MOUNTED :  }
 * </pre>
 * Please note that these messages and string format is only for debugging purposes
 * this is not a part of the api and may change anytime. In such cases any code
 * depending on it might fail to work.
 * Also note that the messages that are send depend highly on platform and version
 * of jpfm. These can also change anytime. <br/>
 * You may however code that acts according to {@link jpfm.FormatterEvent.EVENT }.
 * That is {@link jpfm.FormatterEvent.EVENT#SUCCESSFULLY_MOUNTED } means SUCCESSFULLY_MOUNTED,
 * and this is a meaningful event for both api user and actual user of the program.<br/>
 * Do no write code that relies on the message that is accompanied
 * with a formatter event. The end users might find these messages ugly and meaningless 
 * so a these messages should be simply logged for instead.
 * @author Shashank Tulsyan
 */
public interface MountListener {

    public void eventOccurred(FormatterEvent event);

    public class WaitingMountListener implements MountListener {

        CountDownLatch latch;

        public WaitingMountListener() {
            latch = new CountDownLatch(1);
        }

        public void waitUntilUnmounted(){
            try{
                latch.await();
            }catch(InterruptedException a){
                a.printStackTrace();
            }
        }

        public void eventOccurred(FormatterEvent event) {
            if(event.getEventType()==FormatterEvent.EVENT.DETACHED){
                latch.countDown();
            }
        }

    }
}
