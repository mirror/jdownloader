/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   FileAttributesProvider.java
 * Author: Shashank Tulsyan
 */
package jpfm;

/**
 * Represents a file or folder inside a mount.
 * The formatter is required to implement each and every method properly.
 * The methods
 * {@link  FileAttributesProvider#getAccessTime() }
 * {@link  FileAttributesProvider#getChangeTime()  }
 * {@link  FileAttributesProvider#getCreateTime() }
 * {@link  FileAttributesProvider#getWriteTime() }
 * can return 0 if correct values are not known.
 *
 * 
 *  FileAttributes provider are used to represent both file and folders.
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * <b>Folders are Files</b><br/>
 * The term file is regularly used in this document to
 * mean file or folder. Unless stated otherwise, all
 * PFM Protocol requests and related marshalled functions
 * work the same for files and folders.<br/><br/>
 * <b>File Names</b><br/>
 * The PFM Protocol represents all file names in UTF8.
 * The marshaller converts UTF8 file names to and from wchar_t
 * file names for use by the formatters.
 * The protocol and the driver support multiple named files,
 * or hard links. Formatters that support hard links make
 * use of the driver maintained parentFileId and endName in order
 * to identify which name for a file is being manipulated.
 * The protocol allows the formatter to return a case
 * corrected spelling for the last element of the name of
 * opened files. This case corrected name is used by the
 * driver when emulating short name aliases (DOS 8.3 file names).
 * Short names are still used by many applications,
 * including portions of Windows itself. Formatters that do
 * not provide the case corrected end name will have reduced
 * application compatibility.
 * @author Shashank Tulsyan
 */
public interface FileAttributesProvider {
//    typedef struct
//    {
//       PFM_INT8 fileType; //getFileType
//       PFM_UINT8 fileFlags;
//       PFM_UINT8 extraFlags;
//       PFM_UINT8 reserved1[5];
//       PFM_INT64 fileId; // filedescriptor used for this
//       PFM_UINT64 fileSize;
//       PFM_INT64 createTime;
//       PFM_INT64 accessTime;
//       PFM_INT64 writeTime;
//       PFM_INT64 changeTime;
//    } PfmAttribs;

    /**
     * @return true if is file false if is a directory(includes rootdirectory)
     */
    public FileType getFileType();

    /**
     * This is used by the native code.
     * Implementors should create a new FileDescriptor during initialization
     * of an instance, and return the same everytime.
     * Native side stores very important information in this, which is why
     * it is important that the same FileDescriptor is returned evertime.
     * @return FileDescriptor associated with this file/folder
     */
    //@NotNull
    public FileDescriptor getFileDescriptor();

    /**
     * Size of the file.
     * For folder this is irrelevant and is never invoked.
     * <br/><br/>
     * <u>Important </u> : <br/>
     * If the size of your files can change after the file is already open
     * for reading, the size change will not be observed by PFM or applications
     * being served. The size change is only observed if it occured
     * due to call of {@link jpfm.operations.SetSize} filesystem
     * operation call (if this is that case for you, you don 't need to
     * bother reading ahead.) <br/>
     * The workaround is, as soon as the file size changes,
     * do this :
     * <pre>fileDescriptor = new FileDescriptor();</pre>
     * This results in changes in the internal fileid of the file to invalid file id.
     * After this when the file is opened, it is assigned a valid id, and the new
     * file size is realized by PFM and applications being served.<br/>
     * So for all files with ability to change size internally must
     * declare fileDescriptor this way not setting it final.
     * <pre>private FileDescriptor fileDescriptor = new FileDescriptor();</pre>
     * If you wish to allow size changes only due to
     * call of {@link jpfm.operations.SetSize} filesystem
     * operation call you should do this instead.
     * <pre>private final FileDescriptor fileDescriptor = new FileDescriptor();</pre>
     * Declaring filedescriptor final prevents silly mistakes.
     * @return size of this file (if this represents a file)
     */
    public long getFileSize();

    /**
     * The number of milliseconds after the file was created since
     * January 1, 1970, 00:00:00 GMT
     * If not known, zero may be safely returned.
     * see java.util.Date
     * @return The time when this file/folder was created (Java time )
     * @see java.util.Date
     */
    public long getCreateTime();

    /**
     * The number of milliseconds after the file was last accessed since
     * January 1, 1970, 00:00:00 GMT
     * If not known, zero may be safely returned.
     * see java.util.Date
     * @return The time when this file/folder was created (Java time )
     * @see java.util.Date
     */
    public long getAccessTime();

    /**
     * The number of milliseconds after data was last written in the file since
     * January 1, 1970, 00:00:00 GMT
     * If not known, zero may be safely returned.
     * @return The time when this file/folder was created (Java time )
     * @see java.util.Date
     */
    public long getWriteTime();

    /**
     * The number of milliseconds after data (or metadata) of the file was changed since
     * January 1, 1970, 00:00:00 GMT
     * If not known, zero may be safely returned.
     * @return The time when this file/folder was created (Java time )
     * @see java.util.Date
     */
    public long getChangeTime();

    //@NotNull ?
    /**
     * The name of this file or folder/directory.
     * For root directory this is never invoked.
     * @return Name of this file/folder
     */
    public String getName();

//     unless the root is cascade
//     * mounted on a jpfm filesystem. In that case the value passed during
//     * {@link jpfm.fs.BasicCascadable#getFileSystem(jpfm.fs.ReadOnlyRawFileData[], java.lang.String) }
//     * call must be passed here as well, otherwise unexpected results will be obtained.
//     * Filesystems that are not cascadable do not need to bother themselves,
//     * this method will never be invoked on them.

    /**
     * The FileDescriptor of the parent folder/directory,
     * that is, the folder/directory in which this file/folder is.
     * @return parent directory's FileDescriptor
     */
    public FileDescriptor getParentFileDescriptor();

    /**
     * This should not be null. By default implementation could be : <br/>
     * <code>return new FileFlags.Builder().build();</code>
     * @return properties of the given file such as isExecutable, isReadOnly ...
     */
    public FileFlags getFileFlags();
}
