/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jpfm;

/**
 *
 * @author Shashank Tulsyan
 */
public final class ExceptionFormatterEvent extends FormatterEvent {
    private Throwable exception;
    private int lineNumber;
    private String fileName;
    public ExceptionFormatterEvent(Throwable exception,int lineNumber, String fileName) {
        super(FormatterEvent.EVENT.ERROR,exception.getMessage(),exception);
        this.exception=exception;
        this.lineNumber = lineNumber;
        this.fileName = fileName;
    }

    @Override
    public String toString() {
        return "{" + event + " : " + exception.getMessage() + "}" +
                "\n\tException details{ \n" +
                    "\t\tNative exception origin and message : "+fileName+" at line : "+lineNumber+"\n" +
                    "\t\tException class name : "+exception.getClass().getName()+"\n" +
                    "\t\tMessage : "+ exception.getMessage()+ "\n" +
                    "\t\tStack Trace : \n"+ getStackTraceString()+
                "\t}";
    }

    private String getStackTraceString(){
        StringBuilder ret = new StringBuilder();
        StackTraceElement[] els = exception.getStackTrace();
        for(StackTraceElement ele : els){
            ret.append("\t\t\t");;
            ret.append(ele.toString());
            ret.append("\n");
        }
        return ret.toString();
    }

}
