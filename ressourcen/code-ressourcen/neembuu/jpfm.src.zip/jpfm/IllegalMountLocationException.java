/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   IllegalMountLocationException.java
 * Author: Shashank Tulsyan
 */

package jpfm;

/**
 * This exception is thrown to indicate that mount location
 * is not legal. This happens when Mount location does not exist.
 * JPfm requires that mount location exists and does not create it
 * if the file/folder does not exist. This is because, the destination
 * might be for example a CD. In general we cannot create a file/folder in
 * a CD. This is why JPfm gives all responsibility of verifying the mountlocation
 * to the implementor.
 * On windows IllegalMountLocationException is not thrown if mounting is done
 * on a location on which some other filesystem is already mounted. So any
 * number of mounts could be made on the same location.
 * Illegal mount location exception is also thrown if the program does not
 * have priveledges to mount at a given location, already that loction is
 * perfectly valid. That is why implementors should try to mount on
 * files instead of drive location or folders.
 * @author Shashank Tulsyan
 */
public class IllegalMountLocationException extends MountException {

    public IllegalMountLocationException() {
    }

    public IllegalMountLocationException(String mess) {
        super(mess);
    }

}
