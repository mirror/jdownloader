/**
 * JPfm is a java language binding for Pismo file mount ( http://www.pismotechnic.com/pfm/ ). </p>
 * </p>
 * Pismo File Mount has been created by Joe Lowe.
 * JPfm was originally create by Shashank Tulsyan specifically
 * for Neembuu http://neembuu.sourceforge.net/ 
 * but evolved in such a fashion as to allow more diverse usage.
 * JPfm site : http://jpfm.sourceforge.net/
 * <br/><br/>
 * <u>Pismo file mount</u><br/>
 * PFM provide functionality that is built into Linux as FUSE,
 * and is freely available for Mac as MacFUSE.
 * <br/><br/>
 * The native Windows file system model is very different than the
 * file system model on unix-like operating systems.
 * This difference is hard to imagine by developers
 * that have mostly dealt with either user mode Win32 or unix.
 * Though a FUSE for windows type of technology is possible,
 * in the end it would probably require so many Windows specific
 * changes that it would end up being about the same as using
 * PFM on Windows.
 * <br/><br/>
 * <u>Where to start ?</u>
 * Implementors interested in making a readonly filesystem (functions other than read are intrinsically
 * blocking nature) quickly should start with reading {@link jpfm.JPfmReadOnlyFormatter } .
 * For making a readonly or writable filesystem with all filesystem function that
 * are non-blocking in nature should directly go to {@link jpfm.JPfmFormatter } .
 * If you intend to use jpfm is your project the fastest way would be to
 * have a look at one of the sample implementation in jpfm.fs package in
 * jpfm-fs project.
 * <br/><br/>
 * <u>Note</u> : jpfm.jar contains the bare minimum classes and native dynamic
 * libraries required, which require jdk6 , and jpfm-fs.jar contains
 * sample implementations some of which require jdk7.
 */
package jpfm;

