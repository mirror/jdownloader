/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.LinkedList;
import jpfm.operations.readwrite.Completer;

/**
 * There is atleast one <pre>complete</pre> function in every class implementing FileSystemOperation.
 * <pre>complete</pre> function can be called only once. If an attempt is made to call it again
 * an {@link AlreadyCompleteException} is thrown. <br/>
 * AlreadyCompleteException is also thrown at other occassion like when
 * {@link List#add(jpfm.FileAttributesProvider) } is called after already having
 * called complete.<br/>
 * In case of  {@link Read} the error message may also includes that name of the
 * object which invoked the complete function.
 * @author Shashank Tulsyan
 */
public final class AlreadyCompleteException extends IllegalStateException {

    public AlreadyCompleteException() {
    }

    public AlreadyCompleteException(String message) {
        super(message);
    }

    /*package private*/static AlreadyCompleteException createNew(){
        return new AlreadyCompleteException("Complete method has already been called. complete(..) method can be invoked only once.");
    }

    /*package private*/static AlreadyCompleteException createNew(Completer completer){
        if(completer==null){
            return new AlreadyCompleteException("Complete method was already called somewhere. Read.complete(..) method can be invoked only once.");
        }
        return new AlreadyCompleteException("Complete method has already been called by "+completer+" . Read.complete(..) method can be invoked only once.");
    }

    public static AlreadyCompleteException createNew(Completer truecompleter, Completer possiblyunauthorizedcompleter){
        String trueCompleterName = "someone";
        String possiblyUnauthorizedCompleterName = "someone";

        if(truecompleter!=null)trueCompleterName = truecompleter.toString();
        if(possiblyunauthorizedcompleter!=null)possiblyUnauthorizedCompleterName = possiblyunauthorizedcompleter.toString();
        AlreadyCompleteException ace = new AlreadyCompleteException(
                "Complete method has already been called by "+trueCompleterName+". Yet "
                +possiblyUnauthorizedCompleterName+" was trying to complete this again. Read.complete(..) method can be invoked only once. ");
        StackTraceElement fakeEntry = new StackTraceElement("------------------", "Possibly Unauthorized Completer","------------------",0);
        LinkedList<StackTraceElement> lst = new LinkedList<StackTraceElement>();
        if(ace.getStackTrace()!=null){
            addArray(lst, ace.getStackTrace());
        }
        lst.add(fakeEntry);
        if(truecompleter!=null){
            if(truecompleter.getStackTrace()!=null)
                addArray(lst, truecompleter.getStackTrace());
        }
        lst.add(fakeEntry);
        if(possiblyunauthorizedcompleter!=null){
            if(possiblyunauthorizedcompleter.getStackTrace()!=null)
                addArray(lst, possiblyunauthorizedcompleter.getStackTrace());
        }
        ace.setStackTrace(lst.toArray(new StackTraceElement[0]));
        return ace;

    }

    /*package private*/static IllegalArgumentException createNewIllegalArgEx(Completer truecompleter, Completer possiblyunauthorizedcompleter){
        String trueCompleterName = "someone";
        String possiblyUnauthorizedCompleterName = "someone";

        if(truecompleter!=null)trueCompleterName = truecompleter.toString();
        if(possiblyunauthorizedcompleter!=null)possiblyUnauthorizedCompleterName = possiblyunauthorizedcompleter.toString();
        IllegalArgumentException ace = new IllegalArgumentException(
                "Complete method was already been called by "+trueCompleterName+". Yet "
                +possiblyUnauthorizedCompleterName+" was trying to complete this again. Read.complete(..) method can be invoked only once. ");
        StackTraceElement fakeEntry = new StackTraceElement("---", "---","---",0);
        LinkedList<StackTraceElement> lst = new LinkedList<StackTraceElement>();
        if(ace.getStackTrace()!=null){
            addArray(lst, ace.getStackTrace());
        }
        lst.add(fakeEntry);
        if(truecompleter!=null){
            if(truecompleter.getStackTrace()!=null)
                addArray(lst, truecompleter.getStackTrace());
        }
        lst.add(fakeEntry);
        if(possiblyunauthorizedcompleter!=null){
            if(possiblyunauthorizedcompleter.getStackTrace()!=null)
                addArray(lst, possiblyunauthorizedcompleter.getStackTrace());
        }
        ace.setStackTrace(lst.toArray(new StackTraceElement[0]));
        return ace;
    }

    private static void addArray(java.util.LinkedList<StackTraceElement> store, StackTraceElement[]eles){
        for (StackTraceElement stackTraceElement : eles) {
            store.add(stackTraceElement);
        }
    }
}
