/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.FileId;
import jpfm.JPfmError;

/**
 * This has not been implemented entirely as the structure is system
 * dependent, and porting to linux and mac is in progress so we are not
 * sure how extactly this will be implemented.
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * The driver sends a media info request to retrieve media
 * identification information such as media label and media id.
 * Formatters are free to fail this request, or to return only
 * partial information.
 * <br/><br/>
 * In case of windows the returned information can be accessed
 * by client applications using the Win32 GetVolumeInformation()
 * system call.<br/><br/>
 * The supplied open ID may be zero, or may be the id of an open
 * file or folder. The formatter is free to ignore the open id
 * or to return different information based on what file or folder
 * the open id refers to.<br/><br/>
 * If a media label is returned then the marshaller will call
 * the PfmReadOnlyFormatterOps::ReleaseName function to allow the
 * formatter to free any related memory.
 * @see jpfm.JPfmFileSystem#mediaInfo(jpfm.operations.MediaInfoImpl)
 * @author Shashank Tulsyan
 */
public final class MediaInfoImpl extends FileSystemOperationImpl implements MediaInfo {
//struct PfmMarshallerMediaInfoOp
//{
//   virtual PFM_INT64 PFM_CCALL OpenId(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError,const PfmMediaInfo* mediaInfo,const wchar_t* mediaLabel) = 0;
//};


    private final long handle;
    private final long formatterDispatch;
    private final long fileId;

    private final AtomicBoolean completed = new AtomicBoolean(false);


    /*package private*/ MediaInfoImpl(final long handle, final long formatterDispatch,final long fileId) {
        this.handle = handle;
        this.formatterDispatch =  formatterDispatch;
        this.fileId = fileId;
    }

    public final FileId getFileId() {
        return FILEID_BUILDER.constructFileId(fileId);
    }

    public final void complete(final JPfmError pfmError,final Media media,final String mediaLabel) throws IllegalStateException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeMediaInfo(handle,formatterDispatch, pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode(),media,mediaLabel);
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    
    public final boolean isCompleted() {
        return completed.get();
    }


    public final void handleUnexpectedCompletion(final Exception exception){
        if(!isCompleted()){
            this.complete(JPfmError.FAILED,null,"");
        }
    }
    @Override
    public String toString() {
        return "MediaInfo{"+ fileId + "}";
    }
}
