/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.lang.annotation.Annotation;
import jpfm.annotations.Blocking;
import jpfm.annotations.MightBeBlocking;
import jpfm.annotations.NonBlocking;
import jpfm.annotations.PartiallyCompleting;

/**
 *
 * @author Shashank Tulsyan
 */
public enum RequestHandlingApproach {

    

    /**
     * @see NonBlocking
     */
    NON_BLOCKING(new Annotation() {

        public Class<? extends Annotation> annotationType() {
            return NonBlocking.class;
        }

        @Override
        public String toString() {
            return NonBlocking.class.toString();
        }
    }) ,
    /**
     * @see Blocking
     */
    BLOCKING(new Annotation() {

        public Class<? extends Annotation> annotationType() {
            return Blocking.class;
        }

        @Override
        public String toString() {
            return Blocking.class.toString();
        }
    }),
    /**
     * @see PartiallyCompleting
     */
    PARTIALLY_COMPLETING(new Annotation() {

        public Class<? extends Annotation> annotationType() {
            return PartiallyCompleting.class;
        }

        @Override
        public String toString() {
            return PartiallyCompleting.class.toString();
        }
    });

    private final Annotation asAnnotation;

    private RequestHandlingApproach(Annotation asAnnotation) {
        this.asAnnotation = asAnnotation;
    }

    public final Annotation getAsAnnotation() {
        return asAnnotation;
    }

    /**
     *
     * @return 0 is equal, 1 is not equal, -1 if incomparable by this function
     * 2 if the annotation type is MightBeBlocking
     */
    public static int isEqual(
            RequestHandlingApproach approach,
            Annotation annotation){

        if( annotation.annotationType().equals(MightBeBlocking.class))
            return 2;
        if(
            annotation.annotationType().equals(NonBlocking.class)
            ||
            annotation.annotationType().equals(Blocking.class)
            ||
            annotation.annotationType().equals(PartiallyCompleting.class)
        ){
            if(annotation.annotationType().equals(approach.getAsAnnotation().annotationType())){
                return 0;
            }return 1;
        } else return -1;
    }
}
