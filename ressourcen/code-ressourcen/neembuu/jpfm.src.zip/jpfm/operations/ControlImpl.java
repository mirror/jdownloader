/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.AccessLevel;
import jpfm.FileId;
import jpfm.JPfmError;



/**
 * This can be used for passing messages to a running instance of JPfmFileSystem
 * making PFM api function calls from some other process. So this is for simplyfying
 * interprocess communication.
 * The mountId {@link JPfmMount#getMountId() }
 * or mountlocation {@link JPfmMount#getMountLocation()}  can be used to find
 * the correct PfmMount. Then on this control can be
 * invoked (function description and prototype below).
 * If possible mountId {@link JPfmMount#getMountId() }  should be used
 * since there can be more than one instance mounted at a given mount location.
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileDescriptor<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * <b>PfmMount interface</b><br/>
 * The PfmMount interface is defined in pfmapi.h . Some constants and flags are defined in pfmenum.h .
 * This interface allows applications to query information about, and control, an existing file mount. This interface is returned from the PfmApi::MountCreate, PfmApi::MountOpen, and PfmApi::MountOpenId functions.
 * <pre>
 * int  PfmMount::ControlImpl (
 * int         controlCode ,
 * const void* input ,
 * size_t      inputSize ,
 * void*       output ,
 * size_t      maxOutputSize ,
 * size_t*     outputSize )
 * </pre>
 * Send a formatter specific control code through to the formatter.
 * Formatters using PfmMarshaller will see a the control code
 * via a call to PfmReadOnlyFormatterOps::ControlImpl
 * or PfmFormatterOps::ControlImpl. <br/><br/>
 * Since control codes are formatter specific, applications must
 * identify the formatter before sending control codes.
 * This can be done using PfmMount::GetFormatterName function.<br/><br/>
 * Formatters should number their control codes starting at
 * zero or one and not leave gaps. The range of available
 * control codes is limited and is not guaranteed to remain constant.<br/><br/>
 * @see jpfm.JPfmFileSystem#control(jpfm.operations.ControlImpl)
 * @see jpfm.JPfmMount#getMountId() 
 * @author Shashank Tulsyan
 */
//Not implemented unless required
public final class ControlImpl extends FileSystemOperationImpl implements Control {
//struct PfmMarshallerControlOp
//{
//   virtual PFM_INT64   PFM_CCALL OpenId(void) = 0;
//   virtual PFM_INT8    PFM_CCALL AccessLevel(void) = 0;
//   virtual int         PFM_CCALL ControlCode(void) = 0;
//   virtual const void* PFM_CCALL Input(void) = 0;
//   virtual size_t      PFM_CCALL InputSize(void) = 0;
//   virtual void*       PFM_CCALL Output(void) = 0;
//   virtual size_t      PFM_CCALL MaxOutputSize(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError,size_t outputSize) = 0;
//};

    private final long handle;
    private final long formatterDispatch;
    private final AccessLevel accessLevel;
    private final int controlCode;
    private final ByteBuffer input;
    private final ByteBuffer output;
    private final long fileId;

    private final AtomicBoolean completed = new AtomicBoolean(false);


    /*package private*/ ControlImpl(
            final long handle,
            final long formatterDispatch,
            final AccessLevel accessLevel,
            final int controlCode,
            final ByteBuffer input,
            final ByteBuffer output,
            final long fileid) {
        
        this.handle = handle;
        this.formatterDispatch = formatterDispatch;
        this.accessLevel = accessLevel;
        this.controlCode = controlCode;
        this.input = input;
        this.output = output;
        this.fileId = fileid;
    }

    public final AccessLevel getAccessLevel() {
        return accessLevel;
    }

    public final int getControlCode() {
        return controlCode;
    }

    public final FileId getFileId() {
        return FILEID_BUILDER.constructFileId(fileId);
    }

    public final ByteBuffer getInputBuffer() {
        return input;
    }

    public final ByteBuffer getOutputBuffer() {
        return output;
    }

    public final boolean isCompleted() {
        return completed.get();
    }


    public final void complete(final JPfmError pfmError,final int actualOutputSize)throws IllegalStateException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeControl(handle, formatterDispatch,pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode(),actualOutputSize);
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    

    public final void handleUnexpectedCompletion(final Exception exception){
        if(!isCompleted()){
            this.complete(JPfmError.FAILED,0);
        }
    }


    @Override
    public String toString() {
        return "Control{ Controlcode="+ controlCode +" , "+ getFileId() + "}";
    }

}
