/*
 *  Copyright 2010 Shashank Tulsyan
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileId;
import jpfm.JPfmError;

/**
 * {@link jpfm.JPfmFileSystem#list(jpfm.operations.ListImpl) }
 * is invoked only on directories, when some application wants to view the 
 * contents of the directory. <br/>
 * {@link ListImpl#add(jpfm.FileAttributesProvider) } function should be invoked to add
 * files to the list of the directory being listed.
 * If each <b>add</b> operation is not atomic
 * will cause the client application to be in a not responding state until 
 * complete method is called. Atmoic nature of <b>add</b> allows partially listing
 * the directory and more responsiveness of the client application.
 * That is why in pfm it is implemented in an atomic fashion.
 * In {@link jpfm.JPfmFileSystem} atomic listing is supported, but not in
 * {@link jpfm.JPfmBasicFileSystem } .  For this reason, implementors of
 * FTPFileSytem should use {@link jpfm.JPfmFileSystem} even if they do not
 * plan to support write operations.
 * Support for atomically listing directories
 * was also not implemented in java io/nio until jdk7.
 * When all files have been added, {@link ListImpl#complete(jpfm.JPfmError, boolean) }
 * should be called and the boolean filled should be set to true.
 * The <pre>noMore</pre> field might be set to false, for example in case
 * of FTPFileSystem. In FTPFileSystem, the list of the files is being
 * retrieved from a remote source. This might take time, so if it is taking really long
 * or some error occurs, {@link ListImpl#complete(jpfm.JPfmError, boolean) } could be
 * called with <b>noMore</b> set as true.
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileId<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * This function is called by the marshaller to generate
 * list results for the contents of folders.<br/><br/>
 * The behavior of this function for non-folder files
 * is undefined. Formatters are free to handle this
 * in whatever way is convenient.<br/><br/>
 * The formatter must create and maintain state information
 * for each unique listId parameter that is used to list
 * contents of a folder. The formatter should create this
 * state when it sees a new listId. The formatter frees
 * this state when it receives a call to PfmReadOnlyFormatterOps::ListEndImpl
 * with a matching openId/listId, or when it frees resources
 * associated with an open folder wile processing a call to
 * PfmReadOnlyFormatterOps::Close for the same openId.<br/><br/>
 * Folder contents are added to the results by repeatedly
 * calling the PfmMarshallerListResult::Add or
 * PfmMarshallerListResult::Add8 functions of the listResult
 * parameter, followed by a final call to the
 * PfmMarshallerListResult::NoMore. <br/><br/>
 * @see jpfm.JPfmFileSystem#list(jpfm.operations.ListImpl)
 * @author Shashank Tulsyan
 */
public final class ListImpl extends FileSystemOperationImpl implements List {
//    struct PfmMarshallerListOp
//    {
//       virtual PFM_INT64 PFM_CCALL OpenId(void) = 0;
//       virtual PFM_INT64 PFM_CCALL ListId(void) = 0;
//       virtual bool/*added*/ PFM_CCALL Add(const PfmAttribs* attribs,const wchar_t* endName) = 0;
//       virtual bool/*added*/ PFM_CCALL Add8(const PfmAttribs* attribs,const char* endName) = 0; << not supported
//       virtual void PFM_CCALL Complete(int pfmError,bool noMore) = 0;
//    };

//struct JpfmContentList {                both   32-bit  64-bit
//    JpfmContentList  *next ;                    4        8
//    PfmAttribs attribs;                 50
//    wchar_t  * contentNames;                    4        8
//                                                58      66  
//
//    JpfmContentList(JpfmContentList * previousElement);
//    JpfmContentList();
//
//    int fillListOp(JNIEnv *env, JPfmReadOnlyFormatterDispatch * formatterDispatch, jobject iterator,PfmMarshallerListOp* listop);
//
//
//    ~JpfmContentList();
//};
//struct PfmAttribs                     both
//{
//   int8_t   fileType ;                 1
//   uint8_t  fileFlags ;                1
//   int64_t  fileId ;                   8 1
//   uint64_t fileSize ;                 8 2
//   int64_t  createTime ;               8 3
//   int64_t  accessTime ;               8 4
//   int64_t  writeTime ;                8 5
//   int64_t  changeTime ;               8 6
//}
//                                   total = 6*8 + 2 = 50


    private final long handle;
    private final long formatterDispatch;
    private final long fileId;
    private final long listId;
    private final long jpfmContentListHandle ;

    private final LinkedList<FileAttributesProvider> fileAttributes = new LinkedList<FileAttributesProvider>();

    
    private final AtomicBoolean completed = new AtomicBoolean(false);//why? because other threads could have completed the job without other thread knowing

    /*package private*/ public ListImpl(final long handle,final long formatterDispatch,final long fileId,final long listId,final long jpfmContentListHandle){
        this.fileId = fileId;
        this.formatterDispatch = formatterDispatch;
        this.handle = handle;
        this.listId = listId;
        this.jpfmContentListHandle = jpfmContentListHandle;
    }

    public final boolean isCompleted() {
        return completed.get();
    }

    public final FileId getFileId() {
        return FILEID_BUILDER.constructFileId(fileId);
    }

    public final long getListId() {
        return listId;
    }

    public final void fillWithContentListHandle(final ListEndImpl end){
        end.jpfmContentListHandle = this.jpfmContentListHandle;
    }

    public final void add8(final FileAttributesProvider file,final byte[]dos8letterName)throws IllegalArgumentException,IllegalStateException {
        throw new UnsupportedOperationException("The authors think that in the era of jdk7, supporting dos name shouldn\'t be essential. This might be supported if need arises.");
    }

    public final void add(final FileAttributesProvider file)throws IllegalArgumentException,IllegalStateException {
        if(completed.get()){
            throw new IllegalStateException("Complete method has already been called. This object is useless now.");
        }
        //checks
        if(file==null){
            //complete(JPfmError.FAILED, true);
            throw new IllegalArgumentException("Attempting to add null file to the list of directory"); 
        }
        if(file.getFileDescriptor()==null){
            //complete(JPfmError.FAILED, true);
            throw new IllegalArgumentException("Attempting to add a file with null fileDescriptor to the list of directory.\nFor file being added = "+file);
        }
        ////synchronized assuming that there can be more than one thread trying to fill this list
        synchronized(completed){
            NativeInterfaceMethods.addToList(handle,formatterDispatch, file, this.jpfmContentListHandle);
        }
    }

    @Override
    public final int hashCode() {
        return ((int)listId);
    }

    @Override
    public final boolean equals(final Object obj) {
        if(obj instanceof ListImpl){
            ListImpl toCompare = (ListImpl)obj;
            return(
                    toCompare.listId == this.listId //only checking this is sufficient but added extra junk
                    /*&&
                    toCompare.fileDescriptor.equals(this.fileDescriptor)
                    &&
                    toCompare.handle == toCompare.handle*/ // this can actually be different
            );
        }return false;
    }

    public final void complete(final JPfmError error,final DirectoryStream directoryStream)throws Exception{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }

        Iterator<FileAttributesProvider> it = directoryStream.iterator();
        FileAttributesProvider next =null ;
        while(it.hasNext()){
            try{
                next = it.next();
                if(next==null)throw new NullPointerException("Iterator of directory stream returned null, although iterator hasNext returned true.");
            }catch(Exception any){
                NativeInterfaceMethods.completeList(handle,formatterDispatch,JPfmError.CANCELLED.getErrorCode(),false);
                throw any;
            }NativeInterfaceMethods.addToList(handle, formatterDispatch, next, jpfmContentListHandle);
        }
        NativeInterfaceMethods.completeList(handle,formatterDispatch,error.getErrorCode(), true);
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    
    public final void complete(final JPfmError pfmError,final boolean noMore)throws IllegalStateException,IllegalArgumentException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeList(handle,formatterDispatch,pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode(), noMore);
    }
    

    public final void handleUnexpectedCompletion(final Exception exception){
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            this.complete(JPfmError.FAILED,true);//nomore set to true to prevent infinite tries,
                            //if the user really wants to try, he may just refresh the folder
        }
    }

    @Override
    public String toString() {
        return "List{"+ getFileId() + "}";
    }
}
