/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.FileId;
import jpfm.JPfmError;
import jpfm.operations.readwrite.Completer;

/**
 * <br/><br/>
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileDescriptor<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * The behavior of this function for folders is undefined.
 * Formatters are free to handle this in whatever way is convenient.<br/><br/>
 * The behavior of zero length writes is undefined.
 * Formatters are free to handle this in whatever way is convenient.
 * @see jpfm.JPfmFileSystem#write(jpfm.operations.WriteImpl)
 * @author Shashank Tulsyan
 */
public final class WriteImpl extends FileSystemOperationImpl implements Write {
//struct PfmMarshallerWriteOp
//{
//   virtual PFM_INT64   PFM_CCALL OpenId(void) = 0;
//   virtual PFM_UINT64  PFM_CCALL FileOffset(void) = 0;
//   virtual void*       PFM_CCALL Data(void) = 0;
//   virtual size_t      PFM_CCALL RequestedSize(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError,size_t actualSize) = 0;
//};

    private final long handle;
    private final long formatterDispatch;
    private final long fileId;
    private final ByteBuffer byteBuffer;
    private final long fileOffset;


    //private volatile boolean completed = false;//why? because other thWrites could have completed the job without other thWrite knowing
    private final AtomicBoolean completed = new AtomicBoolean(false);

    /*package private*/ WriteImpl(final long WriteOpHandle,final long formatterDispatch,final long fileId,final long fileOffset,final ByteBuffer byteBuffer) {
        this.fileId = fileId;
        this.formatterDispatch = formatterDispatch;
        this.byteBuffer = byteBuffer;
        this.fileOffset = fileOffset;
        this.handle = WriteOpHandle;
    }


    public final long getFileOffset() {
        return fileOffset;
    }

    public final ByteBuffer getByteBuffer() {
        return byteBuffer;
    }

    public final FileId getFileId() {
        return FILEID_BUILDER.constructFileId(fileId);
    }

    public final boolean isCompleted() {
        return completed.get();
    }



    public final void complete(final JPfmError error,final int actualSize)throws IllegalArgumentException,IllegalStateException{
        /*synchronized(fileDescriptor){
            if(completed){
                throw AlreadyCompleteException.createNew();
            }
        }*/
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }

        //check return value
        if(actualSize<byteBuffer.capacity()){
            if(actualSize<=0){
                if(error==JPfmError.SUCCESS){
                    NativeInterfaceMethods.completeWrite(handle, formatterDispatch, JPfmError.END_OF_DATA.getErrorCode(),0);
                    if(actualSize==0)
                        throw new IllegalArgumentException("Reason why actualSize was zero must be specified. Instead success was returned");
                }
                else{
                    NativeInterfaceMethods.completeWrite(handle, formatterDispatch, error==null?JPfmError.FAILED.getErrorCode():error.getErrorCode(),0);
                }
                if(actualSize<0)
                    throw new IllegalArgumentException("actualSize cannot be negative. \n For given actualSize value = "+actualSize);
                return;
            }
        }
        NativeInterfaceMethods.completeWrite(handle,formatterDispatch,error.getErrorCode(), actualSize);
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    
    public final void handleUnexpectedCompletion(final Exception exception){
        if(!this.completed.get())
            this.complete(JPfmError.FAILED,0);

    }

    @Override
    public String toString() {
        return "Write{"+ fileId + " offset="+ fileOffset + "}";
    }

    public void complete(JPfmError error, int actualwrite, Completer completer) throws IllegalArgumentException, IllegalStateException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
