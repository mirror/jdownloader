/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import jpfm.FileId;
import jpfm.JPfmError;
//import jpfm.JPfmBasicFileSystem;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 * ReadImpl is a wrapper class for atomic filesystem read requests
 * made by some application. It can represent both a pending
 * or a satisfied (completed) request.
 * An object of this class is said to be completed when {@link #complete(jpfm.JPfmError, int) }
 * or {@link #complete(jpfm.JPfmError, int, java.lang.Object) }
 * are invoked, with or without passing correct parameters.
 * Complete method can be invoked only once.
 * <br/><br/>
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileDescriptor<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * The behavior of this function for folders is undefined. Formatters are free to
 * handle this in whatever way is convenient.
 * <br/><br/>
 * ReadImpl does not implement java.nio.channels.CompletionHandler in order to make jpfm core
 * libraries independent of jdk7. In general jpfm.util.ReadCompletionHandler found in jpfm-fs.jar
 * can be used. In all other cases appropriate CompletionHandler have to constructed; for example, when
 * an atomic read request from filesystem has to satisfied using more than one source in NonBlocking
 * fashion.
 * @see jpfm.JPfmBasicFileSystem#read(jpfm.operations.ReadImpl)
 * @author Shashank Tulsyan
 */
public final class ReadImpl extends FileSystemOperationImpl implements Read {
//    struct PfmMarshallerReadOp
//    {
//       virtual PFM_INT64  PFM_CCALL OpenId(void) = 0;
//       virtual PFM_UINT64 PFM_CCALL FileOffset(void) = 0;
//       virtual void*      PFM_CCALL Data(void) = 0;
//       virtual size_t     PFM_CCALL RequestedSize(void) = 0;
//       virtual void PFM_CCALL Complete(int pfmError,size_t actualSize) = 0;
//    };

    /*package private*/ final long fileId;                  // 8
    /*package private*/ final ByteBuffer byteBuffer;        // 4 + 48 + size of buffer
    /*package private*/ final long fileOffset;              // 8
    /*package private*/ final long handle;                  // 8
    /*package private*/ final long formatterDispatch;       // 8

    //private final AtomicBoolean completed = new AtomicBoolean(false); // ]4+8+1[ = 16
    private final AtomicInteger completed = new AtomicInteger(JPfmError.INVALID_JPFM_ERROR_CODE);
    private Completer completer = null;   // 4t
    private int completionTime ; // 4
    //private final long creationTimeNanoSecond = System.nanoTime();
    //private long completionTimeNanoSecond;
    private ConcurrentLinkedQueue incompleteRequestsQueue = null;
    public static int numberOfReadInstancesInMemory = 0;
    //ReadImpl is pefectly packed
    //ReadImpl {MinimumFullSize=88 MaximumRawSize=64 Size without JVM round off=64}
    //ByteBuffer {MinimumFullSize=56 MaximumRawSize=48 Size without JVM round off=43}
    //minimum memory used when read object is created = 64 + 48 + 16 = 128bytes


    /*package private*/ ReadImpl(final long readOpHandle,final long formatterDispatch,final long fileId,final long fileOffset,final ByteBuffer byteBuffer) {
        this.fileId = fileId;
        this.byteBuffer = byteBuffer;
        this.fileOffset = fileOffset;
        this.handle = readOpHandle;
        this.formatterDispatch = formatterDispatch;
        //readOnlyFormatter = false;
        numberOfReadInstancesInMemory++;
    }

    //the formatterDispatch is different for legacy read only filesytem.
    //these cannot be mixed that is why we setInPartialMode them separately and have checks to ensure this
    /*package private*/ ReadImpl(final boolean readOnlyFormatter,final long readOpHandle,final long readOnlyFormatterDispatch,final long fileId,final long fileOffset,final ByteBuffer byteBuffer) {
        this.fileId = fileId;
        this.byteBuffer = byteBuffer;
        this.fileOffset = fileOffset;
        this.handle = readOpHandle;
        this.formatterDispatch = readOnlyFormatterDispatch;
        //this.readOnlyFormatter = readOnlyFormatter;
        numberOfReadInstancesInMemory++;
    }

    /**
     * Can be used to get the time when this request was made.
     * This time is actually slightly greater than the actual time
     * when the client application made the request, because 
     * this request travels through a few functions before
     * jpfm is aware of this.
     * JPfm does not attempt to predict the exact time of request creation.
     * @return the difference, measured in milliseconds, between
     *          the time when this request was made 
     *          and midnight, January 1, 1970 UTC.
     */

    public final long getFileOffset() {
        return fileOffset;
    }
    
    private void setIncompleteRequestsContainer(ConcurrentLinkedQueue clq){
        synchronized(this){
            if(incompleteRequestsQueue==null)incompleteRequestsQueue = clq;
            else throw new IllegalStateException("Pending Requests Queue already set to "+incompleteRequestsQueue);
        }
    }

    /**
     * The ByteBuffer in which the data being requested has to be filled.
     * ByteBuffer object obtained from here is not thread safe.
     * If the request is to satisfied from more than one sources, each source
     * should get it's own copy of ByteBuffer made by this ByteBuffer
     * by spliting, slicing or something similar.
     * @return The ByteBuffer in which the data being requested has to be filled.
     */
    public final ByteBuffer getByteBuffer() {
        return byteBuffer;
    }

    public final JPfmError getError(){
        if(!isCompleted())throw new IllegalStateException("not completed yet");
        return JPfmError.convertErrorCode(completed.get());
    }

    public final boolean isCompleted() {
        return completed.get()!=JPfmError.INVALID_JPFM_ERROR_CODE;
    }

    public boolean isFilledCompletely(){
        // requests pending
        // for a very long time will be automatically handled
        // by neembuu virtual filesystem
        return isCompleted();
    }

    public boolean isCompletedPartially(){
        // we do not need to check for this, since requests pending
        // for a very long time will be automatically handled
        // by neembuu virtual filesystem
        return isCompleted();

    }

    public final FileId getFileId() {
        return FileSystemOperationImpl.FILEID_BUILDER.constructFileId(fileId);
    }

    /**
     * @return the time when this request was completed
     * @throws IllegalStateException if not completed yet
     */
    public final long getCompletionTime() throws IllegalStateException {
        if(!isCompleted())throw new IllegalStateException("Not completed yet");
        return completionTime+getCreationTime();
    }

    /*public final long getTimeTakenToComplete(){
        return completionTimeNanoSecond-creationTimeNanoSecond;
    }*/


    /*public final void complete(final JPfmError error,final int actualRead){
        complete(error, actualRead, null);
    }*/

    /**
     * Invoked when the ByteBuffer has been filled with all that is available
     * and possible. If any
     * @param error Error type if any. Any value other than
     *  JPfmError.SUCCESS indicates a failure
     * @param actualRead The request size is the capacity of the ByteBuffer.
     * This value indicates how much data was read. This value is always
     * positive lesser than or equal to the capacity of ByteBuffer.
     * The region that has not been read, is later on filled with zero by PFM.
     * For knowing why this happen see
     * {@link ReadRequest#complete(JPfmError.FAILED, numberOfReadInstancesInMemory, completer) }
     * @param completer The Object that can be identified as the invoked of
     * the complete method
     * @throws IllegalArgumentException
     * @throws IllegalStateException If already completed
     * @see {@link ReadRequest#complete(JPfmError.FAILED, numberOfReadInstancesInMemory, completer) }
     */
    public final void complete(final JPfmError error,final int actualRead,Completer completer)throws IllegalArgumentException,IllegalStateException{
        //this.completionTimeNanoSecond = System.nanoTime();
        if(!completed.compareAndSet(/*expect*/JPfmError.INVALID_JPFM_ERROR_CODE,/*update*/ error.getErrorCode() )){
        //if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew(this.completer,completer);
        }
        completionTime = (int)(System.currentTimeMillis() - this.getCreationTime());
        //assuming that time taken to satisfy a request
        //will be less than
        //24 days, the difference is saved in an integer
        //check return value
        if(actualRead<0){
            if(error==JPfmError.SUCCESS){
                callCompleteMethod(JPfmError.END_OF_DATA, 0);
                //if(actualRead==0){
                    //throw new IllegalArgumentException
                    //System.out.println("Reason why actualRead was zero must be specified. Instead success was returned");
                //}//return
            }
            else{
                callCompleteMethod(error, 0);
            }
            if(actualRead==-1){
                //System.out.println("spotted a -1");
                throw new IllegalArgumentException("Actual read value was -1. Unlike java.io libraries, jpfm DOES NOT treat -1 as End of File. Pass JPfmError.END_OF_DATA");
            }
            if(actualRead<-1)
                throw new IllegalArgumentException("Actual read cannot be negative. \n For given actualread value = "+actualRead);
            return;
        }

        callCompleteMethod(error, actualRead);
        
        if(!incompleteRequestsQueue.remove(this)){
            StringBuilder sb = new StringBuilder();
            Iterator i = incompleteRequestsQueue.iterator();
            sb.append("Illegal implementation, pending requests not removed from ");
            sb.append("\n+++PendingRequests+++\n");
            while(i.hasNext()){
                sb.append("\n");
                sb.append(i.next().toString());
            }
            sb.append("\n---PendingRequests---\n");
            throw new RuntimeException(sb.toString());
        }incompleteRequestsQueue = null;// lets help in gc

        if(this.completer==null){
            if(completer==null){
                completer = new StateSavingCompleter(error);
            }
            this.completer = completer;
        }
        else {
            if(!this.completer.equals(completer)){
                if(completer instanceof UnexpectedCompletionHandler){
                    // ignore
                    return;
                }

                if(completer.getClass().getName().equals("jpfm.JPfmBasicFileSystem$ForceCompleter") ){
                    return; //ignore
                } else {
                    System.out.println("completer.getClass().getName()="+completer.getClass().getName());
                    System.out.println("completer.getClass()="+completer.getClass());
                }
                throw AlreadyCompleteException.createNewIllegalArgEx(this.completer, completer);
                //throw new IllegalArgumentException("The operation was completed successfully but completer passed was not the same as the one intialized. It is possible that more than one candidates are trying to complete this read operation.");
            }
        }
    }

    private final void callCompleteMethod(final JPfmError pfmError,final int actualRead){
        //System.out.println(error+" "+actualRead);
        //if(!readOnlyFormatter)
        // dangerous
        // passing formatter dispatch without checking
        // which type of formatter this is.
        // The fields are located at different places,
        // this will surely crash if formatterDispatch is used without checking
            NativeInterfaceMethods.completeRead(handle,formatterDispatch,pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode(), actualRead);

        //else NativeInterfaceMethods.completeReadRO(handle,formatterDispatch,pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode(), actualRead);
    }

    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
        complete(error,getByteBuffer().capacity(),null);
    }

    private static final class UnexpectedCompletionHandler implements Completer {
        //private static final UnexpectedCompletionHandler INSTANCE = new UnexpectedCompletionHandler();
        private final StackTraceElement[]stackTrace;
        public  UnexpectedCompletionHandler(){
            this.stackTrace = new Throwable().getStackTrace();
        }
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[]getStackTrace(){
            return stackTrace;
        }
    }

    public final void handleUnexpectedCompletion(final Exception exception){

        if(!isCompleted()){
            try{
                this.complete(JPfmError.FAILED,0,new UnexpectedCompletionHandler());
            }catch(AlreadyCompleteException ace){
                throw ace;
                //ignore ace
            }
            catch(Exception any){
                any.printStackTrace();
            }
        }
    }

    @Override
    public String toString() {
        return
                "Read{ creationTime = "+
                //java.text.DateFormat.getDateInstance().format(
                    //new java.util.Date(super.getCreationTime())
                    formatSystemTime(super.getCreationTime())
                //)
                + " offset = "+ fileOffset
                + " buffercapacity = "+byteBuffer.capacity()
                + " { FileId = "+fileId+" }"
                +(isCompleted()? " completionTime = "+formatSystemTime(getCompletionTime()) : " { not completed yet }")
                +" }";

        //
    }

    @SuppressWarnings(value="deprecation")
    public static final String formatSystemTime(final long time){
        final StringBuilder builder = new StringBuilder(13);
        final java.util.Date date = new java.util.Date(time);
        builder.append(date.getHours());
        builder.append(':');
        builder.append(date.getMinutes());
        builder.append(':');
        builder.append(date.getSeconds());
        builder.append('.');
        builder.append((time%1000));
        return builder.toString();
    }

    public final synchronized void setCompleter(final Completer completehandler) {
        if(isCompleted())throw AlreadyCompleteException.createNew(this.completer);
        if(this.completer!=null){
            throw new IllegalStateException("Already being handled by "+this.completer);
        }
        if(completehandler==null){
            throw new IllegalArgumentException("Setting handler to null is not allowed.");
        }
        this.completer = completehandler;
    }

    public final Completer getCompleter() {
        return completer;
    }

    public boolean canComplete(Completer completehandler) {
        if(this.completer==null)return true;
        return (this.completer==completehandler);
    }

    private static final class StateSavingCompleter implements Completer<ReadRequest>{
        private final JPfmError error;

        public StateSavingCompleter(JPfmError error) {
            this.error = error;
        }

        public JPfmError getError() {
            return error;
        }

        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[] getStackTrace() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }
    
    static  {
        jpfm.LeakSetPRSetter.setPendingReqSetter(IncompleteReqSetter.SINGLETON);
    }
    
    public static final class IncompleteReqSetter {
        private static final IncompleteReqSetter SINGLETON = new IncompleteReqSetter();
        private IncompleteReqSetter(){
            
        }
        public final void setIncompleteRequestContainer(ReadImpl read , ConcurrentLinkedQueue incompleteRequests){
            read.setIncompleteRequestsContainer(incompleteRequests);
        }
    }

    //public static int numberOfReadInstancesInMemory = 0;
    /*@Override
    protected void finalize() throws Throwable {
        numberOfReadInstancesInMemory--;
        //System.out.println("read finalized="+this);
        super.finalize();
    }*/

}
