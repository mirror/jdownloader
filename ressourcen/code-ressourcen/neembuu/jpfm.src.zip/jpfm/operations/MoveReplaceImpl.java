/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import java.util.Date;
import java.util.concurrent.atomic.AtomicBoolean;
import jpfm.FileId;
import jpfm.JPfmError;

/**
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileId<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * The marshaller calls this function when processing a move-replace
 * request from the driver. This request is made when a an opened
 * source file is being renamed to the same name as an opened target
 * file. The replaced target file name becomes deleted.<br/><br/>
 * Some processing for this function is similar to PfmFormatterOps::Replace,
 * except that the source file is guaranteed to exist since it is
 * already open.<br/><br/>
 * Some processing for this function is similar to PfmFormatterOps::Move,
 * specifically with handling of deleted source files and the deleteSource
 * parameter. <br/><br/>
 * @see jpfm.JPfmFileSystem#moveReplace(jpfm.operations.MoveReplaceImpl)
 * @author Shashank Tulsyan
 */
public final class MoveReplaceImpl extends FileSystemOperationImpl implements MoveReplace {
//struct PfmMarshallerMoveReplaceOp
//{
//   virtual PFM_INT64          PFM_CCALL SourceOpenId(void) = 0;
//   virtual PFM_INT64          PFM_CCALL SourceParentFileId(void) = 0;
//   virtual const PfmNamePart* PFM_CCALL SourceEndName(void) = 0;
//   virtual PFM_INT64          PFM_CCALL TargetOpenId(void) = 0;
//   virtual PFM_INT64          PFM_CCALL TargetParentFileId(void) = 0;
//   virtual const PfmNamePart* PFM_CCALL TargetEndName(void) = 0;
//   virtual bool               PFM_CCALL DeleteSource(void) = 0;
//   virtual PFM_INT64          PFM_CCALL WriteTime(void) = 0;
//   virtual void PFM_CCALL Complete(int pfmError) = 0;
//};

    private final long handle;
    private final long formatterDispatch;
    private final long sourceFileId;
    private final long sourceParentFileId;
    private final String sourceEndName;
    private final long targetFileId;
    private final long targetParentFileId;
    private final String targetEndName;
    private final boolean deleteSource;
    private final long writeTime;
    //private final FileId newExistingFileId;

    private final AtomicBoolean completed = new AtomicBoolean(false);

    /*package private*/ MoveReplaceImpl(
            final long handle,
            final long formatterDispatch,
            final long sourceFileId,
            final long sourceParentFileId,
            final String sourceEndName,
            final long targetFileId,
            final long targetParentFileId,
            final String targetEndName,
            final boolean deleteSource,
            final long writeTime
            /*final FileId newExistingFileId*/) {
        this.handle = handle;
        this.formatterDispatch = formatterDispatch;
        this.sourceFileId = sourceFileId;
        this.sourceParentFileId = sourceParentFileId;
        this.sourceEndName = sourceEndName;
        this.targetFileId = targetFileId;
        this.targetParentFileId = targetParentFileId;
        this.targetEndName = targetEndName;
        this.deleteSource = deleteSource;
        this.writeTime = writeTime;
        //this.newExistingFileId = newExistingFileId;
    }

    public final boolean isDeleteSource() {
        return deleteSource;
    }

    /*public final FileId getNewExistingFileId() {
        return newExistingFileId;
    }*/

    public final boolean isCompleted() {
        return completed.get();
    }

    
    public final String getSourceEndName() {
        return sourceEndName;
    }

    public final FileId getSourceFileId() {
        return FILEID_BUILDER.constructFileId(sourceFileId);
    }

    public final FileId getSourceParentFileId() {
        return FILEID_BUILDER.constructFileId(sourceParentFileId);
    }

    public final String getTargetEndName() {
        return targetEndName;
    }

    public final FileId getTargetFileId() {
        return FILEID_BUILDER.constructFileId(targetFileId);
    }

    public final FileId getTargetParentFileId() {
        return FILEID_BUILDER.constructFileId(targetParentFileId);
    }

    public final long getWriteTime() {
        return writeTime;
    }

    public final Date getWriteTimeAsDate() {
        return new Date( writeTime );
    }

    public final void complete(final JPfmError pfmError)throws IllegalStateException{
        if(!completed.compareAndSet(/*expect*/false,/*update*/ true)){
            //we were expecting false, but it is true. implying it is already complete, throw an exception
            throw AlreadyCompleteException.createNew();
        }
        NativeInterfaceMethods.completeMoveReplace(handle, formatterDispatch, pfmError==null?JPfmError.FAILED.getErrorCode():pfmError.getErrorCode());
    }


    @Override
    protected final long getFormatterDispatchHandle() {
        return formatterDispatch;
    }

    
    
    public final void handleUnexpectedCompletion(final Exception exception){
        if(!this.completed.get()){
            this.complete(JPfmError.FAILED);
        }
    }

    @Override
    public String toString() {
        return "MoveReplace{"+ sourceFileId + "}";
    }
}
