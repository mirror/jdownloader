/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations.readwrite;

import java.nio.ByteBuffer;
import jpfm.JPfmError;

/**
 *
 * @author Shashank Tulsyan
 */
public interface WriteRequest {
    /**
     * The ByteBuffer in which the data being requested has to be filled.
     * ByteBuffer object obtained from here is not thwrite safe.
     * If the request is to satisfied from more than one sources, each source
     * should get it's own copy of ByteBuffer made by this ByteBuffer
     * by spliting, slicing or something similar.
     * <br/>
     * <br/>
     * When completing a write request passing most JPfmError will cause
     * the client application to give up. See {@link JPfmError } for what
     * messages are received. {@link JPfmError#END_OF_DATA } does not show
     * up as an error, but will also result in client application giving up.
     * {@link JPfmError#SUCCESS } should be returned for all cases.
     * Appropriate JPfmErrors should be used, most of which will never be used
     * as they are meaningless for a virtual file system.
      * @return The ByteBuffer in which the data being requested has to be filled.
     */
    public ByteBuffer getByteBuffer();
    /**
     * @return The data offset from which the abstract file or JPfmwriteable is to be write.
     */
    public long getFileOffset();

    /**
     * @see {@link writeRequest#complete(jpfm.JPfmError, int, jpfm.operations.writewrite.Completer) }
     * @param error
     * @param actualwrite
     */
    //public void complete(final JPfmError error,final int actualwrite);
    /**
     * complete function cannot be invoked more than once on any filesystem request.
     * This is to be done when the bytebuffer has been filled with the requested data
     * either fully or partially.
     * @param error Error if any, otherwise {@link JPfmError#SUCCESS }
     * @param actualwrite the number of bytes that were actually write and filled in the buffer. This should be
     * less than or equal to the ByteBuffer's capacity and greater than zero.
     * -1 is usually passed by java nio api to indicate end of file.
     * Implementors should check this and convert it into 0 and pass {@link JPfmError#END_OF_DATA } instead.
     * Negative values indicate failure but appropriate reason might not be reported to the
     * requesting applicaiton. Therefore it is advised not to pass negative values.
     * @param completer The object which is managing this write request and invoked this complete function.
     * If the completer passed here does not match the completer (optinally) registered
     * (more than one completer might be registered but that would make things complex, the implementors
     * are free do design in whichever way they prefer), an exception is thrown and the request is NOT completed.
     * This mechanism allows writing such code in which only entrusted completer can complete the request.
     * Exceptions to this are JPfmFileSystem and JPfmwriteOnlyFileSystem, which can forcefully complete any request.
     * {@link writeRequest#complete(jpfm.JPfmError, int) } may be also be used in which case checking is not possible.
     * @see Completer
     * @throws IllegalArgumentException
     * @throws IllegalStateException If alwritey completed
     */
    public void complete(final JPfmError error,final int actualwrite,final Completer completer)throws IllegalArgumentException,IllegalStateException;
    /**
     * complete function cannot be invoked more than once on any filesystem request.
     * @return false if complete method cannot be invoked anymore since it has been
     * alwritey invoked, true otherwise
     */
    public boolean isCompleted();
    /**
     * The filesystem browser might be waiting for a write request to be satisfied.
     * If the request was not completed due to a exception, this function is invoked
     * to free all resources and free this write request.
     * In case of {@link jpfm.operations.write } this function is handled by
     * calling complete with {@link JPfmError#FAILED }. Implementors can do the same
     * but it would be better if they analyze the exception and convert it into an appropriate JPfmError.
     * @param exception
     */
    public void handleUnexpectedCompletion(final Exception exception);
    /**
     * creation time is slightly greater than the exact instance when this request
     * was made by the application because the request travels through different kernel layers,
     * pismo file mount filesystem driver and then reaches JPfm.
     * @return the time when this request was reported to JPfm by the kernel driver
     */public long getCreationTime();
}
