/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations.readwrite;

import java.nio.ByteBuffer;
import jpfm.JPfmError;

/**
 *
 * @author Shashank Tulsyan
 */
public abstract class AbstractRequestWrapper implements ReadRequest{

    private final ReadRequest readRequest;


    public AbstractRequestWrapper(ReadRequest readRequest) {
        this.readRequest = readRequest;
    }

    public final ReadRequest getOriginalReadRequest() {
        return readRequest;
    }

    @Override
    public final ByteBuffer getByteBuffer() {
        return readRequest.getByteBuffer();
    }

    @Override
    public final long getFileOffset() {
        return readRequest.getFileOffset();
    }

    @Override
    public final void complete(JPfmError error, int actualRead, Completer completer) throws IllegalArgumentException, IllegalStateException {
        readRequest.complete(error, actualRead, completer);
    }

    @Override
    public final void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
        readRequest.complete(error);
    }

    @Override
    public final boolean isCompleted() {
        return readRequest.isCompleted();
    }

    @Override
    public final void handleUnexpectedCompletion(Exception exception) {
        readRequest.handleUnexpectedCompletion(exception);
    }

    @Override
    public final long getCreationTime() {
        return readRequest.getCreationTime();
    }

    @Override
    public final long getCompletionTime() {
        return readRequest.getCompletionTime();
    }

    @Override
    public final JPfmError getError() throws IllegalStateException {
        return readRequest.getError();
    }

    @Override
    public final void setCompleter(Completer completehandler) {
        readRequest.setCompleter(completehandler);
    }

    @Override
    public final boolean canComplete(Completer completehandler) {
        return readRequest.canComplete(completehandler);
    }



}
