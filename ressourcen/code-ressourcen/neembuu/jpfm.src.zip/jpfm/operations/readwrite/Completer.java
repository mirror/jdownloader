/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations.readwrite;


/**
 * The job of a Completer is to call complete function on a pending read request.
 * The completer can optionally register with a {@link jpfm.operations.Read }.
 * Registering will not prevent other Completers from calling complete function.
 * If the {@link jpfm.operations.Read#complete(jpfm.JPfmError, int, jpfm.operations.readwrite.Completer)  }
 * function is used, where the calling completer passes and object of itself,
 * an exception will be thrown. Therefore it is a good practice to use {@link jpfm.operations.Read#complete(jpfm.JPfmError, int, jpfm.operations.readwrite.Completer)  }
 * as it helps in finding out if completers other than the registered one are trying to complete
 * the request. For most simple cases use of completer to check wouldn't be required, also the 
 * use of the {@link #getStackTrace() } must be avoided as getting the stacktrace is slow operation.
 * Completers can be used when {@link jpfm.operations.AlreadyCompleteException } is being observed
 * too often. In such cases, it is very likely that the read request is being completed at two or more 
 * different parts of the program, without proper synchronization giving rise to a kind of race condition.
 * A completer with stacktrace information could be used to detect such bugs.<br/>
 * Completer interface and associate functions
 * have been provided as utility for the implementors, it is on the implementor to decide what he
 * would like to use.
 * @author Shashank Tulsyan
 */
public interface Completer<R extends ReadRequest> {
    /**
     * @return number of bytes already filled in the bytebuffer correctly.
     * The <code>position()</code> function of bytebuffer is not a safe way to check this,
     * as bytebuffer is often split and filled as an array from different
     * offsets rather than linearly. Linearly is a common situation, but there
     * are exceptions as already explained. Typical example in <code>jpfm.fs.SplitFS</code>
     */
    public int getBytesFilledTillNow(R pendingRequest);

    /**
     * If a request is taking very long to complete, the filesystem
     * might decide to simply supply whatever is available till now
     * even if the buffer has not been completely filled.
     * Any filesystem which worries about application being casted into
     * <b>Not responding</b> state will do this.
     */
    public void completeNow(R pendingRequest);

    /**
     * This is for strict debugging purposes.
     * @return the program path followed that resulted in finally completing the
     * pending request.
     */
    public StackTraceElement[]getStackTrace();
}
