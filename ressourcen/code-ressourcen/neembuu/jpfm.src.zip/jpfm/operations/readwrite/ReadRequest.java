/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations.readwrite;

import java.nio.ByteBuffer;
import jpfm.JPfmError;

/**
 * Represents a small read requests, it is the
 * fundamental representation of atomic filesystem read requests
 * made by some application. It can represent both a pending
 * or a satisfied (completed) request.
 * An object of this is said to be completed when one of {@link #complete(jpfm.JPfmError, int) }
 * or {@link #complete(jpfm.JPfmError, int, java.lang.Object) }
 * is invoked, with or without passing correct parameters.
 * <b>Complete method can be invoked only once.</b></br>
 * <u>Implementor's note </u><br/>
 * Implementation to this must always be concurrent in nature.
 * {@link java.util.concurrent.atomic.AtomicBoolean} should be used
 * to store completion status.<br/>
 * ReadRequest are requests made by client application.
 * @author Shashank Tulsyan
 * @see SimpleReadRequest
 */
public interface ReadRequest {
    /**
     * The ByteBuffer in which the data being requested has to be filled.
     * ByteBuffer object obtained from here is not thread safe.
     * If the request is to satisfied from more than one sources, each source
     * should get it's own copy of ByteBuffer made by this ByteBuffer
     * by spliting, slicing or something similar.
     * <br/>
     * <br/>
     * When completing a read request passing most JPfmError will cause
     * the client application to give up. See {@link JPfmError } for what
     * messages are received. {@link JPfmError#END_OF_DATA } does not show
     * up as an error, but will also result in client application giving up.
     * {@link JPfmError#SUCCESS } should be returned for all cases.
     * Appropriate JPfmErrors should be used, most of which will never be used
     * as they are meaningless for a virtual file system.
      * @return The ByteBuffer in which the data being requested has to be filled.
     */
    public ByteBuffer getByteBuffer();
    /**
     * @return The data offset from which the abstract file or JPfmReadable is to be read.
     */
    public long getFileOffset();

    /**
     * @see {@link ReadRequest#complete(jpfm.JPfmError, int, jpfm.operations.readwrite.Completer) }
     * @param error
     * @param actualRead
     */
    //public void complete(final JPfmError error,final int actualRead);
    /**
     * complete function cannot be invoked more than once on any filesystem request.
     * This is to be done when the bytebuffer has been filled with the requested data
     * either fully or partially.
     * Filling partially has a special meaning in PFM. In PFM, if buffer is
     * filled partially, the rest of the region is filled with zero,
     * and the client applicaiton receives actualRead value which is
     * equal to buffer capacity.
     * <br/>
     * <br/>
     * <br/>
     * Implementors should check this and convert actualRead values into 0 and pass {@link JPfmError#END_OF_DATA } instead.
     * Negative values indicate failure but appropriate reason might not be reported to the
     * requesting applicaiton. Therefore it is advised not to pass negative values.     *
     * <br/><br/>
     * PFM has a special way of treating satisfied read requests that return
     * value of actualRead less than Buffer's capacity, (such cases are called short read).
     * PFM treats short reads by filling the region not read, with zero
     * and tells the client application that the read successfull entirely.
     * That is to say, the actual value of <pre>actualRead</pre> never reaches
     * the client.<br/>
     * In Linux like operating systems,it is acceptable to have short reads that occur
     * in middle of file.
     * <br/>
     * <br/>
     * From http://www.opengroup.org/onlinepubs/9699919799/functions/read.html
     * <br/><br/>
     * "The <b>value returned may be less than</b> nbyte if the number of bytes left
     * in the file is less than nbyte, if the read() request was interrupted
     * by a signal, or if the file is a pipe or FIFO or
     * <b>special file and has fewer than nbyte bytes immediately available for reading</b>. "
     * <br/><br/>
     * But on windows, a short read that occurs not in the middle of file has been
     * specified in the MSDN docs as an error.<br/><br/>
     * "fread returns the number of full items actually read,
     * which may be less than count if an <b>error</b> occurs or
     * if the end of the file is encountered before reaching count."
     * <br/><br/>
     * Applications might retry, or they might give up, if short read occurs
     * in middle of file. The current PFM design, assumes that majority
     * windows applications do not handle short read in linux style.
     * Linux style support for short read in pismo will not happen in near future.
     * @param error Error if any, otherwise {@link JPfmError#SUCCESS }
     * @param actualRead the number of bytes that were actually read and filled in the buffer. This should be
     * less than or equal to the ByteBuffer's capacity and greater than zero.
     * -1 is usually passed by java nio api to indicate end of file.
     * @param completer The object which is managing this read request and invoked this complete function.
     * If the completer passed here does not match the completer (optinally) registered
     * (more than one completer might be registered but that would make things complex, the implementors
     * are free do design in whichever way they prefer), an exception is thrown and the request is NOT completed.
     * This mechanism allows writing such code in which only entrusted completer can complete the request.
     * Exceptions to this are JPfmFileSystem and JPfmBasicFileSystem, which can forcefully complete any request.
     * {@link ReadRequest#complete(jpfm.JPfmError, int) } may be also be used in which case checking is not possible.
     * @see Completer
     * @throws IllegalArgumentException
     * @throws IllegalStateException If already completed
     */
    public void complete(final JPfmError error,final int actualRead,final Completer completer)throws IllegalArgumentException,IllegalStateException;
    public void complete(final JPfmError error)throws IllegalArgumentException,IllegalStateException;
    /**
     * complete function cannot be invoked more than once on any filesystem request.
     * @return false if complete method cannot be invoked anymore since it has been
     * already invoked, true otherwise
     */
    public boolean isCompleted();
    /**
     * The filesystem browser might be waiting for a read request to be satisfied.
     * If the request was not completed due to a exception, this function is invoked
     * to free all resources and free this read request.
     * In case of {@link jpfm.operations.Read } this function is handled by
     * calling complete with {@link JPfmError#FAILED }. Implementors can do the same
     * but it would be better if they analyze the exception and convert it into an appropriate JPfmError.
     * @param exception
     */
    public void handleUnexpectedCompletion(final Exception exception);
    /**
     * creation time is slightly greater than the exact instance when this request
     * was made by the application because the request travels through different kernel layers,
     * pismo file mount filesystem driver and then reaches JPfm.
     * @return the time when this request was reported to JPfm by the kernel driver
     */
    public long getCreationTime();
    /**
     * The time when complete method was invoked.
     * This is slightly before the time when the application actually
     * received the read data.
     * @return the time when this request was reported to JPfm by the kernel driver
     */
    public long getCompletionTime();
    /**
     * @return  The error that occurred while handling this request.
     * {@link JPfmError#SUCCESS } if no error occurred
     * @throws IllegalStateException If the request is not completer
     * yet
     * @see {@link #isCompleted() }
     */
    public JPfmError getError() throws IllegalStateException;

    public void setCompleter(Completer completehandler);

    public boolean canComplete(Completer completehandler);

}