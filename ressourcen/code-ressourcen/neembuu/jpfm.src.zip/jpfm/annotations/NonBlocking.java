/*
 *  Copyright 2010 Shashank Tulsyan.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Indicates that the annotated method or class does not block
 * execution waiting for an filesystem operation to occur.
 * Like {@link java.io.RandomAccessFile#read() } is blocking in nature
 * while {@link java.nio.channels.AsynchronousFileChannel#read(java.nio.ByteBuffer, long) } is not.
 * So all RandomAccessFile method using api such as AsynchronousFileChannel 
 * would have a @NonBlocking annotation to indicate this.
 * NonBlocking is used only when we are sure each and every function
 * is non-blocking in nature in every case, otherwise it is better to mark it
 * as {@link MightBeBlocking}.
 * <br/><br/>
 * Unlike {@link PartiallyCompleting } a read function that is annotated
 * NonBloking is called only once for a given request. That request is cached
 * by the implementation and is completed asynchronously by calling
 * {@link jpfm.operations.Read#complete(jpfm.JPfmError, int, jpfm.operations.readwrite.Completer)}
 * whenever finished. <br/>
 * These annotations are visible during runtime.<br/>
 * ReadQueueManager implementations might refer to these values
 * and report error if a mismatch is found between the annotation
 * and expected {@link jpfm.operations.RequestHandlingApproach}
 * <br/><br/>
 * If an abstract method is annotated as NonBlocking it means that
 * it would be assumed (for performance or other reasons) at by many critical sections
 * that the implementation to that method will be NonBlocking.
 * So implementors are expected to make their best effort in such cases to make the
 * function NonBlocking.
 * @author Shashank Tulsyan
 */
@Documented
@Retention(value=RetentionPolicy.RUNTIME) //to easily allow checking and thus prevention of loading of jdk7 dependant classes
@Target(value={ElementType.METHOD,ElementType.TYPE})
public @interface NonBlocking {
    /**
     * For implementing true NonBlocking filesystem functionality
     * the programmer might be using jdk7 api classes such as
     * java.nio.channels.AsynchronousFileChannel
     * java.nio.channels.AsynchronousByteChannel .
     * This puts an extra requirement on the project (to have jdk7 that is).
     * Use this field if you need to be conscious of what parts of your
     * project prevent it from working on lower JDKs.
     * @return
     */
    public boolean usesJava1_7NIOClasses() default false;

    public boolean usesOneThreadPerRequest() default false;
    public boolean usesOneThreadPerContinuousChannel() default false;
}
