/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

import java.io.PrintStream;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.WeakHashMap;
import jpfm.JPfm.Manager;
import jpfm.mount.MountFlags;
import jpfm.fs.AsynchronousFileSystem;
import jpfm.fs.BasicFileSystem;
import jpfm.fs.UtilityServiceProvider;
import jpfm.mount.Mount;
import jpfm.mount.MountId;
import jpfm.mount.MountLocation;
import jpfm.mount.MountParams;
import jpfm.mount.MountProvider;
import jpfm.operations.CapacityImpl;
import jpfm.operations.CloseImpl;
import jpfm.operations.ControlImpl;
import jpfm.operations.DeleteImpl;
import jpfm.operations.FlushFileImpl;
import jpfm.operations.FlushMediaImpl;
import jpfm.operations.ListImpl;
import jpfm.operations.MediaInfoImpl;
import jpfm.operations.MoveImpl;
import jpfm.operations.MoveReplaceImpl;
import jpfm.operations.OpenImpl;
import jpfm.operations.ReadImpl;
import jpfm.operations.ReplaceImpl;
import jpfm.operations.SetSizeImpl;
import jpfm.operations.WriteImpl;

/**
 *
 * @author Shashank Tulsyan
 */
final class Impl {

    final static class MountImpl implements Mount {
        private final JPfmMount jPfmMountToWrap;

        public MountImpl(JPfmMount jPfmMountToWrap) {
            this.jPfmMountToWrap = jPfmMountToWrap;
        }


        public MountId getMountId() {
            return new MountId(jPfmMountToWrap.getMountId());
        }

        public MountLocation getMountLocation() {
            return new MountLocation(jPfmMountToWrap.getMountLocation());
        }

        public VolumeVisibility getVolumeVisibility() {
            return jPfmMountToWrap.getVolumeVisibility();
        }

        public boolean isMounted() {
            return jPfmMountToWrap.isMounted();
        }

        public void unMount() throws UnmountException {
            jPfmMountToWrap.unMount();
        }

        public ThreadGroup getThreadGroup(Manager manager) {
            if(JPfm.isManagerValid(manager) )
                return jPfmMountToWrap.getThreadGroup();
            else{
                if(manager==null){
                    throw new IllegalArgumentException("Manager must be the manager currently in use. The parameter passed was null");
                }
                throw new IllegalArgumentException("Manager must be the manager currently in use.");
            }
        }

    }

    final static class DefaultMountProvider implements MountProvider{
        static final MountProvider INSTANCE = new DefaultMountProvider();

        private DefaultMountProvider() {
        }


        public Mount mount(MountParams mountParams) throws jpfm.MountException {
            Object fileSystem = mountParams.getParamValue(MountParams.ParamType.FILE_SYSTEM);
            String mountLocation = (String)mountParams.getParamValue(MountParams.ParamType.MOUNT_LOCATION).toString();
            MountFlags mountFlags = (MountFlags)mountParams.getParamValue(MountParams.ParamType.MOUNT_FLAGS);
            MountListener ufl = (MountListener)mountParams.getParamValue(MountParams.ParamType.LISTENER);
            boolean exitOnUnmount = (Boolean)mountParams.getParamValue(MountParams.ParamType.EXIT_ON_UNMOUNT);
            VolumeVisibility volumeVisibility = (VolumeVisibility)mountParams.getParamValue(MountParams.ParamType.VOLUME_VISIBILITY);
            VolumeFlags volumeFlags = (VolumeFlags)mountParams.getParamValue(MountParams.ParamType.VOLUME_FLAGS);
            boolean asycn = fileSystem instanceof AsynchronousFileSystem;
            
            JPfmMount mount = null;
            if(!asycn){

                JPfmBasicFileSystem basicFileSystem
                        = new BasicFSImpl((BasicFileSystem)fileSystem);

                 mount
                        = JPfmMount.mount(
                            basicFileSystem,
                            mountLocation,
                            mountFlags,
                            ufl,
                            exitOnUnmount,
                            volumeVisibility);
            } else {

                char driveLetter = '\0' ;
                if(
                        mountParams.getParamValue(MountParams.ParamType.MOUNT_LOCATION)
                            instanceof MountLocation
                        )
                    driveLetter =
                            ((MountLocation)mountParams.getParamValue(MountParams.ParamType.MOUNT_LOCATION))
                            .getDriveLetter();

                JPfmFileSystem fileSystem1 = new
                        Impl.AysncFSImpl(volumeFlags, (AsynchronousFileSystem)fileSystem);

                mount
                        = JPfmMount.mount(
                            (JPfmFileSystem)fileSystem1,
                            mountLocation,
                            driveLetter,
                            mountFlags,
                            ufl,
                            exitOnUnmount,
                            volumeVisibility);
            }
            return new MountImpl(mount);
        }

    }

    final static class DefaultSP implements UtilityServiceProvider {
        final static DefaultSP INSTANCE  = new DefaultSP();

        private final LinkedList<WeakReference<AysncFSImpl>>
                asynchFSs = new LinkedList<WeakReference<AysncFSImpl>>();
        private final LinkedList<WeakReference<BasicFSImpl>>
                basicFSs = new LinkedList<WeakReference<BasicFSImpl>>();

        private AysncFSImpl findAsycn(AsynchronousFileSystem afsToCheck){
            synchronized(asynchFSs){
                for(WeakReference<AysncFSImpl> afs : asynchFSs ){
                    AysncFSImpl afsi = afs.get();
                    if(afsi != null)
                        if(afsi.afs == afsToCheck)
                            return afsi;
                }
            }return null;
        }

        private BasicFSImpl findBasic(BasicFileSystem basicToCheck){
            synchronized(basicFSs){
                for(WeakReference<BasicFSImpl> wrbasic : basicFSs ){
                    BasicFSImpl basicfsi = wrbasic.get();
                    if(basicfsi != null)
                        if(basicfsi.basicFileSystem == basicToCheck)
                            return basicfsi;
                }
            }return null;
        }

        public void forceCompleteAsynchronous(AsynchronousFileSystem fileSystem) throws Exception {
            AysncFSImpl afsi = findAsycn(fileSystem);
            if(afsi!=null)
                afsi.forceComplete();
            else
                throw new NullPointerException("This filesystem might have been unmounted");
        }

        public void forceCompleteBasic(BasicFileSystem fileSystem) throws Exception{
            BasicFSImpl baisc = findBasic(fileSystem);
            if(baisc!=null)
                baisc.forceComplete();
            else
                throw new NullPointerException("This filesystem might have been unmounted");
        }

        @SuppressWarnings(value="unchecked")
        public java.util.List getFileSystems(Manager manager) {
            if(JPfm.isManagerValid(manager)){
                throw new IllegalArgumentException("Invalid manager instance passed");
            }
            LinkedList list = new LinkedList();
            synchronized(asynchFSs){
                list.addAll(asynchFSs);
            }
            synchronized(basicFSs){
                list.addAll(asynchFSs);
            }
            return list;
        }

        public int getMountCount() {
            int ret = 0;
            synchronized(asynchFSs){
                Iterator<WeakReference<AysncFSImpl>> it
                        = asynchFSs.iterator();
                while(it.hasNext()){
                    WeakReference<AysncFSImpl> next = it.next();
                    if(next.get() == null){
                        it.remove();
                        continue;
                    }
                    ret++;
                }
            }
            synchronized(basicFSs){
                Iterator<WeakReference<BasicFSImpl>> it
                        = basicFSs.iterator();
                while(it.hasNext()){
                    WeakReference<BasicFSImpl> next = it.next();
                    if(next.get() == null){
                        it.remove();
                        continue;
                    }
                    ret++;
                }
            }
            return ret;
        }

        public void printIncompleteOperationsAsynchronous(AsynchronousFileSystem fileSystem, PrintStream printStream) {
            AysncFSImpl afsi = findAsycn(fileSystem);
            if(afsi!=null)
                afsi.printIncompleteOperations(printStream);
            else
                throw new NullPointerException("This filesystem might have been unmounted");
        }

        public void printIncompleteOperationsBasic(BasicFileSystem fileSystem, PrintStream printStream) {
            BasicFSImpl afsi = findBasic(fileSystem);
            if(afsi!=null)
                afsi.printIncompleteOperations(printStream);
            else
                throw new NullPointerException("This filesystem might have been unmounted");
        }


    }

    final static class AysncFSImpl extends  JPfmFileSystem {
        private final AsynchronousFileSystem afs;

        public AysncFSImpl(VolumeFlags volumeFlags, AsynchronousFileSystem afs) {
            super(volumeFlags);
            synchronized(DefaultSP.INSTANCE.asynchFSs){
                //weak ref so no problem in leaking this in constructor
                DefaultSP.INSTANCE.asynchFSs.add(new WeakReference<AysncFSImpl>(this));
            }
            this.afs = afs;
        }

        protected final String getFileSystemName() {
            return afs.getClass().getSimpleName();
        }


        @Override
        protected final void capacity(CapacityImpl capacity) throws Exception {
            afs.capacity(capacity);
        }

        @Override
        protected final void close(CloseImpl close) throws Exception {
            afs.close(close);
        }

        @Override
        protected final void control(ControlImpl control) throws Exception {
            afs.control(control);
        }

        @Override
        protected final void delete(DeleteImpl delete) throws Exception {
            afs.delete(delete);
        }

        @Override
        protected final void flushFile(FlushFileImpl flushFile) throws Exception {
            afs.flushFile(flushFile);
        }

        @Override
        protected final void flushMedia(FlushMediaImpl flushMedia) throws Exception {
            afs.flushMedia(flushMedia);
        }

        @Override
        protected final void list(ListImpl list) throws Exception {
            afs.list(list);
        }

        @Override
        protected final void mediaInfo(MediaInfoImpl mediaInfo) throws Exception {
            afs.mediaInfo(mediaInfo);
        }

        @Override
        protected final void move(MoveImpl move) throws Exception {
            afs.move(move);
        }

        @Override
        protected final void moveReplace(MoveReplaceImpl moveReplace) throws Exception {
            afs.moveReplace(moveReplace);
        }

        @Override
        protected final void open(OpenImpl open) throws Exception {
            afs.open(open);
        }

        @Override
        protected final void read(ReadImpl read) throws Exception {
            afs.read(read);
        }

        @Override
        protected final void replace(ReplaceImpl replace) throws Exception {
            afs.replace(replace);
        }

        @Override
        protected final void setSize(SetSizeImpl setSize) throws Exception {
            afs.setSize(setSize);
        }

        @Override
        protected final void write(WriteImpl write) throws Exception {
            afs.write(write);
        }

        @Override
        protected final FileAttributesProvider getFileAttributes(FileId fileDescriptor) {
            return afs.getFileAttributes(fileDescriptor);
        }

        /*@Override
        protected final <FS extends JPfmBasicFileSystem> void cascadeMount(String[] mountLocation, FileSystemInstanceProvider<FS> fsProvider) {
            throw new UnsupportedOperationException("Not supported yet.");
        }*/

        @Override
        public final boolean equals(Object obj) {
            if(obj instanceof AysncFSImpl)
                return ((AysncFSImpl)obj).afs == afs;
            return false;
        }

        @Override
        public final int hashCode() {
            return afs.hashCode();
        }


    }

    static final class BasicFSImpl extends  JPfmBasicFileSystem {
        private final BasicFileSystem basicFileSystem;

        public BasicFSImpl(BasicFileSystem basicFileSystem) {
            super();
            synchronized(DefaultSP.INSTANCE.basicFSs){
                //weak ref so no problem in leaking this in constructor
                DefaultSP.INSTANCE.basicFSs.add(new WeakReference<BasicFSImpl>(this));
            }
            this.basicFileSystem = basicFileSystem;
        }

        @Override
        protected final void read(ReadImpl read) throws Exception {
            basicFileSystem.read(read);
        }

        @Override
        protected final FileAttributesProvider getRootAttributes() {
            return basicFileSystem.getRootAttributes();
        }

        @Override
        protected final FileAttributesProvider open(String[] filePath) {
            return basicFileSystem.open(filePath);
        }

        @Override
        protected final void open(FileAttributesProvider fap) {
            basicFileSystem.open(fap);
        }

        @Override
        protected final FileAttributesProvider getFileAttributes(FileId fileDescriptor) {
            return basicFileSystem.getFileAttributes(fileDescriptor);
        }

        @Override
        protected final jpfm.DirectoryStream list(FileId folderToList) {
            return basicFileSystem.list(folderToList);
        }

        @Override
        protected final void close(FileId file) {
            basicFileSystem.close(file);
        }

        @Override
        protected final void delete(FileId fileToDelete) {
            basicFileSystem.delete(fileToDelete);
        }

        @Override
        protected final long capacity() {
            return basicFileSystem.capacity();
        }

        protected final String getFileSystemName(){
            return basicFileSystem.getClass().getSimpleName();
        }


        @Override
        public final boolean equals(Object obj) {
            if(obj instanceof BasicFSImpl)
                return ((BasicFSImpl)obj).basicFileSystem == basicFileSystem;
            return false;
        }

        @Override
        public final int hashCode() {
            return basicFileSystem.hashCode();
        }

        /*@Override
        protected final <FS extends JPfmBasicFileSystem> void cascadeMount(String[] mountLocation, FileSystemInstanceProvider<FS> fsProvider) {
            throw new UnsupportedOperationException("Not supported yet.");
        }*/
    }
}
