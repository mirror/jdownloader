/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   BasicAbstractFile.java
 * Author: Shashank Tulsyan
 */
package jpfm.volume;

import jpfm.DirectoryStream;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileType;
import jpfm.volume.utils.StringMaker;

/**
 * One important fact about BasicAbstractFile is that it cannot
 * be resized internally.
 * <u>Important </u> : <br/>
 * If the size of your files can change after the file is already open
 * for reading, the size change will not be observed by PFM or applications
 * being served. If this is your case then use {@link FileDescriptor#setInvalid() } function.
 * Otherwise, the size change, will be observed only if it occured
 * due to call of {@link jpfm.operations.SetSize} filesystem
 * operation call <br/>
 * For more you should also read javadoc of {@link FileAttributesProvider#getFileSize() }
 * @author Shashank Tulsyan
 */
public abstract class BasicAbstractFile
        extends
            FileDescriptor
        implements
            AbstractFile {

    protected long fileSize;
    protected String name;
    protected DirectoryStream parent;
    protected long createTime = 0;
    protected long accessTime = 0;
    protected long writeTime = 0;
    protected long changeTime = 0;

    protected BasicAbstractFile(String name, long fileSize, DirectoryStream parent) {
        this.fileSize = fileSize;
        this.name = name;
        this.parent = parent;
    }

    protected BasicAbstractFile(String name, long fileSize, DirectoryStream parent, CommonFileAttributesProvider attributesProvider) {
        this.name = name;
        this.fileSize = fileSize;
        this.parent = parent;
        createTime = attributesProvider.getCreateTime();
        accessTime = attributesProvider.getAccessTime();
        writeTime = attributesProvider.getWriteTime();
        changeTime = attributesProvider.getChangeTime();
    }

    public final FileType getFileType() {
        return FileType.FILE;
    }

    public final FileDescriptor getFileDescriptor() {
        return this;
    }

    public long getFileSize() {
        return fileSize;
    }

    public long getCreateTime() {
        return createTime;
    }

    public long getAccessTime() {
        return accessTime;
    }

    public long getWriteTime() {
        return writeTime;
    }

    public long getChangeTime() {
        return changeTime;
    }

    public String getName() {
        return name;
    }

    public FileDescriptor getParentFileDescriptor() {
        return getParent().getFileDescriptor();
    }

    public DirectoryStream getParent() {
        return parent;
    }

    @Override
    public String toString() {
        return StringMaker.createString(this,super.toString());
    }


    public FileFlags getFileFlags() {
        return new FileFlags.Builder().setExecutable().setArchive().build();
    }

/*    protected DirectoryStream parent;
    protected long createTime = 0;
    protected long accessTime = 0;
    protected long writeTime = 0;
    protected long changeTime = 0;*/
}
