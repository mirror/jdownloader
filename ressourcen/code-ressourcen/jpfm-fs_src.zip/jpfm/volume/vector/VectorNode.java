/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.volume.vector;

import java.util.Vector;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileType;
import jpfm.volume.CommonFileAttributesProvider;

/**
 *
 * @author Shashank Tulsyan
 */
public abstract class VectorNode 
        extends Vector<FileAttributesProvider>
        implements VectorFileContainer{

    protected final FileDescriptor fileDescriptor = new FileDescriptor();
    protected long createTime = 0;
    protected long accessTime = 0;
    protected long writeTime = 0;
    protected long changeTime = 0;

    public VectorNode(){
        super();
    }
    public VectorNode(int initialCapacity, int capacityIncrement, CommonFileAttributesProvider attributesProvider) {
        //store = new Vector<DE>(initialCapacity, capacityIncrement);
        super(initialCapacity,capacityIncrement);
        createTime = attributesProvider.getCreateTime();
        accessTime = attributesProvider.getAccessTime();
        writeTime = attributesProvider.getWriteTime();
        changeTime = attributesProvider.getChangeTime();
    }

    public VectorNode(CommonFileAttributesProvider attributesProvider) {
        this(10, 0, attributesProvider);
    }



    public long getDirectorySize() {
        long ret = 0;
        for (FileAttributesProvider element : this) {
            if (element instanceof VectorFileContainer) {
                ret += ((VectorFileContainer)element).getDirectorySize();
            } else {
                ret += element.getFileSize();
            }
        }
        return ret;
    }

    public FileType getFileType() {
        return FileType.FOLDER;
    }

    public final FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    public final long getFileSize() {
        return 0;
    }

    public long getCreateTime() {
        return createTime;
    }

    public long getAccessTime() {
        return accessTime;
    }

    public long getWriteTime() {
        return writeTime;
    }

    public long getChangeTime() {
        return changeTime;
    }

}
