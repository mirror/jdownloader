/*
 *  Copyright 2010 ShashankTulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs;

import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.LinkedList;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileId;
import jpfm.FileType;
import jpfm.JPfmMount;
import jpfm.JPfmReadOnlyFileSystem;
import jpfm.UnderprivilegedFormatterListener;
import jpfm.operations.Read;
import jpfm.volume.VeryBigFile;

/**
 * Demonstrates infitely deep directory structure
 * @author Shashank Tulsyan
 */
public class InfinitelyDeepFS
        extends JPfmReadOnlyFileSystem
        implements DirectoryStream,FileAttributesProvider{
    LinkedList<FileAttributesProvider> root;
    FileDescriptor fileDescriptor = new FileDescriptor();
    VeryBigFile veryBigFile;

    public InfinitelyDeepFS() {
        root = new LinkedList<FileAttributesProvider>();
        root.add(this);
        veryBigFile = new VeryBigFile(this);
        root.add(veryBigFile);
    }



    @Override
    protected FileAttributesProvider getRootAttributes() {

        return this;
    }

    @Override
    protected FileAttributesProvider open(String[] filePath) {
        if(filePath[filePath.length-1].equals(veryBigFile.getName()))
            return veryBigFile;
        return this;
    }

    @Override
    protected void open(FileAttributesProvider descriptor) {
        
    }

    @Override
    protected FileAttributesProvider getFileAttributes(FileId fileDescriptor) {
        if(veryBigFile.getFileDescriptor().implies(fileDescriptor))
            return veryBigFile;
        return this;
    }

    @Override
    protected DirectoryStream list(FileId folderToList) {
        return this;
    }

    //@Override
    protected int read(FileId file, long offset, ByteBuffer directByteBuffer) {
        return veryBigFile.read(offset, directByteBuffer);
    }

    @Override
    protected void close(FileId file) {
        return;
    }

    @Override
    protected void delete(FileId fileToDelete) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected long capacity() {
        return 0;
    }

    public Iterator<FileAttributesProvider> iterator() {
        return root.iterator();
    }

    public FileType  getFileType() {
        return FileType.FOLDER ;
    }

    public FileDescriptor getFileDescriptor() {
        return  fileDescriptor;
    }

    public long getFileSize() {
        return 0;
    }

    public long getCreateTime() {
        return 0;
    }

    public long getAccessTime() {
        return 0;
    }

    public long getWriteTime() {
        return 0;
    }

    public long getChangeTime() {
        return 0;
    }

    public String getName() {
        return "directory";
    }

    public FileDescriptor getParentFileDescriptor() {
        return fileDescriptor;
    }


    public static void main(String[] args) throws Exception{
        String mountLocation;
        if(args.length > 0)mountLocation  = args[0];
        else mountLocation = "j:\\neembuu\\virtual\\veryDeep.abstract";
        InfinitelyDeepFS fS = new InfinitelyDeepFS();

        UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener
                l = new UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener();

        JPfmMount jpm = JPfmMount.mount(fS,mountLocation, l);

        l.waitUntilUnmounted();
    }

    public FileFlags getFileFlags() {
        return null;
    }

    @Override
    protected void read(Read read) throws Exception {
        veryBigFile.read(read);
    }

}
