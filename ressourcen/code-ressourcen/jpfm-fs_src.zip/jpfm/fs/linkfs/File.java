/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs.linkfs;

import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileType;
import jpfm.JPfmError;
import jpfm.operations.Read;

/**
 *
 * @author Shashank Tulsyan
 */
public final class File extends FSE//implements FileAttributesProvider
{
    private FileChannel fc;
    private FileDescriptor fileDescriptor = new FileDescriptor();
    private final Node parent;

    public File(Path path, Node parent) {
        super(path,parent);
        this.parent = parent;
    }


    public void open(){
        try{
            fc = FileChannel.open(getPath(), StandardOpenOption.READ);
        }catch(Exception any){any.printStackTrace();}
    }
    
    public void close(){
        try{
            fc.close();
        }catch(Exception any){
            any.printStackTrace();
        }
    }

    public FileType  getFileType() {
        return FileType.FILE ;
    }

    public FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    /*protected void setFileDescriptor(FileDescriptor fd) {
        this.fileDescriptor = fd;
    }*/

    public long getFileSize() {
        try{
            return fc.size();
        }catch(Exception any){
            any.printStackTrace();
            return 0;
        }
    }

    public long getCreateTime() {
        return 0;
    }

    public long getAccessTime() {
        return 0;
    }

    public long getWriteTime() {
        return 0;
    }

    public long getChangeTime() {
        return 0;
    }

    public String getName() {
        return getPath().getParent().getName().toString();
    }

    public FileDescriptor getParentFileDescriptor() {
        return parent.getFileDescriptor();
    }

    public FileFlags getFileFlags() {
        return new FileFlags.Builder().setExecutable().build();
    }

    /*public void read(Read read) throws Exception{
        int actualRead = 0;
        actualRead = fc.read(read.getByteBuffer(),read.getFileOffset());
        read.complete(JPfmError.SUCCESS, actualRead);
    }*/

}
