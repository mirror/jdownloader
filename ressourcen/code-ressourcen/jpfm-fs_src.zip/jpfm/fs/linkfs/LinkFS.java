/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs.linkfs;

import java.io.IOException;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import jpfm.AccessLevel;
import jpfm.FileAttributesProvider;
import jpfm.FileControlFlag;
import jpfm.FileDescriptor;
import jpfm.FileId;
import jpfm.FileType;
import jpfm.JPfmError;
import jpfm.JPfmFileSystem;
import jpfm.JPfmMount;
import jpfm.MountFlags;
import jpfm.UnderprivilegedFormatterListener;
import jpfm.VolumeFlags;
import jpfm.VolumeVisibility;
import jpfm.operations.Capacity;
import jpfm.operations.Close;
import jpfm.operations.Control;
import jpfm.operations.Delete;
import jpfm.operations.FlushFile;
import jpfm.operations.FlushMedia;
import jpfm.operations.List;
import jpfm.operations.MediaInfo;
import jpfm.operations.Move;
import jpfm.operations.MoveReplace;
import jpfm.operations.Open;
import jpfm.operations.Read;
import jpfm.operations.Replace;
import jpfm.operations.SetSize;
import jpfm.operations.Write;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public final class LinkFS extends JPfmFileSystem {
    private final Path pathToReflect;
    private final HashMap<FileId,FSE> fmap = new HashMap<FileId,FSE>();
    private final FSE root;
    
    public LinkFS(Path path) throws IOException {
        super(VolumeFlags.SIMPLE_FLAG);
        this.pathToReflect = path;
        root = new FSE(path);
    }

    public final Path getPathToReflect() {
        return pathToReflect;
    }


    @Override
    protected final void capacity(final Capacity capacity) throws Exception {
        capacity.complete(JPfmError.SUCCESS, 1024*1024*100, 1024*1024*50);
    }

    @Override
    protected final void close(final Close close) throws Exception {
        //System.out.println(close);
    }

    @Override
    protected final void control(final Control control) throws Exception {
        System.out.println(control);
        control.complete(JPfmError.FAILED, 0);
    }

    @Override
    protected final void delete(final Delete delete) throws Exception {
        System.out.println(delete);
        delete.complete(JPfmError.ACCESS_DENIED);
    }

    @Override
    protected final void flushFile(final FlushFile flushFile) throws Exception {
        System.out.println(flushFile);
        flushFile.complete(JPfmError.SUCCESS);
    }

    @Override
    protected final void flushMedia(final FlushMedia flushMedia) throws Exception {
        //System.out.println(flushMedia);
        flushMedia.complete(JPfmError.SUCCESS,FlushMedia.INDEFINITE_FLUSH_DELAY);
    }

    @Override
    protected final void list(final List list) throws Exception {
        //System.out.println("+++list+++");
        //System.out.println(list);
        //System.out.println(fmap);
        FSE fap = null;
        fap = fmap.get(list.getFileId());//(Node)getFileAttributes(list.getFileDescriptor());
        if(fap==null){
            list.complete(JPfmError.NOT_FOUND, true);
            //System.out.println(" not found ");
            //System.out.println("----list----");
            return;
        }
        if(fap.getFileType()!=FileType.FOLDER){
            list.complete(JPfmError.ACCESS_DENIED, true); // not a file
            System.out.println("access denied ");
            System.out.println("----list----");
            return;
        }
        

        Iterator<Path> it = fap.getPath().newDirectoryStream().iterator();
        while(it.hasNext()){
            FSE nextFse = new FSE(it.next(),fap);
            //filedescriptor for these FSE will be set when they are opened
            //but we add a fake one
            nextFse.setFileDescriptor(FileId.INVALID);

            //now time to add this fse to the native directory list
            //System.out.println("adding "+nextFse);
            list.add(nextFse);

            //this fse shall not be added to 
        }
        
        //System.out.println("----list----");
        list.complete(JPfmError.SUCCESS, true);
        //todo
    }

    /*@Override
    protected final void listEnd(ListEnd listEnd) throws Exception {
        //todo
    }*/

    @Override
    protected final void mediaInfo(final MediaInfo mediaInfo) throws Exception {
        System.out.println(mediaInfo);
        mediaInfo.complete(JPfmError.SUCCESS,null,"LinkFS");
    }

    @Override
    protected final void move(final Move move) throws Exception {
        System.out.println(move);
        //FSE moveDestination = new FSE(pathToReflect);
        FSE fileToMove = (FSE)getFileAttributes(move.getSourceFileId());
        if(fileToMove==null){
            move.complete(JPfmError.NOT_FOUND,false,null,null,null,null);
            return;
        }
        FSE fileToMoveDestinationParent = null;
        
        Path destinationPath=pathToReflect;
        Path destinationParentPath=pathToReflect;
        for (int i = 0; i < move.getTargetName().length; i++) {
            try{
                destinationPath = destinationPath.resolve(move.getTargetName()[i]);
                if(i<move.getTargetName().length-1)
                    destinationParentPath = destinationParentPath.resolve(move.getTargetName()[i]);
            }catch(InvalidPathException ipe){
                ipe.printStackTrace(System.out);
                move.complete(JPfmError.ACCESS_DENIED,false,null,null,null,null);
                return;
            }
        }
        destinationPath = destinationPath.toAbsolutePath();
        destinationParentPath = destinationParentPath.toAbsolutePath();

        Iterator<FSE>itmap = fmap.values().iterator();
        while(itmap.hasNext() && (fileToMoveDestinationParent==null)){
            FSE fse = itmap.next();
            if(fse.getPath().equals(destinationParentPath)){
                 fileToMoveDestinationParent = fse;break;
            }
        }
        if(fileToMoveDestinationParent==null){
            move.complete(JPfmError.NOT_FOUND, destinationPath.exists(), fileToMove, fileToMove.getName(), AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
            return;
        }

        fileToMove.setParent(fileToMoveDestinationParent);

        if(destinationPath.exists()){
            move.complete(JPfmError.SUCCESS,true,fileToMove,fileToMove.getName(),AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
            return;
        }
        try{
            fileToMove.getPath().moveTo(destinationPath);
        }catch(Exception any){
            any.printStackTrace(System.out);
            move.complete(JPfmError.FAILED,false,fileToMove,fileToMove.getName(),AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
        }

        fileToMove.setPath(destinationPath);
        //moveDestination==null definitely
        fileToMove.setFileDescriptor(move.getNewExistingFileId());
        move.complete(JPfmError.SUCCESS,false,fileToMove,fileToMove.getName(),AccessLevel.OWNER,FileControlFlag.FORCE_UNBUFFERED);
    }

    @Override
    protected final void moveReplace(final MoveReplace moveReplace) throws Exception {
        System.out.println(moveReplace);
        moveReplace.complete(JPfmError.ACCESS_DENIED);
    }

    @Override
    protected final void open(final Open open) throws Exception {
        //if(makrOpen.getFileType() == FileType.NONE) ==> this makrOpen is a create operation
            /*System.out.print("\t\tcreate ");
            System.out.println(makrOpen.getNewCreateFileDescriptor());
            System.out.print("\t\texisting ");
            System.out.println(makrOpen.getNewExistingFileDescriptor());*/
        Path path = pathToReflect;
        Path parentPath = pathToReflect;
        for (int i = 0; i < open.getName().length; i++) {
            try{
                path  = path.resolve(open.getName()[i]);
            }catch(InvalidPathException ipe){
                //ipe.printStackTrace(System.out);
                open.complete(JPfmError.BAD_NAME, false, AccessLevel.READ_DATA, FileControlFlag.NONE, null);
                return;
            }
            if(i<open.getName().length - 1)
                parentPath = path.resolve(open.getName()[i]);
        }
        path = path.toAbsolutePath();
        parentPath = parentPath.toAbsolutePath();
        FSE fileap = null;// = getFileAttributes(path);
        FSE fapParent = null;

        if(open.getName().length == 0){//check root
            fileap = root;
            if(fmap.size()==0){
                FileId rootFileId = open.getNewExistingFileId();
                root.setFileDescriptor(rootFileId);
                fmap.put(rootFileId, root);                
            }
        }
        else{
            Iterator<FSE>itmap = fmap.values().iterator();
            while(itmap.hasNext() && (fileap==null && fapParent == null) ){
                FSE fse = itmap.next();
                if(fse.getPath().equals(path)){
                    fileap = fse;
                }
                if(fse.getPath().equals(parentPath)){
                    fapParent = fse; 
                }
            }
        }
        //If the indicated file does not exist and the newCreateOpenId parameter is zero then the
        //formatter should return pfmErrorNotFound.
        //If the indicated file does not exist and the newCreateOpenId parameter is non-zero
        //then the formatter should create the file.
        boolean existed = true;
        if(fileap==null){
            if(!path.exists()){//indicated file does not exist
                if(!open.getNewCreateFileId().isValid()){//the newCreateOpenId parameter is zero
                    open.complete(JPfmError.NOT_FOUND, true,AccessLevel.OWNER, FileControlFlag.FORCE_UNBUFFERED, null);
                    return;
                }else{//newCreateOpenId parameter is non-zero => create
                    if(fapParent==null){
                        //parent does not exist, not possible to create file
                        open.complete(JPfmError.BAD_NAME, true,AccessLevel.OWNER, FileControlFlag.FORCE_UNBUFFERED, null);
                        return;
                    }
                    fileap = new FSE(path, fapParent);
                    try{
                        if(open.getFileType()==FileType.FILE){
                            path.createFile();
                        }else if(open.getFileType()==FileType.FOLDER){
                            path.createDirectory();
                        }else {
                            open.complete(JPfmError.ACCESS_DENIED,false,null,null,null);
                            return;
                        }
                    }catch(Exception any){
                        if(!open.isCompleted())open.complete(JPfmError.ACCESS_DENIED,false,null,null,null);
                        return;
                    }
                    fmap.put(fileap.getFileDescriptor().getFileId(), fileap);
                    existed = false;
                }
                fileap.setFileDescriptor(open.getNewCreateFileId() );
            }else {
                fileap = new FSE(path, fapParent);
                fileap.setFileDescriptor(open.getNewExistingFileId());
                fmap.put(fileap.getFileDescriptor().getFileId(), fileap); existed = true;
            }
            
        }else if(fileap.getFileDescriptor() == null) {
            fileap.setFileDescriptor(open.getNewExistingFileId());
        }

        System.out.print("\t\topenfds{");

        System.out.print(fileap.getFileDescriptor());
        if(fileap!=root)
            System.out.print(fileap.getParentFileDescriptor());
        System.out.println("}openfds");

        // todo : specify actual access level
        open.complete(JPfmError.SUCCESS, existed, AccessLevel.OWNER, FileControlFlag.FORCE_UNBUFFERED, fileap);
    }

    @Override
    protected final void read(final Read read) throws Exception {
        FSE fileToRead = (FSE)getFileAttributes(read.getFileId());
        if(fileToRead==null){
            read.complete(JPfmError.NOT_FOUND,0,LinkFSReadCompleter.INSTANCE);
            return;
        }
        fileToRead.read(read);
        //todo
    }

    @Override
    protected final void replace(final Replace replace) throws Exception {
        System.out.println(replace);
        replace.complete(JPfmError.ACCESS_DENIED,null,null,null);
    }

    @Override
    protected final void setSize(final SetSize setSize) throws Exception {
        System.out.println(setSize);
        FSE fileToResize = (FSE)getFileAttributes(setSize.getFileId());
        if(fileToResize==null){
            setSize.complete(JPfmError.NOT_FOUND);
            return;
        }
        fileToResize.setSize(setSize.getFileSize());
        setSize.complete(JPfmError.SUCCESS);
        //setSize.complete(JPfmError.ACCESS_DENIED);
    }

    @Override
    protected final void write(final Write write) throws Exception {
        FSE fileToWrite = (FSE)getFileAttributes(write.getFileDescriptor());
        if(fileToWrite==null){
            write.complete(JPfmError.NOT_FOUND,0);
            return;
        }
        fileToWrite.write(write);
    }

    @Override
    protected FileAttributesProvider getFileAttributes(FileId fileid) {
        System.out.println("++fmap++");
        System.out.println(fmap);
        System.out.println("--fmap--");
        System.out.println("getAttribs for "+fileid);
        return fmap.get(fileid);
        //return Util.getFileAttributes(files, descriptor);
    }

    /*protected FSE getFileAttributes(Path path) {
        for(Iterator<FSE> it = files.iterator(); it.hasNext();) {
            FSE fileAttributesProvider = it.next();
            if(fileAttributesProvider instanceof File){
                if(
                        ((File)fileAttributesProvider).getPath().equals(path)
                        ){
                    return fileAttributesProvider;
                }
            }else if(
                        ((Node)fileAttributesProvider).getPath().equals(path)
                    ){
                return fileAttributesProvider;
            }
        }return null;
    }*/

    /*private final Path getAsPath(final String[]fileName){
        Path ret = root.getPath();
        for (int i = 0; i < fileName.length; i++) {
            ret = ret.resolve(fileName[i]);
        }return ret;
    }*/

    private static final class LinkFSReadCompleter implements Completer {
        private static LinkFSReadCompleter INSTANCE = new LinkFSReadCompleter();
        private LinkFSReadCompleter(){}
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[] getStackTrace() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }

    public static void main(String[] args) throws Exception{
        System.loadLibrary("jpfm");
        System.out.println("loaded");
        LinkFS lfs= new LinkFS(Paths.get("J:\\neembuu\\heap\\LinkFS"));
        UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener 
                wufl = new UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener();
        JPfmMount mount = JPfmMount.mount(
                    lfs,
                    "j:\\neembuu\\virtual\\linkfs",
                    '\0',
                    new MountFlags.Builder()
                        //.setSystemVisible()
                        //.setWorldRead()
                        //.setWorldWrite()
                        .setFolder().build(),
                    wufl,
                    true,
                    VolumeVisibility.GLOBAL
                    //VolumeVisibility.ME_AND_MY_CHILD_PROCESSES
                );/*(
                lfs,
                "j:\\neembuu\\virtual\\linkfs",
                new MountFlags.Builder().setFolder().build(),
                wufl);*/

        //java.awt.Desktop.getDesktop().makrOpen(new java.io.File("j:\\neembuu\\virtual\\linkfs"));
        javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        javax.swing.JFileChooser chooser = new javax.swing.JFileChooser(new java.io.File("j:\\neembuu\\virtual\\"));
        int returnVal = chooser.showOpenDialog(new javax.swing.JFrame());
        java.io.File selectedFile = chooser.getSelectedFile();
        System.out.println("selectedFile="+selectedFile);
        wufl.waitUntilUnmounted();
    }
}
