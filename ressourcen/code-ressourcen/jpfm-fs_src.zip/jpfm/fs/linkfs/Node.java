/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs.linkfs;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Iterator;
import java.util.LinkedList;
import jpfm.FileAttributesProvider;
import jpfm.FileDescriptor;
import jpfm.FileFlags;
import jpfm.FileType;
import jpfm.JPfmError;
import jpfm.operations.List;

/**
 *
 * @author Shashank Tulsyan
 */
public final class Node extends FSE //implements FileAttributesProvider
{
    private FileDescriptor fileDescriptor ;
    private final Path path;
    private final Node parent;
    private final BasicFileAttributes basicFileAttributes;
    private final LinkedList<FSE> files = new LinkedList<FSE>();

    private Node(Path path, Node parent) throws IOException {
        super(path,parent);
        this.path = path;
        this.parent = parent;
        basicFileAttributes = java.nio.file.attribute.Attributes.readBasicFileAttributes(path);

        java.nio.file.DirectoryStream ds = path.newDirectoryStream();
        Iterator<Path> it = ds.iterator();
        while(it.hasNext()){
            Path next = it.next();
            BasicFileAttributes bfa =  java.nio.file.attribute.Attributes.readBasicFileAttributes(next);
            if(bfa.isRegularFile()){
                File f = new File(next, this);
                //list.add(f);
            }else {
                Node n = new Node(next, this);
                //list.add(n);
            }
        }

    }

    public final void addFile(FSE file){
        files.add(file);
    }

    public final LinkedList<FSE> getFilesList(){
        return files;
    }


    public void list(List list)throws Exception{
        java.nio.file.DirectoryStream ds = path.newDirectoryStream();
        Iterator<Path> it = ds.iterator();
        while(it.hasNext()){
            Path next = it.next();
            BasicFileAttributes bfa =  java.nio.file.attribute.Attributes.readBasicFileAttributes(next);
            if(bfa.isRegularFile()){
                File f = new File(next, this);
                list.add(f);
            }else {
                Node n = new Node(next, this);
                list.add(n);
            }
        }list.complete(JPfmError.SUCCESS, true);
    }

    public FileType  getFileType() {
        return FileType.FOLDER;
    }

    public FileDescriptor getFileDescriptor() {
        return fileDescriptor;
    }

    /*protected void setFileDescriptor(FileDescriptor fd) {
        this.fileDescriptor = fd;
    }*/

    public long getFileSize() {
        return 0;
    }

    public long getCreateTime() {
        return basicFileAttributes.creationTime().toMillis();
    }

    public long getAccessTime() {
        return basicFileAttributes.lastAccessTime().toMillis();
    }

    public long getWriteTime() {
        return basicFileAttributes.lastModifiedTime().toMillis();
    }

    public long getChangeTime() {
        return basicFileAttributes.lastModifiedTime().toMillis(); 
    }

    public String getName() {
        return path.getName().toString();
    }

    public FileDescriptor getParentFileDescriptor() {
        if(parent==null)return this.getFileDescriptor();
        return parent.getFileDescriptor();
    }

    public FileFlags getFileFlags() {
        return new FileFlags.Builder().setExecutable().build();
    }

}
