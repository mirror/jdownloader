/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   SimpleFileSystem.java
 * Author: Shashank Tulsyan
 */
package jpfm.fs;

import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileId;
import jpfm.JPfmFileSystem;
import jpfm.VolumeFlags;
import jpfm.operations.Capacity;
import jpfm.operations.Close;
import jpfm.operations.Control;
import jpfm.operations.Delete;
import jpfm.operations.FlushFile;
import jpfm.operations.FlushMedia;
import jpfm.operations.List;
import jpfm.operations.MediaInfo;
import jpfm.operations.Move;
import jpfm.operations.MoveReplace;
import jpfm.operations.Open;
import jpfm.operations.Read;
import jpfm.operations.Replace;
import jpfm.operations.SetSize;
import jpfm.operations.Write;

/**
 * Abstract volumes are case insensitive,
 * In future will have write capabilities as well. For now this is same
 * as {@link SimpleReadOnlyFileSystem }
 * @author Shashank Tulsyan
 */
public class SimpleFileSystem extends JPfmFileSystem {

    protected DirectoryStream rootDirectoryStream;


    public SimpleFileSystem(final VolumeFlags volumeFlags, DirectoryStream rootDirectoryStream) {
        super(volumeFlags);
        this.rootDirectoryStream = rootDirectoryStream;
    }

    @Override
    protected void capacity(Capacity capacity) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void close(Close close) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void control(Control control) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void delete(Delete delete) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void flushFile(FlushFile flushFile) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void flushMedia(FlushMedia flushMedia) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void list(List list) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void mediaInfo(MediaInfo mediaInfo) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void move(Move move) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void moveReplace(MoveReplace moveReplace) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void open(Open open) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void read(Read read) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void replace(Replace replace) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void setSize(SetSize setSize) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected void write(Write write) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected FileAttributesProvider getFileAttributes(FileId fileDescriptor) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
