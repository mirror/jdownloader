/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   Main.java
 * Author: Shashank Tulsyan
 */

package jpfm.fs;

import java.nio.file.Paths;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import jpfm.JPfmMount;
import jpfm.UnderprivilegedFormatterListener;
import jpfm.volume.BasicRealFile;
import jpfm.volume.vector.VectorRootDirectory;

/**
 *
 * @author Shashank Tulsyan
 */
public class Main {
    public static void main(String[] args) throws Exception  {
        try {
            TestFrame fr = null;
            if (args.length < 2) {
                System.out.println("Usage :");
                System.out.println("java -jar jpfm-abstractfs.jar <file to be placed in the virtual folder> <mountlocation> ");
                System.out.println(" ");

                fr = new TestFrame(null);
                fr.setVisible(true);

                JFileChooser jfc = new JFileChooser();
                jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
                jfc.setMultiSelectionEnabled(false);

                args = new String[2];

                JOptionPane.showMessageDialog(fr, "Choose file to be placed in the virtual folder");
                int retC = jfc.showOpenDialog(fr);
                if (retC == JFileChooser.APPROVE_OPTION) {
                    args[0] = jfc.getSelectedFile().toString();
                } else {
                    System.exit(0);

                }
                JOptionPane.showMessageDialog(fr, "Choose mount location");
                jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                retC = jfc.showOpenDialog(fr);
                if (retC == JFileChooser.APPROVE_OPTION) {
                    args[1] = jfc.getSelectedFile().toString();
                } else {
                    System.exit(0);

                }
            }
            VectorRootDirectory rootDirectory = new VectorRootDirectory();
            SimpleReadOnlyFileSystem fileSystem = new SimpleReadOnlyFileSystem(rootDirectory);
            rootDirectory.add(new BasicRealFile(Paths.get(args[0])));
            UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener listener = new UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener();

            final JPfmMount jPfmMount = JPfmMount.mount(fileSystem, Paths.get(args[1]).toString(), listener);
            if (fr != null) {
                fr.setMount(jPfmMount);

            }
            System.out.println("Press Ctrl+C to exit....");
            //java.awt.EventQueue.invokeLater(new Runnable() {
            //  public void run() {
            fr.setVisible(true);
            //}
            //});
            //listener.waitUntilUnmounted();
        } catch (Exception exception) {
            exception.printStackTrace();
            System.exit(0);
        }
    }
}
