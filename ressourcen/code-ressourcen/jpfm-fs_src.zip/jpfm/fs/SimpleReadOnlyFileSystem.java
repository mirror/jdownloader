/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   SimpleReadOnlyFileSystem.java
 * Author: Shashank Tulsyan
 */
package jpfm.fs;

import java.nio.ByteBuffer;
import java.util.Iterator;
import jpfm.DirectoryStream;
import jpfm.FileAttributesProvider;
import jpfm.FileId;
import jpfm.FileType;
import jpfm.JPfmContainable;
import jpfm.JPfmError;
import jpfm.JPfmMount;
import jpfm.JPfmReadOnlyFileSystem;
import jpfm.JPfmReadable;
import jpfm.UnderprivilegedFormatterListener;
import jpfm.annotations.Blocking;
import jpfm.annotations.MightBeBlocking;
import jpfm.operations.Read;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;
import jpfm.volume.AbstractFile;
import jpfm.volume.VeryBigFile;
import jpfm.volume.vector.VectorRootDirectory;

/**
 * Abstract volumes are case insensitive
 * @author Shashank Tulsyan
 */
public class SimpleReadOnlyFileSystem extends JPfmReadOnlyFileSystem {

    protected DirectoryStream rootDirectoryStream;


    public SimpleReadOnlyFileSystem(DirectoryStream rootDirectoryStream) {
        this.rootDirectoryStream = rootDirectoryStream;
    }

    @Override
    protected FileAttributesProvider getRootAttributes() {
        return rootDirectoryStream;
    }


    @Override
    protected final FileAttributesProvider open(String[] filePath) {

        /*for (int i = 0; i < filePath.length; i++) {
            System.out.print(filePath[i]);System.out.print("\\");
        }System.out.println();*/
        FileAttributesProvider ret = SimpleReadOnlyFileSystem.find(rootDirectoryStream, filePath, 0);
        //System.out.println(ret);
        if(ret==null)return null;
        return ret;
    }

    @Override
    protected void open(FileAttributesProvider ret) {
        if(ret.getFileType()==FileType.FILE){
            ((JPfmReadable)ret).open();
        }
    }

    @Override
    protected final FileAttributesProvider getFileAttributes(FileId fileI) {
        if(fileI.implies(rootDirectoryStream.getFileDescriptor())){
            return rootDirectoryStream;
        } 
        FileAttributesProvider ret = findFile(fileI);//find((C)rootDirectoryStream, fileDescriptor);
        if(ret==null)return null;
        return ret;
    }

    @Override
    protected final DirectoryStream list(FileId folderToList) {
        if(folderToList==null){
            System.out.println("Folder to list is null!, JPfmAbstractFileSystem : line 58");
            return null;
        }
        if(folderToList.implies(rootDirectoryStream.getFileDescriptor())){
            return rootDirectoryStream;
        }
        FileAttributesProvider fse = findFile(folderToList);//find((C)rootDirectoryStream, folderToList);
        if (fse == null) {
            return null;
        }
        if (!(fse instanceof DirectoryStream)) {
            return null;
        }
        return (DirectoryStream) fse;
    }


    @MightBeBlocking(reason="Request is forwarded to appropriate jpfm.JPfmReadable")
    @Override
    protected void read(Read read) throws Exception {
        FileAttributesProvider fse = findFile(read.getFileId());//find((C)rootDirectoryStream, file);
        if (fse == null) {
            //System.out.println("JPfmFileSystem.java line 107 : Could not find fse = "+read.getFileDescriptor()());
            //this cannot happen really
            //return JPfmReadOnlyFileSystem.READ_FILE_NOT_FOUND;
            read.complete(JPfmError.NOT_FOUND , 0,new SimpleReadCompleter());
            return;
        }
        if (!(fse instanceof JPfmReadable)) {
            // if you have some other way of implementing this
            // you should override this method
            //return JPfmReadOnlyFileSystem.READ_END_OF_FILE;
            read.complete(JPfmError.END_OF_DATA,0,new SimpleReadCompleter());
            return;
        }
        //return ((JPfmReadable) fse).read(offset, directByteBuffer);
        ((JPfmReadable) fse).read(read);
    }

    private static final class SimpleReadCompleter implements Completer {
        private final StackTraceElement[] stackTrace;
        private SimpleReadCompleter(){
            this.stackTrace = new Throwable().getStackTrace();
        }
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public void completeNow(ReadRequest pendingRequest) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        public StackTraceElement[] getStackTrace() {
            return stackTrace;
        }
    }

    //@Override
    @Blocking
    protected final int read(FileId file, long offset, ByteBuffer directByteBuffer) {
        FileAttributesProvider fse = findFile(file);//find((C)rootDirectoryStream, file);
        if (fse == null) {
            System.out.println("JPfmFileSystem.java line 103 : Could not find fse = "+file);
            //this cannot happen really
            return JPfmReadOnlyFileSystem.READ_FILE_NOT_FOUND;
        }
        if (!(fse instanceof JPfmReadable)) {
            // if you have some other way of implementing this
            // you should override this method
            return JPfmReadOnlyFileSystem.READ_END_OF_FILE;
        }
        return ((JPfmReadable) fse).read(offset, directByteBuffer);
    }

    @Override
    protected final void close(FileId file) {
        FileAttributesProvider fse = findFile(file);//find((C)rootDirectoryStream, file);
        if (fse == null) {
            return;
        }
        if (!(fse instanceof AbstractFile)) {
            return;
        }
        ((JPfmReadable) fse).close();
    }

    @Override
    protected final long capacity() {
        return SimpleReadOnlyFileSystem.getDirectorySize(rootDirectoryStream);
        //return rootDirectoryStream.getDirectorySize();
    }

    @Override
    protected final void delete(FileId fileToDelete) {
        FileAttributesProvider fse  = findFile(fileToDelete);;//find((C)rootDirectoryStream, fileToDelete);
        if(!(fse instanceof JPfmContainable)){
            throw new UnsupportedOperationException("Does not implement JPfmContainable, cannot find parent");
        }
        Iterator<FileAttributesProvider> it = ((JPfmContainable)fse).getParent().iterator();
        while(it.hasNext()){
            if(it.next().equals(fse))
                it.remove();
        }        
    }

    public FileAttributesProvider findFile(FileId fileDescriptor){
        FileAttributesProvider ret
            =
                SimpleReadOnlyFileSystem.find(
                    rootDirectoryStream,
                    fileDescriptor
                );
        return ret;
    }
    

    public static final long getDirectorySize(DirectoryStream directory){
        int size = 0;
        for (FileAttributesProvider ele : directory) {
            if(ele.getFileType()==FileType.FILE){
                size+=ele.getFileSize();
            }else{
                if(ele instanceof DirectoryStream){
                    size += getDirectorySize((DirectoryStream)ele);
                }
            }
        }
        return size;
    }


    public static final FileAttributesProvider find(
            DirectoryStream container,
            FileId fileDescriptor) {
            //System.out.println("container="+container);
        for (FileAttributesProvider fse : container) {
            //System.out.println("ele="+fse);
            if (fse.getFileDescriptor().implies(fileDescriptor)) {
                return fse;
            }
            if (fse instanceof DirectoryStream) {
                if(!(fse instanceof FileAttributesProvider)){
                    continue;
                }
                FileAttributesProvider tmp = find(
                        (DirectoryStream)fse, fileDescriptor);
                if(tmp!=null)return tmp;
            }
        }
        return null;
    }

    public static final FileAttributesProvider find(
            DirectoryStream container,
            String[] name,
            int index) {
        //root directory is handled internally
        for (FileAttributesProvider de : container) {
            if (name[index].equalsIgnoreCase(de.getName())) {
                if (index == name.length - 1) {
                    return de;
                }
                if (de instanceof DirectoryStream) {
                    FileAttributesProvider ret = find(
                            (DirectoryStream)de, name, index + 1
                    );
                    if (ret != null) {
                        return ret;
                    }
                }
            }
        }
        return null;
    }

    public static void main(String[] args)  throws Exception {
        if(args.length<1){
            System.err.println("++++++++++Syntax++++++++++");
            System.err.println("java -jar jpfm-fs.jar <mountLocation>");
            System.err.println("mountLocation refers to existing file/folder where" +
                    "you would like to see the virtual volume appear.");
            System.err.println("----------Syntax----------");
            System.exit(1);
        }
        String mountLocation = args[0];
        java.io.File fl = new java.io.File(mountLocation);
        if(!fl.exists()){
            System.err.println("Mountlocatin does not exist");
            System.err.println("You need to create this file/folder "+fl.getAbsolutePath());
            System.exit(1);
        }

        VectorRootDirectory rootDirectory = new VectorRootDirectory();
        VeryBigFile veryBigFile = new VeryBigFile(rootDirectory);
        rootDirectory.add(veryBigFile);
        SimpleReadOnlyFileSystem fileSystem = new SimpleReadOnlyFileSystem(rootDirectory);
        UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener
                listener =
        new UnderprivilegedFormatterListener.WaitingUnderprivilegedFormatterListener();
        JPfmMount mount = JPfmMount.mount(
                fileSystem,
                mountLocation,
                listener);
        listener.waitUntilUnmounted();

    }
}
