/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   JPfmReadable.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.io.Closeable;
import java.nio.ByteBuffer;
import jpfm.annotations.Blocking;
import jpfm.annotations.MightBeBlocking;
import jpfm.operations.Read;
import jpfm.operations.readwrite.ReadRequest;

/**
 *
 * @author Shashank Tulsyan
 */
public interface JPfmReadable<R extends ReadRequest> extends Closeable{
    public void open();

    /**
     * JPfm equivalent of read.
     * Invoked when read requests are made on a file.
     * The ByteBuffer is a directBuffer and should be filled with the requested region
     * @param offset The offset of the file from where reading is started
     * @param directByteBuffer The buffer where the data is to be filled. In general, if possible the buffer should be fully filled.
     * @return Value greater than equal to zero if file corresponding to the given FileDescriptor was found,
     * and this returned value indicates the actual number of bytes filled in buffer
     * A negative 1 is returned if the end of the file is reached
     * Any value smaller than -1 to indicate that file was not found
     */
    @Deprecated
    @Blocking
    public int read(long offset, ByteBuffer directByteBuffer);

    /**
     * JPfm equivalent of concurrent read.
     * Invoke {@link jpfm.operations.Read#complete(jpfm.JPfmError, int) }
     * when completed. Do not pass -1 as actualRead to indicate
     * end of file. Instead pass {@link  jpfm.JPfmError#END_OF_DATA } and the error value,
     * and 0 for actualRead.
     */
    @MightBeBlocking
    public void read(R read)throws Exception;


    /**
     * This is called when all instances of the file have been closed.
     * The memory allocated and handles can be freed and FileDescriptor can be saved or forgotten whichever
     * is desired. (removing reference to FileDescriptor will free 40 bytes of memory  )
     */
    public void close();
}
