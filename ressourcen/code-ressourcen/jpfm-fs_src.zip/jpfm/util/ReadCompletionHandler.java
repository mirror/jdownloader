/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.util;

import java.nio.channels.CompletionHandler;
import jpfm.JPfmError;
import jpfm.operations.Read;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;

/**
 * This is used for handling completion of read requests, with the assumptions : <ul>
 * <li>Read request made is atomic with reference of the filesystem as well, and will not be broken
 * into smaller parts, each bytebuffer being handled differently.
 * <li>pendingRequest.getByteBuffer().position() == the amount of data read.
 * </ul>
 * @author Shashank Tulsyan
 */
public final class ReadCompletionHandler<R extends ReadRequest>
        implements
            CompletionHandler<Integer,Read> {
    public static final ReadCompletionHandler INSTANCE = new ReadCompletionHandler();
    public static final ReadCompletionHandler getHandler(){return INSTANCE;}
    private static final boolean DEBUG = true;

    private ReadCompletionHandler(){}
    public void completed(Integer result, Read attachment) {
        //if(DEBUG)System.out.println("completed= "+attachment);
        // do not check for completion.
        // the implementor should have had brains to send it to only one

        if(attachment.isCompleted()){
            System.out.println("trying to complete, a completed attachment");
            return;
        }

        if(result==0){
            //ignore
            System.out.println("result was zero "+attachment);
            //return;
        }

        if(result == -1){
            attachment.complete(JPfmError.END_OF_DATA, 0, new SimpleCompleter(new Throwable().getStackTrace()));
            return;
        }
        if(!attachment.isCompleted())
            attachment.complete(JPfmError.SUCCESS, result, new SimpleCompleter(new Throwable().getStackTrace()));
        else {
            //System.out.println("fix this");
        }
    }

    public void failed(Throwable exc, Read attachment) {
        if(DEBUG)System.out.println("failed= "+attachment);
        if(attachment.isCompleted()){
            System.out.println("Weird behaviour "+this+" attachment="+attachment);
            return;
        }
        if(exc instanceof Exception)
            attachment.handleUnexpectedCompletion((Exception)exc);
        else {
            Exception k = new Exception(exc.getMessage(),exc.getCause());
            k.setStackTrace(exc.getStackTrace());
            attachment.handleUnexpectedCompletion(k);
        }
    }

    public static final class SimpleCompleter<R extends ReadRequest> implements Completer<R> {
        private final StackTraceElement[] stackTrace ;

        public SimpleCompleter(final StackTraceElement[] stackTrace) {
            this.stackTrace = stackTrace;
        }

        /**
         * Works under the assumption that pendingRequest.getByteBuffer().position() == the amount of data read.
         */
        public final int getBytesFilledTillNow(R pendingRequest) {
            /*if(pendingRequest.isCompleted())
                return pendingRequest.getByteBuffer().position();*/
            return pendingRequest.getByteBuffer().position();
        }

        /**
         * Works under the assumption that pendingRequest.getByteBuffer().position() == the amount of data read.
         */
        public final void completeNow(R pendingRequest) {
            int assumedActualRead = pendingRequest.getByteBuffer().position();
            if(assumedActualRead==-1){
                pendingRequest.complete(JPfmError.END_OF_DATA, 0, this);
                return;
            }
            if(assumedActualRead==0){
                pendingRequest.complete(JPfmError.getJPfmErrorForNothingRead(), assumedActualRead, this);
                return;
            }
            pendingRequest.complete(JPfmError.SUCCESS, assumedActualRead, this);
        }

        public StackTraceElement[] getStackTrace() {
            return stackTrace;
        }
        
    }

}
