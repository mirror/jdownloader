#define RARVER_MAJOR     3
#define RARVER_MINOR    93
#define RARVER_BETA      0
#define RARVER_DAY      15
#define RARVER_MONTH     3
#define RARVER_YEAR   2010
