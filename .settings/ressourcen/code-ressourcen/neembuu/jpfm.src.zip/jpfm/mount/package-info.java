/**
 * For mounting a <code>filesytem</code> instance with a variable name <code>toMount</code>,
 * where filesystem either implements {@link jpfm.fs.BasicFileSystem }
 * or {@link jpfm.fs.AsynchronousFileSystem }.<br/>
 * See the javadoc of {@link jpfm.mount.MountParams.ParamType} for further detail about each parameter.
 * <br/><br/>
 * {@link jpfm.mount.Mount} mount = {@link jpfm.mount.Mounts#mount}(<br/>
 * &nbsp;&nbsp;new {@link jpfm.mount.MountParamsBuilder}<br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;.set({@link jpfm.mount.MountParams.ParamType#FILE_SYSTEM}, toMount)<br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;.set({@link jpfm.mount.MountParams.ParamType#MOUNT_LOCATION},mountLocation)<br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;.set({@link jpfm.mount.MountParams.ParamType#LISTENER}, u)<br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;.set({@link jpfm.mount.MountParams.ParamType#EXIT_ON_UNMOUNT}, true)<br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;.build()<br/>
 * );<br/>
 */
package jpfm.mount;
