/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.mount;

/**
 *
 * @author Shashank Tulsyan
 */
public final class MountId {
    private final long mountid;
    private final boolean cascadedMount;

    public MountId(long mountid) {
        this.mountid = mountid;
        this.cascadedMount = false;
    }

    public MountId(long mountid, boolean cascadedMount) {
        this.mountid = mountid;
        this.cascadedMount = cascadedMount;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof MountId){
            return ((MountId)obj).mountid == this.mountid;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (int)(this.mountid);
    }

    /**
     * @return true if and only if this is not a cascade mount and
     * represents an actual mount in the native filesystem
     */
    public boolean isValid(){
        return mountid>0 && !cascadedMount;
    }

    public boolean isCascadedMount(){
        return cascadedMount;
    }

}
