/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   FormatterListener.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import java.util.LinkedList;
import java.util.logging.Level;

/**
 *
 * @author Shashank Tulsyan
 */
final class FormatterListener {

    private LinkedList<MountListener> listeners = null;
    private boolean exitOnUnmount;
    //private static boolean toStdOut = true;
    private final JPfmMount mount;
    private final Object listeners_lock = new Object();
    private static JPfm.Manager manager;

    final static void setManager(JPfm jPfm, JPfm.Manager m){
        if(jPfm==null)throw new IllegalArgumentException("jpfm passed was null");
        if(!jPfm.isManagerValid(m))throw new IllegalArgumentException("invalid manager passed");
        manager = m;
    }

    protected FormatterListener(boolean exitOnUnmount, final JPfmMount mount) {
        this.exitOnUnmount = exitOnUnmount;
        this.mount = mount;
    }

    /*package private*/ final JPfmMount getMount() {
        return mount;
    }
    
    public final void eventOccurred(final FormatterEvent event) {
        if(manager==null){
            JPfm.setDefaultManager();
            manager.getLogger().log(Level.INFO,"Default manager set by formatterlistener");
        }

        if (event == null) {
            //System.out.println("event shold not be null");
            manager.getLogger().log(Level.INFO,"event shold not be null");
            return;
        }


        manager.getLogger().log(Level.INFO,
                "Formatter Event '{'Mount = {0} '}{' {1} '}' ",new Object[]{mount, event.toString()});
        //if (toStdOut) {
            //System.out.print("Formatter Event {Mount = " + mount +"}");
            //System.out.println(event);
        //}

        if (exitOnUnmount) {
            if (event.getEventType() == FormatterEvent.EVENT.DETACHED) {
                manager.getLogger().log(Level.INFO,"Exit on unmount option was enabled by {0} , exiting... ", mount ) ;
                //if (toStdOut) {
                    //System.out.println("Exit on unmount option was enabled, exiting...");
                    System.exit(0);
                //}
            }
        }

        //this call is from a native method, we do not want any trouble
        //propagating to native side, neither do we want to make
        //the native code complex trying to figure out java exceptions
        if (listeners == null) {
            return;
        }
        synchronized(listeners_lock){
            for (final MountListener listener : listeners) {
                try {
                    Thread t = new Thread() {

                        @Override
                        public void run() {
                            listener.eventOccurred(event);
                        }
                    };
                    t.start();
                } catch (Exception any) {
                }
            }
        }
    }

    public final void addListener(MountListener listener) {
        synchronized(listeners_lock){
            if (listener == null) {
                return;
            }
            if (listeners == null) {
                listeners = new LinkedList<MountListener>();
            }
            listeners.add(listener);
        }
    }

    public final void removeListener(MountListener listener) {
        synchronized(listeners_lock){
            if (listener == null) {
                return;
            }
            listeners.remove(listener);
            if (listeners.size() == 0) {
                listeners = null;
            }
        }
    }
}
