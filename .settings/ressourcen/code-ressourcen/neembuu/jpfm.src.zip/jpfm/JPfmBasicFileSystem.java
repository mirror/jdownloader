/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   JPfmBasicFileSystem.java
 * Author: Shashank Tulsyan
 */
package jpfm;

import jpfm.annotations.NonBlocking;
import jpfm.annotations.Blocking;
import java.nio.channels.FileChannel;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import jpfm.annotations.MightBeBlocking;
import jpfm.operations.FileSystemOperationImpl;
import jpfm.operations.ReadImpl;
import jpfm.operations.readwrite.Completer;
import jpfm.operations.readwrite.ReadRequest;
//import jpfm.volume.AbstractVolume;

/**
 * JPfmBasicFileSystem is a quick way to implement readonly
 * virutal filesystems in java. JPfmBasicFileSystem , {@link jpfm.fs.SimpleReadOnlyFileSystem }
 * or classes extending any of these can be used to quickly make
 * readonly virtual filesystems in java
 *<br/>
 *<br/>
 * This is semiconcurrent, that is
 * All filesystem functions are
 * implemented as blocking in nature, with exception to read.
 * <br/><br/>
 * <u>Some advice :</u><ul>
 * <li>All JPfmBasicFileSystem functions (with exception to {@link #read(jpfm.operations.ReadImpl) } )
 * are intrinsically blocking in nature. That is, there is no way to implement them in NonBlocking fashion.
 * Therefore {@link #open(filePath)} , {@link #getFileAttributes(null) },
 * {@link #close(jpfm.FileDescriptor) } , {@link #capacity() },
 * {@link #delete(jpfm.FileDescriptor) } , {@link #getRootAttributes() } and
 * {@link #list(jpfm.FileDescriptor) }  should be implemented in such a
 * way that it does not take much time to execute,
 * because the client application may be in <b>Not Responding</b> state during execution of these functions.
 * <li><u>ReadImpl requests (that is {@link #read(jpfm.operations.ReadImpl)  } )</u><br/>
 * If the implementor feels, might take some time for the request to be satisifed,
 * he should handle it in a separate thread or do it in a non-blocking java-nio fashion.
 * Implementing read in blocking fashion
 * might risk locking the client application in <b>Not Responding</b> state.
 * See {@link java.nio.channels.AsynchronousFileChannel } and
 * {@link neembuu.vfs.test.ThrottledRealFile } for inspiration.
 * <li>It would be good idea to shift to {@link JPfmFileSystem }
 * if non-blocking nature is required for all filesystem functions. 
 * JPfmFileSystem provides all pismo file mount features.
 * <li>Cases in which you should use {@link JPfmFileSystem } would be
 * for example : FTPFileSystem . See {@link JPfmFileSystem#list(jpfm.operations.List) }
 * for exact reason why an FTPFileSystem would be implemented using non blocking list
 * implementation.
 * </ul>
 * <br/><br/>
 * <u>JPfm annotations</u>
 * Keep an eye on the type of annotation on methods, it is one of :
 * <ul>
 * <li> {@link jpfm.annotations.NonBlocking}
 * <li> {@link jpfm.annotations.Blocking}
 * <li> {@link jpfm.annotations.MightBeBlocking}
 * </ul>
 * Try to annotate your functions, and also note the annotation made of JPfm library functions,
 * as it will keep you conscious why a method has been implemented as blocking, what are assumptions made,
 * why it must be implemented in non blocking fashion, when it is safe to
 * ignore .... so on so forth.
 * @see #read(jpfm.operations.ReadImpl)
 * @see JPfmFileSystem
 * @author Shashank Tulsyan
 */
@Blocking(getReasonWhyItDoesNotMatter="Although functions are intrinsically blocking in nature, read function can be implemented as non blocking")
abstract class JPfmBasicFileSystem {

    private ReadDispatchThread readDispatchThread ;
    /**
     * Requests that have not been dispatched by the Dispatch thread yet.
     * These requests are thus surely incomplete.
     */
    final LinkedBlockingQueue<FileSystemOperationImpl> pendingOperations;
    // if monitor snatched, it means that new fs op is queue
    //private final Object pendingReqLock = new Object(); not required any more
    private final Object incompleteReqLock = new Object(); // required as removable is from random locations
    /**
     * This is used to keep track of readrequests that have not been satisfied (or completed) yet.
     * These might have been dispatched by the appropriate Dispatch thread and delegated to 
     * appropriate region handler. Even so, the read handler might be still working to complete this 
     * request. Thus these requests might need to be forcefully completed to avoid the operating system
     * filesystem explorer (example : windows explorer, nautilius ) from going into not responding state.
     * Implementors of JPfmBasicFileSystem may use
     */
    protected final ConcurrentLinkedQueue<FileSystemOperationImpl> incompleteOperations = new ConcurrentLinkedQueue<FileSystemOperationImpl>();
    /*package private*/ final MountStateListener mountStateListener = new MountStateListener(this);
    //protected static ReadImpl.ForceComplete READ_FORCE_COMPLETER = null;
    private final ConcurrentLinkedQueue<FileSystemMountStateListener> mountStateListeners = new ConcurrentLinkedQueue<FileSystemMountStateListener>();
    private final AtomicInteger mountCount = new AtomicInteger(0);
    private final static LinkedList<JPfmBasicFileSystem>
            fileSystems = new LinkedList<JPfmBasicFileSystem>();

    private static final Logger LOGGER = Logger.getLogger(JPfmBasicFileSystem.class.getName());

    public static Collection<JPfmBasicFileSystem> getFileSystems() {
        // TODO : should be wrapped around nonmodifible colleciton
        return fileSystems;
    }

    public JPfmBasicFileSystem() {
        //readDispatchThread = new ReadDispatchThread(this);
        pendingOperations = new LinkedBlockingQueue<FileSystemOperationImpl>();
        //readDispatchThread.start(); call from mount state listener instead
    }

    /*package private*/JPfmBasicFileSystem(final LinkedBlockingQueue<FileSystemOperationImpl> pendingReadOperations){
        //writableFS has overtaken the responsibility
        readDispatchThread = null;
        this.pendingOperations = pendingReadOperations;
    }

    /**
     * Called from native side, concurrent read requests are send here.
     * This is not called when JPfmFileSystem is implemented.
     * JPfmFileSystem has it's own dispatch methods.
     * This functions adds requests to pendingOperations
     * and ReadDispatch thread dispatches them from a separate thread.
     * Thus all filesystem operations other than read share a single thread,
     * being implemented in blocking fashion, and all read operations
     * are dispatched from a single independent thread.
     */
    @NonBlocking
    private final void concurrentRead(ReadImpl read){
        PENDINGREQSETTER.setIncompleteRequestContainer(read, incompleteOperations);
        incompleteOperations.add(read); 
        pendingOperations.add(read);
            
        //pendingOperations.add(read);//thread safe
        /*synchronized(pendingReqLock){
            //synchronization is required only if same volume is mounted
            //at more than one location
            pendingReqLock.notifyAll();
        }*/
        //System.out.println("adding"+read);
    }

    @MightBeBlocking(reason="Function is abstract")
    protected abstract void read(ReadImpl read)throws Exception;

    ///*to remove later*/ private AbstractVolume getVolume(){return null;}
    
    //+++++++++++pismo file mount equivalents++++++++++
    /**
     * @return FileAttributesProvider for the root directory
     */
    //@NotNull
    protected abstract FileAttributesProvider getRootAttributes();

    /**
     * Called from native side. Call forwarded to abstract open.
     * Added to process filedecriptor after opening.
     * Doing this using JNI is cumbersome.
     * @param filePath
     * @return
     */
    private final FileAttributesProvider open1(String[] filePath){
        if(!SystemUtils.IS_OS_WINDOWS){
            /*System.out.print("Path={");
            for (int i = 0; i < filePath.length; i++) {
                System.out.print(filePath[i]);
                System.out.print(" , ");

            }System.out.print("}");System.out.println("");*/
            // we need to fix the path
            // the path cab be anything like new String[]{"fs","..","gs"}
            // which is actually simply new String[]{"gs"};

            if(filePath.length>0){
                if(filePath[0].startsWith("/")){
                    filePath[0] = filePath[0].substring(1);
                }
            }
        }
        FileAttributesProvider ret = open(filePath);
        if(ret!=null){
            if(ret.getFileDescriptor()!=null){
                boolean wasOpen = ret.getFileDescriptor().isOpen();
                ret.getFileDescriptor().opened();
                if(!wasOpen)
                    open(ret); // to ensure opening of files
            }
        }            
        return ret;
    }

    /**
     * The for filepath  /directory1/file1.bin
     * filePath[] = {"directory1", "file1.bin"} <br/>
     * <br/>
     * The filedescriptor is set as open after this method
     * successfully returns. Just after that,
     * {@link #open(jpfm.FileDescriptor) } is called.
     * It is in {@link #open(jpfm.FileDescriptor) } that you
     * should call open() of any JPfmReadable. <br/>
     * Here you are supposed to simply return the
     * appropriate FileAttributesProvider, nothing more.
     * @param filePath The path of the file or folder being opened
     * @return FileAttributesProvider associated with the given filePath
     * or null if no such file exists in the Volume
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that open consumes negligible time to complete")
    protected abstract FileAttributesProvider open(String[] filePath);

    /**
     * This is always called after opening of the file, if and only if
     * the file is being opened for the first time.
     * This method should be used to call open() function
     * of all JPfmReadables .
     * @param FileAttributesProvider
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that open consumes negligible time to complete")
    protected abstract void open(FileAttributesProvider fap);

    /**
     * Invoked for file whose existence in the abstract volume was
     * recently confirmed. This is used for serializingOpen operation.
     *
     *
     * This has no concurrent counterpart and is also used in {@link JPfmBasicFileSystem } .
     * Just as all blocking fileystem method this method should be implemented in such a
     * way that it does not take much time to execute,
     * because the client application may be in <b>Not Responding</b> state during execution of this.
     * <br/>
     * The FileAttributesProvider is not cached by the JPfm.
     * This provides the freedom for the FileAttributes to be saved in
     * any desired fashion : in RAM, harddisk or database;
     * which would probably be more efficient
     * (and memory saving) that JPfm handling all this.
     * <br/>
     * Even the FileDescriptor is not cached by JPfm, it only
     * maintains certain Id to differentiate between files.
     * <br/>
     * The correct way to know if a given
     * FileAttributesProvider correspondes to the
     * FileDescriptor passed is  to get the fileDescriptor FileAttributesProvider being checked
     * by {@link FileAttributesProvider#getFileDescriptor()} and then
     * using {@link FileDescriptor#implies(jpfm.FileDescriptor) } passing it the
     * fileDescriptor of the file being reopened.
     * If {@link FileDescriptor#implies(jpfm.FileDescriptor) } returns true
     * then that FileAttributesProvider should be returned.
     * If no FileAttributesProvider in this volume satify this criteria
     * null can be returned. (this implies that the file existed but not any more)
     *
     * @param fileDescriptor The fileDescriptor corresponding to a
     * file
     * @return The FileAttributesProvider associated with the given
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that getFileAttributes consumes negligible time to complete, and files metainfo is not backed by a slow source.")
    protected abstract FileAttributesProvider getFileAttributes(FileId fileDescriptor);

    /**
     * @param folderToList The FileDescriptor of the folder whoes contents are to be listed
     * Null may be returned
     * @return DirectoryStream that provides an iterator over the abstract list of files
     * and folders in this folderToList
     */
    @Blocking(getReasonWhyItDoesNotMatter="assuming that list consumes negligible time to complete, as the folder is not a remote one, or folder contents have been cached")
    protected abstract DirectoryStream list(FileId folderToList);

    /**
     * This is called when all instances of the file have been closed.
     * The memory allocated and handles can be freed and FileDescriptor can be saved or forgotten whichever
     * is desired. (removing reference to FileDescriptor will free 40 bytes of memory  )
     * @param file The filedescriptor of the file who's resources (if any) can be freed/that is file can be closed
     */
    @Blocking(getReasonWhyItDoesNotMatter="Calls to close in any java.io or java.nio library do not block")
    protected abstract void close(FileId file);

    /**
     * This is called when user/an application tries to delete a file.
     * Implementing this is would allow deletion of malicious files.
     * It is would be a better idea not to check if the file is being read, before deleting it,
     * because this way malicious files cannot be locked.
     * Files on virtual filesystem are unreal, so it does not matter if they are deleted, they can
     * be very easily re-added to the filesystem.
     *
     * <br/><br/><br/><br/>
     * <b><u>Additional reference from PFM docs</u></b><br/><br/>
     * <i>Please note : Native implementation is different from java implementation. The description
     * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
     * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
     * <br/><br/>
     * <b>Deleted Files</b><br/>
     * The PFM Protocol handles file deletion using a unix model,
     * where deletion applies to file names as opposed to underlying
     * file data. After a file has been deleted, the file data must
     * remain accessible until the file is finally closed.<br/><br/>
     * The unix file deletion model requires extra code for some formatters.
     * For other formatters it is trivially supported. Regardless,
     * it is a requirement for formatters and is utilized by the driver.<br/><br/>
     * Formatter developers should understand that the NT file system
     * model is more complex than is apparent to casual
     * users of the Win32 API. Using a unix model for
     * file delete allows the driver to achieve a high level
     * of application compatibility in a more portable and
     * supportable way than if the native NT delete model were
     * directly supported by the protocol.
     *
     * @param file The filedescriptor of the file whoes resources (if any) can be freed/that is file can be closed
     */
    @Blocking
    protected abstract void delete(FileId fileToDelete);

    /**
     * The total size of the volume.
     * For read only volume it is the sum of size of each file in the volume.
     * This is only informative and incorrect implementation will not cause funtional failuers in readonly volume/formatter.
     * @return The total size of the volume, that is the sum of size of each file in the volume
     */
    @Blocking
    protected abstract long capacity();
    //-----------pismo file mount equivalents---------


    /**
     * Cascade mounting is mounting of a virtual filesystem over another.
     * <br/><br/>
     * For example we have somemovie.mkv.001, somemovie.mkv.002 .....
     * somemovie.mkv.007 mounted in NeembuuVirtualFileSystem.
     * Now we mount the somemovie.mkv.001 file using SplitFS.
     * This way we have two filesystem layers. This works, but
     * this would mean that you have two jvm instances. That might
     * mean a lot of memory consumption, and with more cascading
     * it might get slower.<br/>
     * Cascade mounting is the same thing as the above example
     * the only difference is that all filesystem lie in same jvm process.
     * It is faster , saves memory, a lot of classes and resources are shared.
     * <br/><br/>
     * It is not compulsary to support this function<br/>
     * <br/>
     * @param <FS> the type of the filesystem
     * @param mountLocation The mountlocation inside the virtual filesystem
     * expressed relative to the root of the virtual filesystem, just
     * as it is done in {@link JPfmBasicFileSystem#open(java.lang.String[]) }
     * @param fsProvider the instanceprovider for the filesystem being
     * mounted.
     */
    /*protected abstract <FS extends JPfmBasicFileSystem>
            void cascadeMount(
                    String[]mountLocation,
                    FileSystemInstanceProvider<FS> fsProvider);*/

    /**
     * A mount can also be initiated from the native side.
     * In such a case the native side needs to know which
     * formatter can be used to manage the volume being mounted.
     *
     *
     * Implementors should also refer the pismo documentation
     * {@link http://www.pismotechnic.com/pfm/doc/#pfmformatter-identify }
     *
     *
     * {@link JPfmBasicFileSystem#canManage(jpfm.AbstractVolume) }
     * is just ceremonial, actually classes implementing
     * JPfmBasicFileSystem will be searched for canManage and create method.
     *
     *
     * @param volumeRawData Buffer containing initial few bytes of data of the file
     * that is being mounted as a volume
     * @param name Name of the file that contains data associated with the volume
     * @param volumeFileChannel The file channel which can be used to read (currently write not supported)
     * the file being mounted
     * @param the path of the file being mounted. This can be used to construct a nio Path
     * @return true is and only if the provided can be managed by an instance of this
     */
    public static boolean canManage(String name, java.nio.ByteBuffer volumeRawData, FileChannel volumeFileChannel) {
        return false;
    }

    public boolean isReadOnly(){
        return true;
    }

    public static JPfmBasicFileSystem create(
            String name,
            java.nio.ByteBuffer volumeRawData,
            FileChannel volumeFileChannel,
            String directory) {
        return null;
    }

    public void printIncompleteOperations() {
        printIncompleteOperations(System.out);
    }
    
    public void printIncompleteOperations(java.io.PrintStream printStream) {
        Iterator<FileSystemOperationImpl> it = incompleteOperations.iterator();
        printStream.println("+++++++++ operations dipatched but not completed yet ++++++++++++");
        while(it.hasNext()){
            FileSystemOperationImpl next = it.next();
            if(next.isCompleted()){
                it.remove();
                continue;
            }
            printStream.println(next);
        }
        printStream.println("-------- operations dipatched but not completed yet -------------");
        it = pendingOperations.iterator();
        printStream.println("+++++++++ operations not dipatched yet ++++++++++++");
        while(it.hasNext()){
            FileSystemOperationImpl next = it.next();
            if(next.isCompleted()){
                it.remove();
                continue;
            }
            printStream.println(next);
        }
        printStream.println("-------- operations not dipatched yet -------------");
    }

    /**
     * Indicates the number of mount location where this filesystem is mounted.
     * Usually it will be one, because implementation of filesystems which
     * can be mounted at more than one mount location is slightly more
     * difficult.
     */
    public final int getMountCount() {
        return mountCount.get();
    }

    public synchronized final boolean addMountStateListener(final FileSystemMountStateListener listener){
        return mountStateListeners.add(listener);
    }

    public synchronized final boolean removeMountStateListener(final FileSystemMountStateListener listener){
        return mountStateListeners.remove(listener);
    }
    
    public final void forceComplete() throws Exception,SecurityException{
        Exception exc = new Exception("FileSystem level force completion initiated");
        synchronized(pendingOperations){
            Iterator<FileSystemOperationImpl> it = incompleteOperations.iterator();
            while(it.hasNext()){
                FileSystemOperationImpl next = it.next();
                it.remove();
                next.handleUnexpectedCompletion(exc);
                pendingOperations.remove(next);
            }
        }
    }

    /**
     * ReadDispatchThread does not operate for JPfmFileSystem, since
     * all filesystem functions are allow NonBlocking implementation.
     */
    private static final class ReadDispatchThread extends Thread {
        private final JPfmBasicFileSystem parent;
        private static final int SLEEP_INTERVAL = 5000;//milliseconds

        public ReadDispatchThread(JPfmBasicFileSystem parent) {
            super("JPfmBasicFormatter_read_dispatcher");
            this.parent = parent;
        }

        @Override
        public void run() {
            INFINITE_LOOP:
            for(;parent.mountCount.get()>0;){
                //Iterator<FileSystemOperationImpl> it = parent.pendingOperations.iterator();
                ReadImpl read;FileSystemOperationImpl next;
                
                try{
                    WHILE_LOOP:
                    while(
                        (next = parent.pendingOperations.poll(
                            SLEEP_INTERVAL,TimeUnit.MILLISECONDS)
                        )!=null ){
                        
                        //next = it.next();
                        if(next instanceof ReadImpl){
                            read = (ReadImpl)next;
                            /*if(read.isCompleted()){
                                //parent.pendingOperations.remove(read);
                                //System.out.println("removing"+read);
                                //>>>>> TODO :
                                //parent.incompleteOperations.remove(next);
                                it.remove(); //request removed on invocation of complete
                                continue WHILE_LOOP;
                            }*/
                            try{
                                parent.read(read);
                                //object has been send once, it can be removed now
                                //we send requests only once.
                                //otherwise in second loop it will come agan, as while we are busy dispatching it
                                //it might get completed. There is no point in sending requests more than once.
                                //However we could have a flag that indicates that the request has been send
                                //Multiple such flags will exists,
                                // example : if throttled file use : one for JPfmBasicFileSystem, one for ThrottledReadlFile
                                //parent.incompleteOperations.add(next); already added
                                //it.remove(); 
                                continue WHILE_LOOP;
                            }catch(Exception any){
                                //it.remove();
                                if(!read.isCompleted())
                                    read.complete(JPfmError.END_OF_DATA, 0,new ForceCompleter());
                                JPfm.getManagerLogger().log(Level.INFO, "Read failed, reporting failure to client application", any);
                                /*if(!read.isSatisfied()){
                                    System.out.println("invoking forceCompleteOnRead");
                                    READ_FORCE_COMPLETER.forceComplete(read);
                                    //read.complete(JPfmError.FAILED, 0);
                                }*/
                            }
                        }else {
                            //cannot happen
                            throw new RuntimeException("JPfmBasicFileSystem ReadDispatch thread handles only Read type of FileSystemOperation.\n" +
                                    " For FileSystemOperation passed="+next);
                        }
                    }
                }catch(InterruptedException ie){
                    
                }

                //<editor-fold defaultstate="collapsed" desc="legacy ConcurrentLinkedQueue waiting code">
                /*try{
                 * synchronized(parent.pendingReqLock){
                 * while(parent.pendingOperations.isEmpty() && parent.mountCount.get()>0   ){
                 * parent.pendingReqLock.wait(SLEEP_INTERVAL);
                 * }
                 * }
                 * }catch(InterruptedException any){
                 * LOGGER.log(Level.WARNING,"Possible implementation error in jpfm",any);
                 * }*/
                //</editor-fold>
            }
        }
    }
    
    static {
        ReadImpl.class.getClass();
    }
    
    private static ReadImpl.IncompleteReqSetter PENDINGREQSETTER;
    
    public final static void setPendingReqSetter(final ReadImpl.IncompleteReqSetter prs){
        if(prs==null)throw new NullPointerException("Attempting to set ReadImpl.PendingReqSetter to null");
        JPfmBasicFileSystem.PENDINGREQSETTER = prs;
    }

    public static final class ForceCompleter implements Completer {
        private final StackTraceElement[] stackTrace;
        private ForceCompleter(){
            stackTrace = new Throwable().getStackTrace();
        }
        public int getBytesFilledTillNow(ReadRequest pendingRequest) {
            return 0;
        }

        public void completeNow(ReadRequest pendingRequest) {
            pendingRequest.complete(JPfmError.FAILED, 0, this);
        }

        public StackTraceElement[] getStackTrace() {
            return stackTrace;
        }

    }

    protected final static class MountStateListener implements MountListener {
        private final JPfmBasicFileSystem parent;
        private MountStateListener(final JPfmBasicFileSystem parent) {
            this.parent = parent;
        }

        public final void eventOccurred(final FormatterEvent event) {
            switch(event.getEventType()){
                case SUCCESSFULLY_MOUNTED: {
                    final int state = parent.mountCount.incrementAndGet();
                    new Thread(FormatterEvent.EVENT.SUCCESSFULLY_MOUNTED.name()){
                        @Override
                        public void run() {
                            final Iterator<FileSystemMountStateListener> it
                                    = parent.mountStateListeners.iterator();
                            
                            if(state==1){
                                // There is a separate Dispatch mechanism for
                                // JPfmFileSystem, it is useless calling
                                // this for it.
                                if(!(parent instanceof JPfmFileSystem)){
                                    parent.readDispatchThread = new ReadDispatchThread(parent);
                                    parent.readDispatchThread.start();
                                }
                                
                                /*parent.completedRequestRemoverThread = new CompletedRequestRemoverThread(parent);
                                parent.completedRequestRemoverThread.start();*/
                            }
                            while(it.hasNext()){
                                if(state==1)
                                    it.next().mounted();
                                else
                                    it.next().remounted();
                            }
                        }
                    }.start();
                    break;
                }
                case DETACHED: {
                    final int state = parent.mountCount.decrementAndGet();
                    if(state==0){
                        new Thread(FormatterEvent.EVENT.DETACHED.name()){
                            @Override
                            public void run() {
                                Iterator<FileSystemMountStateListener> it
                                        = parent.mountStateListeners.iterator();
                                while(it.hasNext()){
                                    it.next().completelyUnmounted();
                                }
                                // notify so that threads do not wait anymore
                                synchronized(parent.incompleteReqLock){
                                    parent.incompleteReqLock.notifyAll();
                                }
                                //<editor-fold defaultstate="collapsed" desc="legacy ConcurrentLinkedQueue waiting code">
                                /*synchronized(parent.pendingReqLock){
                                    parent.pendingReqLock.notifyAll();
                                }*/
                                //</editor-fold>

                                //release all sorts of requests
                                releaseAllResources();
                            }
                        }.start();
                    }
                    break;
                }
                default:
                    //ignore
            }
        }

        private void releaseAllResources(){
            Iterator<FileSystemOperationImpl> it = parent.pendingOperations.iterator();
            FileSystemOperationImpl next;
            while(it.hasNext()){
                next = it.next();
                if(!next.isCompleted()){
                    try{
                        next.handleUnexpectedCompletion(null);
                    }catch(Exception any){
                        LOGGER.log(Level.WARNING,"Implementation error in jpfm",any);
                    }
                }it.remove();
            }
            it = parent.incompleteOperations.iterator();
            while(it.hasNext()){
                next = it.next();
                if(!next.isCompleted()){
                    try{
                        next.handleUnexpectedCompletion(null);
                    }catch(Exception any){
                        LOGGER.log(Level.WARNING,"Implementation error in jpfm",any)  ;
                    }
                }it.remove();
            }
        }

    }
}
