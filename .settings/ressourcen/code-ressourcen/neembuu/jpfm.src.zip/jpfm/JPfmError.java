/*
 * Copyright 2009-2010 Shashank Tulsyan
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File:   JPfmError.java
 * Author: Shashank Tulsyan
 */
package jpfm;

/**
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 * <b>Errors</b><br/>
 * The PFM Protocol and the PfmReadOnlyFormatterOps and
 * PfmFormatterOps interfaces return
 * error codes as defined in pfmenum.h ,
 * such as pfmErrorAccessDenied.
 * The other interfaces return system error codes
 * such as ERROR_ACCESS_DENIED on windows.
 * The protocol is remotable and portable,
 * so the use of system error codes is not appropriate.
 * @see #SUCCESS
 * @see #ACCESS_DENIED
 * @author Admin
 */
//@Deprecated
public enum JPfmError {

    /**
     * All successful filesystem operations should be followed by
     * issuing a call to respective complete function with SUCCESS
     * as a parameter. If this is not done, the filesystem continues
     * waiting for the operation to complete and the client application
     * in the meanwhile could be in a <b>not responding</b> condition.
     * <br/><br/>
     * <u>Note:</u> Passing null in place of appropriate JPfmError to a complete
     * function ( eg : {@link jpfm.operations.Read#complete(jpfm.JPfmError, int)  } )
     * is equivalent to passing {@link JPfmError#FAILED }
     */
    SUCCESS(0),
    /**
     * Causes unmounting if this values is passed, and therefore
     * is not supported any more.
     * Message received on windows :<br/>
     * The pipe has been ended.
     */
    //DISCONNECT(1),
    /**
     * Message received on windows :<br/>
     * The I/O operation has been aborted because of either a thread exit or an application request.
     */
    CANCELLED(2),
    /**
     * Message received on windows :<br/>
     * The request is not supported.
     */
    UNSUPPORTED(3),
    /**
     * Message received on windows :<br/>
     * The parameter is incorrect.<br/>
     */
    INVALID(4),
    /**
     * Most commonly returned
     * Should be returned for all cases
     * which are not supported by this FileSystem
     * Message received on windows :<br/>
     * Access is denied.
     */
    ACCESS_DENIED(5),
    /**
     * Message received on windows :<br/>
     * Not enough storage is available to process this command.
     */
    OUT_OF_MEMORY(6),
    /**
     * Indicates a failure. <br/>
     * Message received on windows :<br/>
     * A device attached to the system is not functioning.<br/>
     * <u>Note:</u> Passing null in place of appropriate JPfmError to a complete
     * function ( eg : {@link jpfm.operations.Read#complete(jpfm.JPfmError, int)  } )
     * is equivalent to passing {@link JPfmError#FAILED }
     */
    FAILED(7),
    /**
     * Message received on windows :<br/>
     * The system cannot find the file specified.
     */
    NOT_FOUND(8),
    /**
     * Message received on windows :<br/>
     * The system cannot find the path specified.
     */
    PARENT_NOT_FOUND(9),
    /**
     * Message received on windows :<br/>
     * Cannot create a file when that file already exists.
     */
    EXISTS(10),
    /**
     * Message received on windows :<br/>
     * There is not enough space on the disk.
     */
    NO_SPACE(11),
    /**
     * Message received on windows :<br/>
     * The filename, directory name, or volume label syntax is incorrect.
     */
    BAD_NAME(12),
    /**
     * Message received on windows :<br/>
     * The directory is not empty.
     */
    NOT_EMPTY(13),
    /**
     * No message is shown.
     */
    END_OF_DATA(14),
    /**
     * Message received on windows (when trying to read) :<br/>
     * Access is denied. <br/>
     */
    NOT_A_FILE(15),
    /**
     * Message received on windows (when trying to read) :<br/>
     * Access is denied. <br/>
     */
    DELETED(16),
    /**
     * Message received on windows (when trying to read) :<br/>
     * The disk structure is corrupted and unreadable.
     */
    CORRUPT_DATA(17);
    private final int errorCode;

    /*package private*/JPfmError(int errorCode) {
        this.errorCode = errorCode;
    }

    public static JPfmError convertErrorCode(int errorCode){
        switch(errorCode){
            case 0 : return SUCCESS;
            //case 1 : return DISCONNECT;
            case 2 : return CANCELLED;
            case 3 : return UNSUPPORTED;
            case 4 : return INVALID;
            case 5 : return ACCESS_DENIED;
            case 6 : return OUT_OF_MEMORY;
            case 7 : return FAILED;
            case 8 : return NOT_FOUND;
            case 9 : return PARENT_NOT_FOUND;
            case 10 : return EXISTS;
            case 11 : return NO_SPACE;
            case 12 : return BAD_NAME;
            case 13 : return NOT_EMPTY;
            case 14 : return END_OF_DATA;
            case 15 : return NOT_A_FILE;
            case 16 : return DELETED;
            case 17 : return CORRUPT_DATA;
        }return null;
    }

    public final int getErrorCode() {
        return errorCode;
    }

    public static JPfmError getJPfmErrorForNothingRead(){
        return JPfmError.CORRUPT_DATA;
    }

    public final Throwable getAsThrowable(){
        return new Throwable(this.toString());
    }

    public static final int INVALID_JPFM_ERROR_CODE = -1;
}
