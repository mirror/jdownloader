/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.fs;

import jpfm.JPfm;
import jpfm.JPfm.Manager;
import java.util.List;
import jpfm.operations.Read;

/**
 *
 * @author Shashank Tulsyan
 */
public final class FSUtils {

    private static UtilityServiceProvider provider;

    private FSUtils() {
    }

    public static void forceCompleteAsynchronous(AsynchronousFileSystem fileSystem) throws Exception{
        check();
        provider.forceCompleteAsynchronous(fileSystem);
    }

    public static void forceCompleteBasic(BasicFileSystem fileSystem) throws Exception{
        check();
        provider.forceCompleteBasic(fileSystem);
    }

    /**
     * The type of the object returned depends on the implementation.
     * This function might be useful for custom service provider implementations.
     * @param manager
     * @return
     */
    public static List getFileSystems(Manager manager){
        check();
        return provider.getFileSystems(manager);
    }

    public static final int getMountCount() {
        check();
        return  provider.getMountCount();
    }

    public static void printIncompleteOperationsAsynchronous(AsynchronousFileSystem fileSystem) {
        check();
        provider.printIncompleteOperationsAsynchronous(fileSystem, System.out);
    }

    public static void printIncompleteOperationsAsynchronous(AsynchronousFileSystem fileSystem,java.io.PrintStream printStream) {
        check();
        provider.printIncompleteOperationsAsynchronous(fileSystem,printStream);
    }

    public static void printIncompleteOperationsBasic(BasicFileSystem fileSystem) {
        check();
        provider.printIncompleteOperationsBasic(fileSystem, System.out);
    }

    public static void printIncompleteOperationsBasic(BasicFileSystem fileSystem,java.io.PrintStream printStream) {
        check();
        provider.printIncompleteOperationsBasic(fileSystem,printStream);
    }

    private static void check(){
        if(provider==null)
            throw new UnsupportedOperationException("So service provider available");
    }

    /**
     * used by spi
     * @param jPfm
     * @param utilityServiceProvider
     */
    public static synchronized void setServiceProvider(
            JPfm jPfm,
            UtilityServiceProvider utilityServiceProvider){
        if(jPfm==null)
            throw new IllegalArgumentException("Only jpfm.JPfm can call this method, or those who have a valid jpfm instance");
        if(!(jPfm instanceof JPfm))
            throw new IllegalArgumentException("Only jpfm.JPfm can call this method, or those who have a valid jpfm instance");
        FSUtils.provider = utilityServiceProvider;
    }
}
