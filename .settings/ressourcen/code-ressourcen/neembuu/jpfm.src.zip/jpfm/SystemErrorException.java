/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm;

/**
 * This is a exception to wrap system error code.
 * It might contains description of the system error as String.
 * In windows the string is generated using FormatMessage function.
 * This exception might reported by native during mounting.
 * @author Shashank Tulsyan
 */
public final class SystemErrorException extends Exception {
    private final long errorCode;
    private final JPfmError jPfmError;

    /*package private*/ SystemErrorException(long errorCode) {
        this.errorCode = errorCode;
        this.jPfmError = null;
    }

    /*package private*/ SystemErrorException(long errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.jPfmError = null;
    }

    /*package private*/ SystemErrorException(long errorCode, int error, String message) {
        super(message);
        this.errorCode = errorCode;
        this.jPfmError = JPfmError.convertErrorCode(error);
    }

    /**
     * The system specific error code value
     * @return error code value
     */
    public final long getSystemErrorCode() {
        return errorCode;
    }

    /**
     * Error as a JPfmError
     * @return
     */
    public final JPfmError getAsJPfmError() {
        return jPfmError;
    }

}
