/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */
package jpfm;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Shashank Tulsyan
 */
public final class MachineUtils {

    public enum MachineType {

        UNKNOWN(null),
        AMD64(new String[]{"x86_64"}),
        X86(new String[]{"i386","i586"} ),
        /**
         * Intel 64 bit. <br/>
         * IA64 cannot run 32-bit programs.
         */
        IA64(null),
        MIPS16(null),
        MIPSFPU(null),
        MIPSFPU16(null),
        POWERPC(new String[]{"ppc"}),
        POWERPC64(new String[]{"ppc64"}),
        POWERPCFP(new String[]{"ppcfp"}),
        /**
         * Example SPARC V8
         */
        SPARC32(null),
        /**
         * Example SPARC V9
         */
        SPARC64(null);

        private final String[]alternateName;

        private MachineType(String[] alternateName) {
            this.alternateName = alternateName;
        }

        private List<String> getAlternateNames(){
            if(alternateName==null)return null;
            return Arrays.asList(alternateName);
        }

        public final boolean equals(String s){
            s = s.trim();
            if(this.name().equalsIgnoreCase(s)){
                return true;
            }
            if(alternateName!=null){
                for (int i = 0; i < alternateName.length; i++) {
                    if(alternateName[i].equalsIgnoreCase(s))
                        return true;
                }
            }
            return false;
        }        
    }

    /**
     * @param mt
     * @return true if and only if the given machine type supports
     * 64-bit instructions and registers.
     */
    public static boolean is64Bit(MachineType mt) {
        switch (mt) {
            case AMD64:
            case IA64:
            case SPARC64:
                return true;
            case X86:
                return false;
            case UNKNOWN:
                throw new IllegalArgumentException("Cannot determine if machine type "+mt + " is 64 bit");
            default:
                return false;
        }
    }


    /**
     * The sub architecture of the system available because of limitations
     * such as in the type of jre being used.</br> <br/>
     * <u>For example,</u> <br/>
     * When running a 32-bit jre on a amd64 architecture.
     * Calling {@link #getRuntimeSystemArchitecture() } would return x86,
     * whereas calling {@link #getRuntimeSystemArchitecture() } would return amd64.
     * But this should be kept in mind, that you cannot use 64-bit instructions
     * or directly (an indirect method for example could be use of named pipes)
     * interact with 64-bit libraries if you are running on 32-bit jdk/jre.
     * @return MachineType corresponding to string returned by
     * System.getProperty("os.arch")
     */
    public static MachineType getRuntimeSystemArchitecture(){
        String architectureString = System.getProperty("os.arch");
        for (MachineType mt : MachineType.values()) {
            if(mt.equals(architectureString))
                return mt;
        }
        return MachineType.UNKNOWN;
    }

    /**
     * The actual architecture of the system, might be different from
     * {@link MachineUtils#getRuntimeSystemArchitecture() }.
     * Currently not supported.
     * @see MachineUtils#getRuntimeSystemArchitecture()
     * @return
     */
    public static MachineType getSystemArchitecture(){
        throw new UnsupportedOperationException("Use getRuntimeSystemArchitecture instead");
    }
}
