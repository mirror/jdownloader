/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations.readwrite;

import java.nio.ByteBuffer;
import jpfm.JPfmError;

/**
 * Used in cascadable split fs.
 * Replaces the fileoffset value of the given read request by the fileoffset
 * passed during contruction.
 * @author Shashank Tulsyan
 */
public final class RequestWrapper implements ReadRequest {
    private final ReadRequest readRequestToWrap;
    private final long fileOffset;
    private final ByteBuffer byteBuffer;

    public RequestWrapper(ReadRequest toWrap, long fileOffset) {
        this.readRequestToWrap = toWrap;
        this.byteBuffer = toWrap.getByteBuffer();
        this.fileOffset = fileOffset;
    }

    public RequestWrapper(ReadRequest toWrap, long fileOffset, ByteBuffer byteBuffer) {
        this.readRequestToWrap = toWrap;
        this.byteBuffer = byteBuffer;
        this.fileOffset = fileOffset;
    }

    public ByteBuffer getByteBuffer() {
        return byteBuffer;
    }

    public long getFileOffset() {
        return fileOffset;
    }

    public void complete(JPfmError error, int actualRead, Completer completer) throws IllegalArgumentException, IllegalStateException {
        readRequestToWrap.complete(error, actualRead, completer);
    }

    public boolean isCompleted() {
        return readRequestToWrap.isCompleted();
    }

    public void handleUnexpectedCompletion(Exception exception) {
        readRequestToWrap.handleUnexpectedCompletion(exception);
    }

    public long getCreationTime() {
        return readRequestToWrap.getCreationTime();
    }

    public long getCompletionTime() {
        return readRequestToWrap.getCompletionTime();
    }

    public JPfmError getError() {
        return readRequestToWrap.getError();
    }

    public void setCompleter(Completer completehandler) {
        readRequestToWrap.setCompleter(completehandler);
    }

    public boolean canComplete(Completer completehandler) {
        return readRequestToWrap.canComplete(completehandler);
    }

    public void complete(JPfmError error) throws IllegalArgumentException, IllegalStateException {
        complete(error,readRequestToWrap.getByteBuffer().capacity(),null);
    }

    @Override
    public String toString() {
        return "{RequestWrapper off="+fileOffset
                + ", capa="+byteBuffer.capacity()
                + "}";
    }
}
