/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

/**
 *
 * @author Shashank Tulsyan
 */
public interface FileSystemOperation {

    /**
     * Can be used to get the time when this request was made.
     * This time is actually slightly greater than the actual time
     * when the client application made the request, because
     * this request travels through a few functions before
     * jpfm is aware of this.
     * JPfm does not attempt to predict the exact time of request creation.
     * The value of System.currentTimeMillis() during creation of this
     * filesystem operation is returned by this method.
     * @return the difference, measured in milliseconds, between
     * the time when this request was made
     * and midnight, January 1, 1970 UTC.
     */
    long getCreationTime();

    /**
     * The filesystem browser might be waiting during a filesystem operations.
     * If the request was not completed due to a exception, this function is invoked,
     * to free all resources and free this filesystem operation request.
     * @param exception
     */
    void handleUnexpectedCompletion(final Exception exception);

    /**
     * @return false if complete method cannot be invoked anymore since it has been
     * already invoked, true otherwise
     */
    boolean isCompleted();

}
