/*
 *  Copyright 2010 Shashank Tulsyan.
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */

package jpfm.operations;

import jpfm.FileDescriptor;
import jpfm.FileId;
import jpfm.JPfmMount;
import jpfm.JPfmMount.FormatterDispatchHandleGetter;
import net.jcip.annotations.ThreadSafe;

/**
 * Represents an abstract non-blocking atomic file system operation .
 * In fuse and pfm operations are presented by strucutes ending with suffix Ops,
 * like ReadOps . The JPfm equivalent of which is {@link jpfm.operations.Read }
 * <u>Note </u> : ANY PFM OpenID (or FileId) field or method is equivalently represented
 * in JPfm by a field or method with return type FileDescriptor<br/>
 * A example can be found in javadoc of {@link Replace }
 * <br/>
 * All FileSystemOperations are thread safe. Thread safety is ensured by use of atomic checks.
 * The only exception is that ByteBuffer obtained from getByteBuffer in Read and Write
 * should be handled by one thread only. If it is to be handled by more than one thread
 * it should be broken into smaller instances of ByteBuffer. See {@link Read#getByteBuffer() }
 * for more information.
 * <br/>
 * <br/><br/><br/><br/>
 * <b><u>Additional reference from PFM docs</u></b><br/><br/>
 * <i>Please note : Native implementation is different from java implementation. The description
 * below must be used only in absence of javadoc, or for reference sake only.</i><br/><br/>
 * You can also read the latest version of this at {@link http://www.pismotechnic.com/pfm/doc/ }
 * <br/><br/>
 *
 * @author Shashank Tulsyan
 */
@ThreadSafe
public abstract class FileSystemOperationImpl implements FileSystemOperation {
    private static JPfmMount.FormatterDispatchHandleGetter handleGetter = null;
    static FileDescriptor.FDModifier FD_MODIFIER = null;
    static FileId.Builder FILEID_BUILDER = null; // assumING that filesystem classes implemented
    // aren't stupid enough to change the value of these package private fields.

    private final long creationTime; //8
    //total size = perfect 16

    public static void setHandleGetter(FormatterDispatchHandleGetter handleGetter) {
        if(handleGetter == null) throw new NullPointerException("FormatterDispatchHandleGetter passed was null");
        FileSystemOperationImpl.handleGetter = handleGetter;
    }

    public final static void setFDModifier(final FileDescriptor.FDModifier fdm){
        if(fdm==null)throw new NullPointerException("Attempting to set FileDescriptor modifier to null");
        FileSystemOperationImpl.FD_MODIFIER = fdm;
    }

    public final static void setFileIdBuilder(final FileId.Builder fileIdBuilder_){
        if(fileIdBuilder_==null)throw new NullPointerException("Attempting to set FileDescriptor modifier to null");
        FileSystemOperationImpl.FILEID_BUILDER = fileIdBuilder_;
    }

    /*package private*/ FileSystemOperationImpl() {
        creationTime = System.currentTimeMillis();
    }

    /**
     * Can be used to get the time when this request was made.
     * This time is actually slightly greater than the actual time
     * when the client application made the request, because
     * this request travels through a few functions before
     * jpfm is aware of this.
     * JPfm does not attempt to predict the exact time of request creation.
     * The value of System.currentTimeMillis() during creation of this 
     * filesystem operation is returned by this method.
     * @return the difference, measured in milliseconds, between
     *          the time when this request was made
     *          and midnight, January 1, 1970 UTC.
     */
    public final long getCreationTime() {
        return creationTime;
    }

    protected abstract long getFormatterDispatchHandle();

    /**
     * The typical usage of this would if a filesystem is mounted at
     * more than one place, and wants to deal differently with
     * mounts at different location.
     * Such a formatter would be required to have a copy of it's mounts ( {@link jpfm.JPfmMount} that is ).
     * How it does it is upto the implementor to decide.
     * Mouting same filesystem at different location will also demand
     * that all filesytem code is both NonBlocking and thread safe at the
     * same time, because filesystem calls will be made from more than one
     * native thread in such a case. This is troublesome and makes the implementations complex.
     * So the implementor is advised not to do so.
     * @see JPfmMount
     * @param mount
     * @return true if this operation was generated from the volume represented by the given mount object.
     */
    public final boolean isOriginatedFrom(final Object mount){
        if(!(mount instanceof  JPfmMount) ){
            throw new UnsupportedOperationException();
        }

        if(handleGetter == null) throw new NullPointerException("JPfmMount.FormatterDispatchHandleGetter was not initialized");
        if( handleGetter.getHandle((JPfmMount)mount) == getFormatterDispatchHandle())
            return true;
        return false;
    }


}
