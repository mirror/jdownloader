/*
 *  Copyright (C) 2010 Shashank Tulsyan
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package neembuu.util;

/**
 *
 * @author Shashank Tulsyan
 */
public final class Constants {
    /**
     * The reason why we often make the constructor private is
     * so that an instance cannot be created.
     * We don 't want the user to create an instace due to
     * #1) a new instance wil unnecessarily consume memory
     * #2) security reasons
     * Here the reason is #1)
     *
     * For {@link jpfm.operations.Read } the reason is #2) that is to say,
     * the user might give any random values for handles.
     * If he does that then the program will surely crash.
     * Because the handle will be passed to native side,
     * and it will be used as a pointer. We can easily appreciate that
     * pointer cannot be a random value. For example if you do this
     * void * someVariable =  0;
     * delete someVariable; your program will surely crash.
     */
    private Constants(){

    }

    public static final int KB = 1024;
    public static final int MB = 1024*1024;
    public static final int GB = 1024*1024*1024;
}
