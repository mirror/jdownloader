/*
 *  Copyright (C) 2009-2010 Shashank Tulsyan
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 *
 *  Linking this library statically or
 *  dynamically with other modules is making a combined work based on this library.
 *  Thus, the terms and conditions of the GNU General Public License cover the whole combination.
 *
 *
 *  As a special exception, the copyright holders of this library give you permission to
 *  link this library with independent modules to produce an executable, regardless of
 *  the license terms of these independent modules, and to copy and
 *  distribute the resulting executable under terms of your choice,
 *  provided that you also meet, for each linked independent module,
 *  the terms and conditions of the license of that module.
 *  An independent module is a module which is not derived from or based on this library.
 *  If you modify this library, you may extend this exception to your version of the library,
 *  but you are not obligated to do so. If you do not wish to do so,
 *  delete this exception statement from your version.
 */

package neembuu.util;

/**
 *
 * @author Shashank Tulsyan
 */
public class TimeInterval {
    private int days,hours,minutes;
    public static final TimeInterval INFINITE=intializeInfiteTimeInterval();
    public static final TimeInterval NO_SUCH_TIME_INTERVAL_EXISTS=intializeNoSuchTimeIntervalExists();
    public static final TimeInterval ZERO_TIME_INTERVAL=intializeZeroTimeInterval();
    public TimeInterval(long minutes)throws IncorrectTimeIntervalException{
        setTimeInterval(minutes);
    }
    public TimeInterval(long hours, int minutes)throws IncorrectTimeIntervalException{
        this(
                (int)hours/24,
                (int)hours%24,
                minutes
        );
    }
    public TimeInterval(int days,int hours,int minutes)throws IncorrectTimeIntervalException{
        setDays(days);
        setHours(hours);
        setMinutes(minutes);
    }
    protected TimeInterval(){

    }
    public int[]getTimeInterval(){
        return new int[]{days,hours,minutes};
    }
    public double getIntervalInDays(){
        return days+hours/24+minutes/(24*60);
    }
    public double getIntervalInHours(){
        return days*24+hours+minutes/60;
    }
    public long getIntervalInMinutes(){
        return days*24*60+hours*60+minutes;
    }

    public int getDays(){
        return days;
    }
    public int getHours() {
        return hours;
    }
    public int getMinutes() {
        return minutes;
    }

    public void setDays(int days)throws IncorrectTimeIntervalException {
        if(days<0)throw IncorrectTimeIntervalException.ANY_TIME_INTERVAL_PARAMETER_CANNOT_BE_NEGATIVE;
        this.days = days;
    }
    public void setHours(int hours)throws IncorrectTimeIntervalException {
        if(hours<0)throw IncorrectTimeIntervalException.ANY_TIME_INTERVAL_PARAMETER_CANNOT_BE_NEGATIVE;
        if(hours>23)throw IncorrectTimeIntervalException.HOURS_CANNOT_BE_GREATER_THAN_23;
        this.hours = hours;
    }
    public void setMinutes(int minutes)throws IncorrectTimeIntervalException{
        if(minutes<0)throw IncorrectTimeIntervalException.ANY_TIME_INTERVAL_PARAMETER_CANNOT_BE_NEGATIVE;
        if(minutes>59)throw IncorrectTimeIntervalException.MINUTES_CANNOT_BE_GREATER_THAN_59;
        this.minutes = minutes;
    }

    public void setTimeInterval(long minutes)throws IncorrectTimeIntervalException{
        setDays((int)minutes/(60*24));
        setHours((int)(minutes/60)%24);
        setMinutes((int)minutes%60);
    }
    public synchronized void addMinutes(int minutes)throws IncorrectTimeIntervalException{
        long total_minutes=getIntervalInMinutes();
        total_minutes+=minutes;
        if(total_minutes<0)throw new IncorrectTimeIntervalException("Total time has become negative.");
        setTimeInterval(total_minutes);
    }
    public synchronized void addHours(double hours)throws IncorrectTimeIntervalException{
        long total_minutes=getIntervalInMinutes();
        total_minutes+=hours*60;
        if(total_minutes<0)throw new IncorrectTimeIntervalException("Total time has become negative.");
        setTimeInterval(total_minutes);
    }
    public synchronized void addDays(int days)throws IncorrectTimeIntervalException{
        if(days+this.days<0)throw IncorrectTimeIntervalException.ANY_TIME_INTERVAL_PARAMETER_CANNOT_BE_NEGATIVE;
        this.days+=days;
    }

    private static TimeInterval intializeInfiteTimeInterval(){
        try{
            return new TimeInterval(Long.MAX_VALUE);
        }catch(IncorrectTimeIntervalException a){
            return null;
        }
    }
    private static TimeInterval intializeNoSuchTimeIntervalExists(){
        TimeInterval _NO_SUCH_TIME_INTERVAL_EXISTS;
        _NO_SUCH_TIME_INTERVAL_EXISTS=new TimeInterval();
        _NO_SUCH_TIME_INTERVAL_EXISTS.minutes=Integer.MIN_VALUE;
        _NO_SUCH_TIME_INTERVAL_EXISTS.hours=Integer.MIN_VALUE;
        _NO_SUCH_TIME_INTERVAL_EXISTS.days=Integer.MIN_VALUE;
        return _NO_SUCH_TIME_INTERVAL_EXISTS;
    }
    private static TimeInterval intializeZeroTimeInterval(){
        TimeInterval zero = new TimeInterval();
        zero.minutes=0;
        zero.hours=0;
        zero.days=0;
        return zero;
    }
}