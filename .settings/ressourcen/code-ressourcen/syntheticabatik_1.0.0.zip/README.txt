The syntheticaBatik library contains some Apache Batik 
(http://xmlgraphics.apache.org/batik/) based classes which
are needed by Java2D based Synthetica themes on Java 1.5. 
The syntheticaBatik library is not needed if Java 6 (or above) 
is used or if the theme is image based only. 

Please take a look a the themes web page at
http://www.javasoft.de/jsf/public/products/synthetica/themes 
to find out which themes require the syntheticaBatik.jar library. 
