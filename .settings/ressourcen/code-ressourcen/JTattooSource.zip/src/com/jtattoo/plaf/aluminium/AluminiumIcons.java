/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */
package com.jtattoo.plaf.aluminium;

import java.io.Serializable;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.plaf.UIResource;

import com.jtattoo.plaf.*;

/**
 * @author Michael Hagen
 */
public class AluminiumIcons extends BaseIcons {

    private static final Color foreColor = new Color(32, 32, 32);
    private static final Color shadowColor = new Color(232, 232, 232);
    private static final Color rolloverColor = new Color(196, 0, 0);//new Color(196, 203, 163);
    private static Icon iconIcon = null;
    private static Icon maxIcon = null;
    private static Icon minIcon = null;
    private static Icon closeIcon = null;
    private static Icon radioButtonIcon = null;
    private static Icon checkBoxIcon = null;
    private static Icon thumbHorIcon = null;
    private static Icon thumbHorIconRollover = null;
    private static Icon thumbVerIcon = null;
    private static Icon thumbVerIconRollover = null;

    public static Icon getIconIcon() {
        if (iconIcon == null) {
            iconIcon = new BaseIcons.IconSymbol(foreColor, shadowColor, rolloverColor, new Insets(0, 0, 1, 0));
        }
        return iconIcon;
    }

    public static Icon getMinIcon() {
        if (minIcon == null) {
            minIcon = new BaseIcons.MinSymbol(foreColor, shadowColor, rolloverColor, new Insets(0, 0, 1, 0));
        }
        return minIcon;
    }

    public static Icon getMaxIcon() {
        if (maxIcon == null) {
            maxIcon = new BaseIcons.MaxSymbol(foreColor, shadowColor, rolloverColor, new Insets(0, 0, 1, 0));
        }
        return maxIcon;
    }

    public static Icon getCloseIcon() {
        if (closeIcon == null) {
            closeIcon = new BaseIcons.CloseSymbol(foreColor, shadowColor, rolloverColor, new Insets(0, 0, 1, 0));
        }
        return closeIcon;
    }

    public static Icon getRadioButtonIcon() {
        if (radioButtonIcon == null) {
            radioButtonIcon = new RadioButtonIcon();
        }
        return radioButtonIcon;
    }

    public static Icon getCheckBoxIcon() {
        if (checkBoxIcon == null) {
            checkBoxIcon = new CheckBoxIcon();
        }
        return checkBoxIcon;
    }

    public static Icon getThumbHorIcon() {
        if (thumbHorIcon == null) {
            thumbHorIcon = new LazyImageIcon("aluminium/icons/thumb_hor.gif");
        }
        return thumbHorIcon;
    }

    public static Icon getThumbHorIconRollover() {
        if (thumbHorIconRollover == null) {
            thumbHorIconRollover = new LazyImageIcon("aluminium/icons/thumb_hor_rollover.gif");
        }
        return thumbHorIconRollover;
    }

    public static Icon getThumbVerIcon() {
        if (thumbVerIcon == null) {
            thumbVerIcon = new LazyImageIcon("aluminium/icons/thumb_ver.gif");
        }
        return thumbVerIcon;
    }

    public static Icon getThumbVerIconRollover() {
        if (thumbVerIconRollover == null) {
            thumbVerIconRollover = new LazyImageIcon("aluminium/icons/thumb_ver_rollover.gif");
        }
        return thumbVerIconRollover;
    }

    //--------------------------------------------------------------------------------------------------------
    private static class CheckBoxIcon implements Icon, UIResource, Serializable {

        private static Icon checkIcon = new LazyImageIcon("icons/CheckSymbol.gif");
        private static Icon checkPressedIcon = new LazyImageIcon("icons/CheckPressedSymbol.gif");
        
        private final static int WIDTH = 15;
        private final static int HEIGHT = 15;

        public void paintIcon(Component c, Graphics g, int x, int y) {
            if (!JTattooUtilities.isLeftToRight(c)) {
                x += 3;
            }
            JCheckBox cb = (JCheckBox) c;
            ButtonModel model = cb.getModel();
            Color colors[] = null;
            if (cb.isEnabled()) {
                if (cb.isRolloverEnabled() && model.isRollover() && !model.isArmed()) {
                    colors = AluminiumLookAndFeel.getTheme().getRolloverColors();
                } else if (JTattooUtilities.isFrameActive(cb)) {
                    if (model.isArmed() && model.isPressed()) {
                        colors = new Color[]{AluminiumLookAndFeel.getBackgroundColor()};
                    } else {
                        colors = AluminiumLookAndFeel.getTheme().getButtonColors();
                    }
                } else {
                    colors = AluminiumLookAndFeel.getTheme().getInActiveColors();
                }
            } else {
                colors = AluminiumLookAndFeel.getTheme().getDisabledColors();
            }
            JTattooUtilities.fillHorGradient(g, colors, x, y, WIDTH, HEIGHT);
            if (cb.isEnabled()) {
                g.setColor(AluminiumLookAndFeel.getFrameColor());
            } else {
                g.setColor(ColorHelper.brighter(AluminiumLookAndFeel.getFrameColor(), 20));
            }
            g.drawRect(x, y, WIDTH, HEIGHT);

            Graphics2D g2D = (Graphics2D) g;
            Composite composite = g2D.getComposite();
            AlphaComposite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.6f);
            g2D.setComposite(alpha);
            g2D.setColor(Color.white);
            g2D.drawRect(x + 1, y + 1, WIDTH - 2, HEIGHT - 2);
            g2D.setComposite(composite);

            int xi = x + ((WIDTH - checkIcon.getIconWidth()) / 2) + 1;
            int yi = y + ((HEIGHT - checkIcon.getIconHeight()) / 2) + 1;
            if (model.isPressed() && model.isArmed()) {
                checkPressedIcon.paintIcon(c, g, xi, yi);
            } else if (model.isSelected()) {
                checkIcon.paintIcon(c, g, xi, yi);
            }
        }

        public int getIconWidth() {
            return WIDTH + 4;
        }

        public int getIconHeight() {
            return HEIGHT;
        }
    }

    private static class RadioButtonIcon implements Icon, UIResource, Serializable {

        private static Icon radioIcon = new LazyImageIcon("icons/RadioSymbol.gif");
        private final static int WIDTH = 14;
        private final static int HEIGHT = 14;

        public void paintIcon(Component c, Graphics g, int x, int y) {
            if (!JTattooUtilities.isLeftToRight(c)) {
                x += 3;
            }
            Graphics2D g2D = (Graphics2D) g;
            JRadioButton cb = (JRadioButton) c;
            ButtonModel model = cb.getModel();
            Color colors[] = null;
            if (cb.isEnabled()) {
                if (cb.isRolloverEnabled() && model.isRollover()) {
                    colors = AluminiumLookAndFeel.getTheme().getRolloverColors();
                } else {
                    colors = AluminiumLookAndFeel.getTheme().getButtonColors();
                }
            } else {
                colors = AluminiumLookAndFeel.getTheme().getDisabledColors();
            }

            Shape savedClip = g.getClip();
            Area clipArea = new Area(savedClip);
            Area ellipseArea = new Area(new Ellipse2D.Double(x, y, WIDTH + 1, HEIGHT + 1));
            ellipseArea.intersect(clipArea);
            g2D.setClip(ellipseArea);
            JTattooUtilities.fillHorGradient(g, colors, x, y, WIDTH, HEIGHT);
            g2D.setClip(savedClip);

            if (cb.isEnabled()) {
                g2D.setColor(AluminiumLookAndFeel.getFrameColor());
            } else {
                g2D.setColor(ColorHelper.brighter(AluminiumLookAndFeel.getFrameColor(), 20));
            }
            Object savedRenderingHint = g2D.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
            g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2D.drawOval(x, y, WIDTH, HEIGHT);

            Composite composite = g2D.getComposite();
            AlphaComposite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.6f);
            g2D.setComposite(alpha);
            g2D.setColor(Color.white);
            g2D.drawOval(x + 1, y + 1, WIDTH - 2, HEIGHT - 2);
            g2D.setComposite(composite);

            g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, savedRenderingHint);

            if (model.isSelected()) {
                int xi = x + ((WIDTH - radioIcon.getIconWidth()) / 2) + 1;
                int yi = y + ((HEIGHT - radioIcon.getIconHeight()) / 2) + 1;
                radioIcon.paintIcon(c, g, xi, yi);
            }
        }

        public int getIconWidth() {
            return WIDTH + 4;
        }

        public int getIconHeight() {
            return HEIGHT;
        }
    }
}
