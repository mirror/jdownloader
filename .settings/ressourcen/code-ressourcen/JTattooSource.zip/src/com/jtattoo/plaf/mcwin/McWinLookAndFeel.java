/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */
package com.jtattoo.plaf.mcwin;

import java.util.*;
import javax.swing.*;
import com.jtattoo.plaf.*;

/**
 * @author Michael Hagen
 */
public class McWinLookAndFeel extends AbstractLookAndFeel {

    private static McWinDefaultTheme myTheme = null;
    private static ArrayList themesList = new ArrayList();
    private static HashMap themesMap = new HashMap();
    private static Properties defaultProps = new Properties();
    private static Properties smallFontProps = new Properties();
    private static Properties largeFontProps = new Properties();
    private static Properties giantFontProps = new Properties();
    private static Properties pinkProps = new Properties();
    private static Properties pinkSmallFontProps = new Properties();
    private static Properties pinkLargeFontProps = new Properties();
    private static Properties pinkGiantFontProps = new Properties();


    static {
        smallFontProps.setProperty("controlTextFont", "Dialog 10");
        smallFontProps.setProperty("systemTextFont", "Dialog 10");
        smallFontProps.setProperty("userTextFont", "Dialog 10");
        smallFontProps.setProperty("menuTextFont", "Dialog 10");
        smallFontProps.setProperty("windowTitleFont", "Dialog bold 10");
        smallFontProps.setProperty("subTextFont", "Dialog 8");

        largeFontProps.setProperty("controlTextFont", "Dialog 14");
        largeFontProps.setProperty("systemTextFont", "Dialog 14");
        largeFontProps.setProperty("userTextFont", "Dialog 14");
        largeFontProps.setProperty("menuTextFont", "Dialog 14");
        largeFontProps.setProperty("windowTitleFont", "Dialog bold 14");
        largeFontProps.setProperty("subTextFont", "Dialog 12");

        giantFontProps.setProperty("controlTextFont", "Dialog 18");
        giantFontProps.setProperty("systemTextFont", "Dialog 18");
        giantFontProps.setProperty("userTextFont", "Dialog 18");
        giantFontProps.setProperty("menuTextFont", "Dialog 18");
        giantFontProps.setProperty("windowTitleFont", "Dialog 18");
        giantFontProps.setProperty("subTextFont", "Dialog 16");

        pinkProps.setProperty("backgroundColorLight", "248 244 248");
        pinkProps.setProperty("backgroundColorDark", "255 255 255");
        pinkProps.setProperty("focusCellColor", "160 120 160");
        pinkProps.setProperty("selectionBackgroundColor", "248 202 248");
        pinkProps.setProperty("controlColorLight", "255 220 255");
        pinkProps.setProperty("controlColorDark", "248 140 248");
        pinkProps.setProperty("rolloverColorLight", "240 180 240");
        pinkProps.setProperty("rolloverColorDark", "232 120 232");
        pinkProps.setProperty("windowTitleForegroundColor", "0 0 0");
        pinkProps.setProperty("windowTitleBackgroundColor", "248 180 248");
        pinkProps.setProperty("windowTitleColorLight", "248 180 248");
        pinkProps.setProperty("windowTitleColorDark", "200 120 200");
        pinkProps.setProperty("windowBorderColor", "200 120 200");
        pinkProps.setProperty("menuSelectionForegroundColor", "0 0 0");
        pinkProps.setProperty("menuSelectionBackgroundColor", "248 202 248");
        pinkProps.setProperty("desktopColor", "255 255 255");

        String key = null;
        String value = null;
        Iterator iter = smallFontProps.keySet().iterator();
        while (iter.hasNext()) {
            key = (String) iter.next();
            value = smallFontProps.getProperty(key);
            pinkSmallFontProps.setProperty(key, value);
        }
        iter = largeFontProps.keySet().iterator();
        while (iter.hasNext()) {
            key = (String) iter.next();
            value = largeFontProps.getProperty(key);
            pinkLargeFontProps.setProperty(key, value);
        }
        iter = giantFontProps.keySet().iterator();
        while (iter.hasNext()) {
            key = (String) iter.next();
            value = giantFontProps.getProperty(key);
            pinkGiantFontProps.setProperty(key, value);
        }

        iter = pinkProps.keySet().iterator();
        while (iter.hasNext()) {
            key = (String) iter.next();
            value = pinkProps.getProperty(key);
            pinkSmallFontProps.setProperty(key, value);
            pinkLargeFontProps.setProperty(key, value);
            pinkGiantFontProps.setProperty(key, value);
        }


        themesList.add("Default");
        themesList.add("Small-Font");
        themesList.add("Large-Font");
        themesList.add("Giant-Font");

        themesList.add("Pink");
        themesList.add("Pink-Small-Font");
        themesList.add("Pink-Large-Font");
        themesList.add("Pink-Giant-Font");

        themesMap.put("Default", defaultProps);
        themesMap.put("Small-Font", smallFontProps);
        themesMap.put("Large-Font", largeFontProps);
        themesMap.put("Giant-Font", giantFontProps);

        themesMap.put("Pink", pinkProps);
        themesMap.put("Pink-Small-Font", pinkSmallFontProps);
        themesMap.put("Pink-Large-Font", pinkLargeFontProps);
        themesMap.put("Pink-Giant-Font", pinkGiantFontProps);
    }

    public static java.util.List getThemes() {
        return themesList;
    }

    public static Properties getThemeProperties(String name) {
        return ((Properties) themesMap.get(name));
    }

    public static void setTheme(String name) {
        if (myTheme != null) {
            myTheme.setInternalName(name);
        }
        setTheme((Properties) themesMap.get(name));
    }

    public static void setTheme(String name, String licenseKey, String logoString) {
        Properties props = (Properties) themesMap.get(name);
        props.put("licenseKey", licenseKey);
        props.put("logoString", logoString);
        if (myTheme != null) {
            myTheme.setInternalName(name);
        }
        setTheme(props);
    }

    public static void setTheme(Properties themesProps) {
        if (myTheme == null) {
            myTheme = new McWinDefaultTheme();
        }
        if ((myTheme != null) && (themesProps != null)) {
            myTheme.setUp();
            myTheme.setProperties(themesProps);
            myTheme.setupColorArrs();
            AbstractLookAndFeel.setTheme(myTheme);
        }
    }

    public static void setCurrentTheme(Properties themesProps) {
        setTheme(themesProps);
    }

    public String getName() {
        return "McWin";
    }

    public String getID() {
        return "McWin";
    }

    public String getDescription() {
        return "The McWin Look and Feel";
    }

    public boolean isNativeLookAndFeel() {
        return false;
    }

    public boolean isSupportedLookAndFeel() {
        return true;
    }

    public AbstractBorderFactory getBorderFactory() {
        return McWinBorderFactory.getInstance();
    }

    public AbstractIconFactory getIconFactory() {
        return McWinIconFactory.getInstance();
    }

    protected void createDefaultTheme() {
        if (myTheme == null) {
            myTheme = new McWinDefaultTheme();
        }
        setTheme(myTheme);
    }

    protected void initClassDefaults(UIDefaults table) {
        super.initClassDefaults(table);
        Object[] uiDefaults = {
            // BaseLookAndFeel classes
            "LabelUI", BaseLabelUI.class.getName(),
            "SeparatorUI", BaseSeparatorUI.class.getName(),
            "TextFieldUI", BaseTextFieldUI.class.getName(),
            "TextAreaUI", BaseTextAreaUI.class.getName(),
            "EditorPaneUI", BaseEditorPaneUI.class.getName(),
            "ToolTipUI", BaseToolTipUI.class.getName(),
            "TreeUI", BaseTreeUI.class.getName(),
            "TableUI", BaseTableUI.class.getName(),
            "TableHeaderUI", BaseTableHeaderUI.class.getName(),
            "ScrollBarUI", BaseScrollBarUI.class.getName(),
            "ProgressBarUI", BaseProgressBarUI.class.getName(),
            "FileChooserUI", BaseFileChooserUI.class.getName(),
            "MenuUI", BaseMenuUI.class.getName(),
            "PopupMenuUI", BasePopupMenuUI.class.getName(),
            "MenuItemUI", BaseMenuItemUI.class.getName(),
            "CheckBoxMenuItemUI", BaseCheckBoxMenuItemUI.class.getName(),
            "RadioButtonMenuItemUI", BaseRadioButtonMenuItemUI.class.getName(),
            "PopupMenuSeparatorUI", BaseSeparatorUI.class.getName(),
            // McWinLookAndFeel classes
            "CheckBoxUI", McWinCheckBoxUI.class.getName(),
            "RadioButtonUI", McWinRadioButtonUI.class.getName(),
            "ButtonUI", McWinButtonUI.class.getName(),
            "ToggleButtonUI", McWinToggleButtonUI.class.getName(),
            "ComboBoxUI", McWinComboBoxUI.class.getName(),
            "SliderUI", McWinSliderUI.class.getName(),
            "PanelUI", McWinPanelUI.class.getName(),
            "ScrollPaneUI", McWinScrollPaneUI.class.getName(),
            "TabbedPaneUI", McWinTabbedPaneUI.class.getName(),
            "ToolBarUI", McWinToolBarUI.class.getName(),
            "MenuBarUI", McWinMenuBarUI.class.getName(),
            "SplitPaneUI", McWinSplitPaneUI.class.getName(),
            "InternalFrameUI", McWinInternalFrameUI.class.getName(),
            "RootPaneUI", McWinRootPaneUI.class.getName(),};
        table.putDefaults(uiDefaults);
        if (JTattooUtilities.getJavaVersion() >= 1.5) {
            table.put("SpinnerUI", BaseSpinnerUI.class.getName());
        }
    }
}
