/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */
package com.jtattoo.plaf.smart;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;

import com.jtattoo.plaf.*;

/**
 * author Michael Hagen
 */
public class SmartTabbedPaneUI extends BaseTabbedPaneUI {

    private static final Color SELECTED_TAB_COLORS[] = {AbstractLookAndFeel.getBackgroundColor()};

    public static ComponentUI createUI(JComponent c) {
        return new SmartTabbedPaneUI();
    }

    public void installDefaults() {
        super.installDefaults();
        tabAreaInsets = new Insets(2, 6, 2, 6);
        contentBorderInsets = new Insets(2, 2, 2, 2);
        tabPane.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    }

    protected Font getTabFont(boolean isSelected) {
        if (isSelected) {
            return super.getTabFont(isSelected).deriveFont(Font.BOLD);
        } else {
            return super.getTabFont(isSelected);
        }
    }

    protected Color[] getTabColors(int tabIndex, boolean isSelected) {
        if (isSelected) {
            return SELECTED_TAB_COLORS;
        } else {
            return super.getTabColors(tabIndex, isSelected);
        }
    }

    protected Color getGapColor(int tabIndex) {
        if (tabIndex == tabPane.getSelectedIndex()) {
            return AbstractLookAndFeel.getBackgroundColor();
        }
        return super.getGapColor(tabIndex);
    }

    protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
        if (isSelected) {
            if (tabPane.getBackgroundAt(tabIndex) instanceof UIResource) {
                g.setColor(AbstractLookAndFeel.getBackgroundColor());
            } else {
                g.setColor(tabPane.getBackgroundAt(tabIndex));
            }
            if (tabPlacement == TOP) {
                g.fillRect(x + 1, y + 1, w - 1, h + 1);
            } else if (tabPlacement == LEFT) {
                g.fillRect(x + 1, y + 1, w + 1, h - 1);
            } else if (tabPlacement == BOTTOM) {
                g.fillRect(x + 1, y - 1, w - 1, h + 1);
            } else {
                g.fillRect(x - 1, y + 1, w + 1, h - 1);
            }
        } else {
            super.paintTabBackground(g, tabPlacement, tabIndex, x, y, w, h, isSelected);
            switch (tabPlacement) {
                case TOP: {
                    if (tabIndex == rolloverIndex) {
                        g.setColor(AbstractLookAndFeel.getFocusColor());
                        g.fillRect(x + 2, y + 1, w - 3, 2);
                    }
                    break;
                }
                case LEFT: {
                    if (tabIndex == rolloverIndex) {
                        g.setColor(AbstractLookAndFeel.getFocusColor());
                        g.fillRect(x, y + 2, w - 1, 2);
                    }
                    break;
                }
                case RIGHT: {
                    if (tabIndex == rolloverIndex) {
                        g.setColor(AbstractLookAndFeel.getFocusColor());
                        g.fillRect(x, y + 2, w - 1, 2);
                    }
                    break;
                }
                case BOTTOM: {
                    if (tabIndex == rolloverIndex) {
                        g.setColor(AbstractLookAndFeel.getFocusColor());
                        g.fillRect(x + 2, y + h - 3, w - 3, 2);
                    }
                    break;
                }
            }
        }
    }

    protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        Color loColor = AbstractLookAndFeel.getControlDarkShadow();
        Color hiColor = AbstractLookAndFeel.getControlHighlight();
        g.setColor(loColor);
        switch (tabPlacement) {
            case TOP: {
                int tabAreaHeight = calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                g.drawRect(x, y + tabAreaHeight - 1, x + w - 1, h - tabAreaHeight);
                g.setColor(hiColor);
                g.drawLine(x + 1, y + tabAreaHeight, w - 2, y + tabAreaHeight);
                g.drawLine(x + 1, y + tabAreaHeight, x + 1, h - 2);
                break;
            }
            case LEFT: {
                int tabAreaWidth = calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                g.drawRect(x + tabAreaWidth - 1, y, w - tabAreaWidth, y + h - 1);
                g.setColor(hiColor);
                g.drawLine(x + tabAreaWidth, y + 1, x + tabAreaWidth, h - 2);
                g.drawLine(x + tabAreaWidth, y + 1, w - 2, y + 1);
                break;
            }
            case BOTTOM: {
                int tabAreaHeight = calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                g.drawRect(x, y, x + w - 1, h - tabAreaHeight);
                g.setColor(hiColor);
                g.drawLine(x + 1, y + 1, w - 2, y + 1);
                g.drawLine(x + 1, y + 1, x + 1, h - tabAreaHeight - 1);
                break;
            }
            case RIGHT: {
                int tabAreaWidth = calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                g.drawRect(x, y, w - tabAreaWidth, y + h - 1);
                g.setColor(hiColor);
                g.drawLine(x + 1, y + 1, x + 1, h - 2);
                g.drawLine(x + 1, y + 1, w - tabAreaWidth - 1, y + 1);
                break;
            }
        }
    }

    protected void paintScrollContentBorder(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        Insets bi = tabPane.getBorder().getBorderInsets(tabPane);
        Color loColor = AbstractLookAndFeel.getControlDarkShadow();
        Color hiColor = AbstractLookAndFeel.getControlHighlight();
        g.setColor(loColor);
        switch (tabPlacement) {
            case TOP: {
                int tabAreaHeight = calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                g.drawLine(x, y + tabAreaHeight - 1 - bi.top, w, y + tabAreaHeight - 1 - bi.top);
                g.setColor(hiColor);
                g.drawLine(x, y + tabAreaHeight - bi.top, w - 1, y + tabAreaHeight - bi.top);
                break;
            }
            case LEFT: {
                int tabAreaWidth = calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                g.drawLine(x + tabAreaWidth - 1 - bi.left, y, x + tabAreaWidth - 1 - bi.left, h);
                g.setColor(hiColor);
                g.drawLine(x + tabAreaWidth - bi.left, y, x + tabAreaWidth - bi.left, h);
                break;
            }
            case BOTTOM: {
                int tabAreaHeight = calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                g.drawLine(x, h - tabAreaHeight + bi.bottom, w, h - tabAreaHeight + bi.bottom);
                break;
            }
            case RIGHT: {
                int tabAreaWidth = calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                g.drawLine(w - tabAreaWidth + bi.right, y, w - tabAreaWidth + bi.right, h);
                break;
            }
        }
    }

    protected void paintRoundedTopTabBorder(int tabIndex, Graphics g, int x1, int y1, int x2, int y2, boolean isSelected) {
        Graphics2D g2D = (Graphics2D) g;
        Object savedRederingHint = g2D.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
        g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Color loColor = AbstractLookAndFeel.getControlDarkShadow();
        Color hiColor = AbstractLookAndFeel.getControlHighlight();
        int d = 2 * GAP;
        if (isSelected) {
            g.setColor(ColorHelper.brighter(loColor, 20));
            g.drawLine(x1 + GAP, y1, x2 - GAP, y1);
            g.setColor(hiColor);
            g.drawLine(x1 + GAP, y1 + 1, x2 - GAP, y1 + 1);
            g.setColor(ColorHelper.brighter(loColor, 10));
            g.drawArc(x1, y1, d, d, 90, 90);
            g.setColor(hiColor);
            g.drawArc(x1 + 1, y1 + 1, d, d, 90, 90);
            g.setColor(ColorHelper.brighter(loColor, 10));
            g.drawArc(x2 - d, y1, d, d, 0, 90);
            g.setColor(loColor);
            g.drawLine(x1, y1 + GAP + 1, x1, y2);
            g.setColor(hiColor);
            g.drawLine(x1 + 1, y1 + GAP + 1, x1 + 1, y2);
            g.setColor(loColor);
            g.drawLine(x2, y1 + GAP + 1, x2, y2);
        } else {
            g.setColor(loColor);
            g.drawLine(x1 + GAP, y1, x2 - GAP, y1);
            g.drawArc(x1, y1, d, d, 90, 90);
            g.drawArc(x2 - d, y1, d, d, 0, 90);
            g.drawLine(x1, y1 + GAP + 1, x1, y2);
            g.drawLine(x2, y1 + GAP + 1, x2, y2);
        }
        g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, savedRederingHint);
    }
}