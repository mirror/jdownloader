/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */
package com.jtattoo.plaf.mcwin;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;

import com.jtattoo.plaf.*;

/**
 * @author Michael Hagen
 */
public class McWinToggleButtonUI extends BaseToggleButtonUI {

    public static ComponentUI createUI(JComponent c) {
        return new McWinToggleButtonUI();
    }

    protected void paintBackground(Graphics g, AbstractButton b) {
        if (!b.isContentAreaFilled() || (b.getParent() instanceof JMenuBar)) {
            return;
        }

        int width = b.getWidth();
        int height = b.getHeight();
        if (!(b.isBorderPainted() && (b.getBorder() instanceof UIResource))) {
            super.paintBackground(g, b);
            if ((b.getParent() instanceof JToolBar)) {
                g.setColor(Color.lightGray);
                g.drawRect(0, 0, width - 2, height - 1);
                g.setColor(Color.white);
                g.drawLine(width - 1, 0, width - 1, height - 1);
            }
            return;
        }

        Color colors[] = null;
        ButtonModel model = b.getModel();
        if (b.isEnabled()) {
            if (b.getBackground().equals(AbstractLookAndFeel.getButtonBackgroundColor())) {
                if ((model.isPressed() && model.isArmed()) || model.isSelected()) {
                    colors = McWinLookAndFeel.getTheme().getPressedColors();
                } else {
                    if (model.isRollover()) {
                        colors = McWinLookAndFeel.getTheme().getRolloverColors();
                    } else if (JTattooUtilities.isFrameActive(b)) {
                        colors = McWinLookAndFeel.getTheme().getButtonColors();
                    } else {
                        colors = McWinLookAndFeel.getTheme().getInActiveColors();
                    }
                }
            } else {
                if ((model.isPressed() && model.isArmed()) || model.isSelected()) {
                    colors = ColorHelper.createColorArr(b.getBackground(), ColorHelper.darker(b.getBackground(), 50), 20);
                } else {
                    if (model.isRollover()) {
                        colors = ColorHelper.createColorArr(ColorHelper.brighter(b.getBackground(), 80), ColorHelper.brighter(b.getBackground(), 20), 20);
                    } else {
                        colors = ColorHelper.createColorArr(ColorHelper.brighter(b.getBackground(), 40), ColorHelper.darker(b.getBackground(), 20), 20);
                    }
                }
            }
        } else {
            colors = McWinLookAndFeel.getTheme().getDisabledColors();
        }
        JTattooUtilities.fillHorGradient(g, colors, 0, 0, width, height);
        g.setColor(Color.lightGray);
        g.drawRect(0, 0, width - 2, height - 1);
        g.setColor(Color.white);
        g.drawLine(width - 1, 0, width - 1, height - 1);
    }
}


