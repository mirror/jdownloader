/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */
package com.jtattoo.plaf.mcwin;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;

import com.jtattoo.plaf.*;

/**
 * @author Michael Hagen
 */
public class McWinTabbedPaneUI extends BaseTabbedPaneUI {

    private Color sepColors[] = null;
    private Color altSepColors[] = null;

    public static ComponentUI createUI(JComponent c) {
        return new McWinTabbedPaneUI();
    }

    public void installDefaults() {
        super.installDefaults();
        tabAreaInsets.bottom = 6;
    }

    protected Color[] getContentBorderColors(int tabPlacement) {
        if (JTattooUtilities.isActive(tabPane)) {
            if (tabPlacement == TOP || tabPlacement == LEFT) {
                if (sepColors == null) {
                    int len = AbstractLookAndFeel.getTheme().getDefaultColors().length;
                    sepColors = new Color[5];
                    sepColors[0] = AbstractLookAndFeel.getTheme().getDefaultColors()[0];
                    sepColors[1] = AbstractLookAndFeel.getTheme().getDefaultColors()[len - 6];
                    sepColors[2] = AbstractLookAndFeel.getTheme().getDefaultColors()[2];
                    sepColors[3] = AbstractLookAndFeel.getTheme().getDefaultColors()[1];
                    sepColors[4] = AbstractLookAndFeel.getTheme().getDefaultColors()[0];
                }
                return sepColors;
            } else {
                if (altSepColors == null) {
                    int len = AbstractLookAndFeel.getTheme().getDefaultColors().length;
                    altSepColors = new Color[5];
                    altSepColors[0] = AbstractLookAndFeel.getTheme().getDefaultColors()[9];
                    altSepColors[1] = AbstractLookAndFeel.getTheme().getDefaultColors()[8];
                    altSepColors[2] = AbstractLookAndFeel.getTheme().getDefaultColors()[7];
                    altSepColors[3] = AbstractLookAndFeel.getTheme().getDefaultColors()[6];
                    altSepColors[4] = AbstractLookAndFeel.getTheme().getDefaultColors()[0];
                }
                return altSepColors;
            }
        } else {
            return super.getContentBorderColors(tabPlacement);
        }
    }

    protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        McWinUtils.fillComponent(g, tabPane);
        super.paintContentBorder(g, tabPlacement, selectedIndex, x, y, w, h);
    }
}