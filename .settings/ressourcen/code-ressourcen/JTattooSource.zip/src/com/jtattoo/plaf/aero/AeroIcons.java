/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */

package com.jtattoo.plaf.aero;

import java.io.Serializable;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.plaf.UIResource;

import com.jtattoo.plaf.*;

/**
 * @author Michael Hagen
 */
public class AeroIcons extends BaseIcons {
    private static Icon iconIcon = null;
    private static Icon maxIcon = null;
    private static Icon minIcon = null;
    private static Icon closeIcon = null;
    
    private static Icon radioButtonIcon = null;
    private static Icon checkBoxIcon = null;
    
    public static Icon getIconIcon() {
        if (iconIcon == null)
            iconIcon = new BaseIcons.IconSymbol(Color.black, Color.white, null, new Insets(2, 2, 2, 2));
        return iconIcon;
    }
    
    public static Icon getMinIcon() {
        if (minIcon == null)
            minIcon = new BaseIcons.MinSymbol(Color.black, Color.white, null, new Insets(2, 2, 2, 2));
        return minIcon;
    }
    
    public static Icon getMaxIcon() {
        if (maxIcon == null)
            maxIcon = new BaseIcons.MaxSymbol(Color.black, Color.white, null, new Insets(2, 2, 2, 2));
        return maxIcon;
    }
    
    public static Icon getCloseIcon() {
        if (closeIcon == null)
            closeIcon = new BaseIcons.CloseSymbol(Color.black, Color.white, null, new Insets(2, 2, 2, 2));
        return closeIcon;
    }
    
    public static Icon getRadioButtonIcon() {
        if (radioButtonIcon == null)
            radioButtonIcon = new RadioButtonIcon();
        return radioButtonIcon;
    }
    
    public static Icon getCheckBoxIcon() {
        if (checkBoxIcon == null)
            checkBoxIcon = new CheckBoxIcon();
        return checkBoxIcon;
    }
    
    //--------------------------------------------------------------------------------------------------------
    private static class CheckBoxIcon implements Icon, UIResource, Serializable {

        private static Icon checkIcon = new LazyImageIcon("icons/CheckSymbol.gif");
        private static Icon checkPressedIcon = new LazyImageIcon("icons/CheckPressedSymbol.gif");

        private final static int WIDTH = 15;
        private final static int HEIGHT = 15;
        
        public void paintIcon(Component c, Graphics g, int x, int y) {
            if (!JTattooUtilities.isLeftToRight(c))
                x += 3;
            JCheckBox cb = (JCheckBox)c;
            ButtonModel model = cb.getModel();
            Color colors[] = null;
            if (cb.isEnabled()) {
                if (cb.isRolloverEnabled() && model.isRollover() && !model.isArmed())
                    colors = AeroLookAndFeel.getTheme().getRolloverColors();
                else if (JTattooUtilities.isFrameActive(cb)) {
                    if (model.isArmed() && model.isPressed())
                        colors = new Color[] {AeroLookAndFeel.getBackgroundColor()};
                    else
                        colors = AeroLookAndFeel.getTheme().getButtonColors();
                }
                else
                    colors = AeroLookAndFeel.getTheme().getInActiveColors();
            }
            else {
                colors = AeroLookAndFeel.getTheme().getDisabledColors();
            }
            JTattooUtilities.fillHorGradient(g, colors, x + 1, y + 1, WIDTH - 1, HEIGHT - 1);
            if (cb.isEnabled())
                g.setColor(AeroLookAndFeel.getFrameColor());
            else
                g.setColor(ColorHelper.brighter(AeroLookAndFeel.getFrameColor(), 20));
            g.drawRect(x, y, WIDTH, HEIGHT);
            if (cb.isEnabled() && !model.isRollover() && !model.isPressed()) {
                g.setColor(Color.white);
                g.drawLine(x + 1, y + 1, x + 1, y + HEIGHT - 2);
                g.drawLine(x + WIDTH - 1, y + 1, x + WIDTH - 1, y + HEIGHT - 2);
            }
            int xi = x + ((WIDTH - checkIcon.getIconWidth()) / 2) + 1;
            int yi = y + ((HEIGHT - checkIcon.getIconHeight()) / 2) + 1;
            if (model.isPressed()) {
                checkPressedIcon.paintIcon(c, g, xi, yi);
            }
            else if (model.isSelected()) {
                checkIcon.paintIcon(c, g, xi, yi);
            }
        }
        
        public int getIconWidth()
        { return WIDTH + 4; }
        
        public int getIconHeight()
        { return HEIGHT; }
    }
    
    private static class RadioButtonIcon implements Icon, UIResource, Serializable {
        private static Icon radioIcon = new LazyImageIcon("icons/RadioSymbol.gif");
        
        private final static int WIDTH = 14;
        private final static int HEIGHT = 14;
        
        public void paintIcon(Component c, Graphics g, int x, int y) {
            if (!JTattooUtilities.isLeftToRight(c))
                x += 3;
            Graphics2D g2D = (Graphics2D)g;
            JRadioButton cb = (JRadioButton)c;
            ButtonModel model = cb.getModel();
            Color colors[] = null;
            if (cb.isEnabled()) {
                if (cb.isRolloverEnabled() && model.isRollover())
                    colors = AeroLookAndFeel.getTheme().getRolloverColors();
                else if (JTattooUtilities.isFrameActive(cb))
                    colors = AeroLookAndFeel.getTheme().getButtonColors();
                else
                    colors = AeroLookAndFeel.getTheme().getInActiveColors();
            }
            else {
                colors = AeroLookAndFeel.getTheme().getDisabledColors();
            }
            
            Shape savedClip = g.getClip();
            Area clipArea = new Area(savedClip);
            Area ellipseArea = new Area(new Ellipse2D.Double(x, y, WIDTH + 1, HEIGHT + 1));
            ellipseArea.intersect(clipArea);
            g2D.setClip(ellipseArea);
            JTattooUtilities.fillHorGradient(g, colors, x, y, WIDTH, HEIGHT);
            g2D.setClip(savedClip);
            
            if (cb.isEnabled())
                g.setColor(AeroLookAndFeel.getFrameColor());
            else
                g.setColor(ColorHelper.brighter(AeroLookAndFeel.getFrameColor(), 20));
            Object savedRederingHint = g2D.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
            g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.drawOval(x, y, WIDTH, HEIGHT);
            g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, savedRederingHint);
            
            if (model.isSelected()) {
                int xi = x + ((WIDTH - radioIcon.getIconWidth()) / 2) + 1;
                int yi = y + ((HEIGHT - radioIcon.getIconHeight()) / 2) + 1;
                radioIcon.paintIcon(c, g, xi, yi);
            }
        }
        
        public int getIconWidth()
        { return WIDTH + 4; }
        
        public int getIconHeight()
        { return HEIGHT; }
    }
}
