/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */
package com.jtattoo.plaf.mint;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;

import com.jtattoo.plaf.*;

/**
 * @author Michael Hagen
 */
public class MintTabbedPaneUI extends BaseTabbedPaneUI {

    private static Color INACTIVE_SEP_COLORS[] = ColorHelper.createColorArr(new Color(220, 228, 228), new Color(208, 214, 214), 6);

    public static ComponentUI createUI(JComponent c) {
        return new MintTabbedPaneUI();
    }

    public void installDefaults() {
        super.installDefaults();
        tabAreaInsets.bottom = 6;
    }

    protected Color[] getContentBorderColors(int tabPlacement) {
        if (!JTattooUtilities.isActive(tabPane)) {
            return INACTIVE_SEP_COLORS;
        } else {
            return super.getContentBorderColors(tabPlacement);
        }
    }
}