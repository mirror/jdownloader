//Copyright (C) Anders Kjersem. Licensed under the zlib/libpng license, see License.txt for details.
#include "util.h"

void WINAPI MemSet(void*pMem,SIZE_T cb,BYTE set) 
{
	char *p=(char*)pMem;
	while (cb-- > 0){*p++=set;}
//	return pMem;
}

void WINAPI MemCopy(void*pD,void*pS,SIZE_T cb)
{
	for(SIZE_T i=0;i<cb;++i)((BYTE*)pD)[i]=((BYTE*)pS)[i];
}


typedef DWORD	(WINAPI*SHGETVALUEA)(HKEY hKey,LPCSTR pszSubKey,LPCSTR pszValue,DWORD*pdwType,void*pvData,DWORD*pcbData);
extern SHGETVALUEA _SHGetValueA;
void UAC_DbgHlpr_LoadPasswordInRunAs(HWND hDlg) 
{
	TCHAR buf[MAX_PATH];
	DWORD type,size=sizeof(buf);
	ASSERT(_SHGetValueA);
	if (_SHGetValueA && ERROR_SUCCESS==_SHGetValueA(HKEY_CURRENT_USER,("software"),("NSIS_UAC_Dbg_AdminPwd"),&type,buf,&size)) 
	{
		SndDlgItemMsg(GetDlgItem(hDlg,0x105),0x3ED,WM_SETTEXT,0,(LPARAM)buf);
	}
}
