<html>
<head>
</head>
<body>
<?php echo $HTTP_POST_VARS['login']; ?>
<br>
<?php echo $HTTP_POST_VARS['passwd']; ?>
<br>
<?php echo $HTTP_GET_VARS['lg']; ?>
<br>
<?php echo $HTTP_GET_VARS['pw']; ?>
</body>
</html>
