/*****************************************************************
 *                Registry NSIS plugin v3.5                      *
 *                                                               *
 * 2008 Shengalts Aleksander aka Instructor (Shengalts@mail.ru)  *
 *****************************************************************/


/* Comment-out and recompile */
#define REGISTRY_SEARCH        //Compile with search function
#define REGISTRY_KEY_EXISTS    //Compile with check key function
#define REGISTRY_READ          //Compile with read function
#define REGISTRY_WRITE         //Compile with write function
#define REGISTRY_READ_EXTRA    //Compile with extra read function
#define REGISTRY_WRITE_EXTRA   //Compile with extra write function
#define REGISTRY_CREATE        //Compile with create function
#define REGISTRY_DELETE        //Compile with delete key/value functions
#define REGISTRY_COPY_VALUE    //Compile with copy/move value functions
#define REGISTRY_COPY_KEY      //Compile with copy/move key functions
#define REGISTRY_BACKUP        //Compile with export/import functions
#define REGISTRY_CONVERT       //Compile with convertion functions



#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "ConvFunc.h"
#include "StrFunc.h"
#include "StackFunc.h"
#ifdef POCKETPC
  #include <basetyps.h>
  #include "RAPI\rapi.h"
#endif

/* Include conversion functions */
#define xatoiA
#define xitoaA
#define dec2hexA
#define hex2decA
#define hex2strA
#define str2hexA
#include "ConvFunc.h"

/* Include string functions */
#define xstrstrA
#define GetOptionsA
#include "StrFunc.h"

/* Include private stack functions */
#define StackInsert
#define StackDelete
#define StackClear
#include "StackFunc.h"

/* Defines */
#define NSIS_MAX_STRLEN       1024
#define MAX_PATHLEN           MAX_PATH+32
#ifndef POCKETPC
  #define MAX_DATALEN   65536
#else
  #define MAX_DATALEN   4096
#endif
#ifndef REG_QWORD
  #define REG_QWORD     11
#endif
#define IDC_STATIC_DETAILS    1006
#define PPC_TIMEOUT           3000

#define RO_TYPE_ALL          -1

#define RO_NAME_ALL           0
#define RO_NAME_EXACT         1
#define RO_NAME_SUBSTR_S      2
#define RO_NAME_SUBSTR_I      3

#define RO_GOTO_END           0
#define RO_GOTO_BEGIN         1
#define RO_GOTO_OPENKEY       2
#define RO_GOTO_NEXTKEY       3
#define RO_GOTO_NEXTVALUE     4

#define RO_BANNER_IGNORE      0
#define RO_BANNER_DETAILS     1
#define RO_BANNER_CALLBACK    2

#define RO_DELETE_IGNORE      0
#define RO_DELETE_ROOT        1
#define RO_DELETE_ANY         2

typedef struct _privat_stack {
  struct _privat_stack *next;
  struct _privat_stack *prev;
  char string[MAX_PATHLEN];
} privat_stack;

typedef struct _HREGSTACK {
  HSTACK hKeysStack;
  char szName[MAX_PATHLEN];
  char szPath[MAX_PATHLEN];
  char szKey[MAX_PATHLEN];
  char szValue[MAX_PATHLEN];
  unsigned char szString[MAX_DATALEN];
  HKEY hKeyRoot;
  HKEY hKeyHandle;
  DWORD dwIndex;
  int nElement;
  short nFindType;
  short nBanner;
  short nGoto;
  short nNames;
  BOOL bFindKeys;
  BOOL bFindValues;
  BOOL bFindStrings;
  BOOL bGotoSubkeys;
} HREGSTACK;

/* ExDll */
typedef struct _stack_t {
  struct _stack_t *next;
  char text[1];
} stack_t;

stack_t **g_stacktop;
char *g_variables;
unsigned int g_stringsize;

#define EXDLL_INIT()        \
{                           \
  g_stacktop=stacktop;      \
  g_variables=variables;    \
  g_stringsize=string_size; \
}

/* Global variables */
char szBuf[MAX_DATALEN];
char szBuf2[MAX_DATALEN];
char szName[MAX_PATHLEN];
char szPath[MAX_PATHLEN];
char szKey[MAX_PATHLEN];
char szValue[MAX_PATHLEN];
unsigned char szString[MAX_DATALEN];
BOOL bMoveValue=FALSE;
BOOL bMoveKey=FALSE;
HWND hSearchDetails=0;
HREGSTACK *hRegStack;

#ifdef POCKETPC
  wchar_t wszBuf[MAX_PATHLEN];
  wchar_t wszData[MAX_DATALEN];
#endif

/* Funtions prototypes and macros */
int TypeNameToTypeValue(char *name);
char* TypeValueToTypeName(DWORD type);
BOOL RegReadPath(char *pFullPath, HKEY *hKeyRoot, char *szKeyRoot, char *szKey);
void RegReadType(char *szOutput, char **pType, DWORD dwType, unsigned char *szString, DWORD dwSizeString);
void RegWriteType(HANDLE hFileWrite, char *szValueName, DWORD dwType, unsigned char *szString, DWORD dwSizeString);
void ReplaceEscapeSequence(char *pResult, char *pText);
LONG RegCopyKey(HKEY hSource, char *szPathSource, HKEY hTarget, char *szPathTarget);
int RegCopyValue(HKEY hSource, HKEY hTarget, char *szPathSource, char *pValueSource, char *szPathTarget, char *pValueTarget, BOOL bMove);
LONG RegDeleteSubKeys(HKEY hKeyRoot, LPCTSTR lpSubKey);
int RegDeleteKeyPath(HKEY hKeyRoot, char *szPath);
BOOL FileExists(char *fname);
void HexStrToHexData(char *pHexStr, unsigned char *pHexData, int *nHexLen);
#define SWAP_ENDIAN(x) (((x<<24)&0xFF000000)|((x<<8)&0xFF0000)|((x>>8)&0xFF00)|((x>>24)&0xFF))

LONG API_RegOpenKeyEx(HKEY hKey, LPCTSTR lpSubKey, DWORD ulOptions, REGSAM c, PHKEY phkResult);
LONG API_RegEnumKeyEx(HKEY hKey, DWORD dwIndex, LPTSTR lpName, LPDWORD lpcName, LPDWORD lpReserved, LPTSTR lpClass, LPDWORD lpcClass, PFILETIME lpftLastWriteTime);
LONG API_RegCreateKeyEx(HKEY hKey, LPCTSTR lpSubKey, DWORD Reserved, LPTSTR lpClass, DWORD dwOptions, REGSAM samDesired, LPSECURITY_ATTRIBUTES lpSecurityAttributes, PHKEY phkResult, LPDWORD lpdwDisposition);
LONG API_RegCloseKey(HKEY hKey);
LONG API_RegDeleteKey(HKEY hKey, LPCTSTR lpSubKey);
LONG API_RegEnumValue(HKEY hKey, DWORD dwIndex, LPTSTR lpValueName, LPDWORD lpcValueName, LPDWORD lpReserved, LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData);
LONG API_RegDeleteValue(HKEY hKey, LPCTSTR lpValueName);
LONG API_RegQueryValueEx(HKEY hKey, LPCTSTR lpValueName, LPDWORD lpReserved, LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData);
LONG API_RegSetValueEx(HKEY hKey, LPCTSTR lpValueName, DWORD Reserved, DWORD dwType, BYTE* lpData, DWORD cbData);

int popinteger();
void pushinteger(int integer);
int popstring(char *str, int len);
void pushstring(const char *str, int len);


/* NSIS functions code */
#ifdef REGISTRY_SEARCH
void __declspec(dllexport) _Open(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    hRegStack=(HREGSTACK *)GlobalAlloc(GPTR, sizeof(HREGSTACK));
    hRegStack->nFindType=RO_TYPE_ALL;
    hRegStack->nElement=1;
    hRegStack->nNames=RO_NAME_ALL;
    hRegStack->bFindKeys=TRUE;
    hRegStack->bFindValues=TRUE;
    hRegStack->bFindStrings=TRUE;
    hRegStack->bGotoSubkeys=TRUE;

    popstring(hRegStack->szPath, NSIS_MAX_STRLEN);
    popstring(szBuf, NSIS_MAX_STRLEN);

    RegReadPath(hRegStack->szPath, &hRegStack->hKeyRoot, NULL, hRegStack->szPath);

    if (GetOptionsA(szBuf, "/N=", FALSE, hRegStack->szName, NSIS_MAX_STRLEN))
      hRegStack->nNames=RO_NAME_EXACT;
    else if (GetOptionsA(szBuf, "/NS=", FALSE, hRegStack->szName, NSIS_MAX_STRLEN))
      hRegStack->nNames=RO_NAME_SUBSTR_S;
    else if (GetOptionsA(szBuf, "/NI=", FALSE, hRegStack->szName, NSIS_MAX_STRLEN))
      hRegStack->nNames=RO_NAME_SUBSTR_I;
    if (GetOptionsA(szBuf, "/K=", FALSE, szBuf2, NSIS_MAX_STRLEN) && *szBuf2 == '0')
      hRegStack->bFindKeys=FALSE;
    if (GetOptionsA(szBuf, "/V=", FALSE, szBuf2, NSIS_MAX_STRLEN) && *szBuf2 == '0')
      hRegStack->bFindValues=FALSE;
    if (GetOptionsA(szBuf, "/S=", FALSE, szBuf2, NSIS_MAX_STRLEN) && *szBuf2 == '0')
      hRegStack->bFindStrings=FALSE;
    if (GetOptionsA(szBuf, "/G=", FALSE, szBuf2, NSIS_MAX_STRLEN) && *szBuf2 == '0')
      hRegStack->bGotoSubkeys=FALSE;
    if (GetOptionsA(szBuf, "/B=", FALSE, szBuf2, NSIS_MAX_STRLEN))
    {
      if (*szBuf2 == '1')
      {
        hRegStack->nBanner=RO_BANNER_DETAILS;
        if (!hSearchDetails) hSearchDetails=GetDlgItem(FindWindowEx(hwndParent, NULL, "#32770", NULL), IDC_STATIC_DETAILS);
      }
      else if (*szBuf2 == '2')
      {
        hRegStack->nBanner=RO_BANNER_CALLBACK;
      }
    }
    if (GetOptionsA(szBuf, "/T=", FALSE, szBuf2, NSIS_MAX_STRLEN))
      hRegStack->nFindType=TypeNameToTypeValue(szBuf2);

    if (hRegStack->hKeyRoot == 0 || (hRegStack->bFindKeys == FALSE && hRegStack->bFindValues == FALSE && hRegStack->bFindStrings == FALSE))
      goto Error;

    if (API_RegOpenKeyEx(hRegStack->hKeyRoot, hRegStack->szPath, 0, KEY_READ, &hRegStack->hKeyHandle) == ERROR_SUCCESS)
    {
      API_RegCloseKey(hRegStack->hKeyHandle);
      hRegStack->nGoto=RO_GOTO_BEGIN;
      pushinteger((int)hRegStack);
      return;
    }

    Error:
    GlobalFree((HGLOBAL)hRegStack);
    pushstring("0", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _Find(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    privat_stack *lpElement;
    char *pType;
    DWORD dwSizeKey;
    DWORD dwSizeValue;
    DWORD dwSizeString;
    DWORD dwType;
    int i;

    hRegStack=(HREGSTACK *)popinteger();

    if (!hRegStack) goto End;
    if (hRegStack->nGoto == RO_GOTO_NEXTVALUE) goto EnumValue;
    else if (hRegStack->nGoto == RO_GOTO_NEXTKEY) goto EnumKey;
    else if (hRegStack->nGoto == RO_GOTO_OPENKEY) goto OpenKey;
    else if (hRegStack->nGoto == RO_GOTO_BEGIN) goto Begin;
    else if (hRegStack->nGoto == RO_GOTO_END) goto End;

    Begin:
    StackInsert((stack **)&hRegStack->hKeysStack.first, (stack **)&hRegStack->hKeysStack.last, (stack **)&lpElement, -1, sizeof(privat_stack));
    lstrcpyn(lpElement->string, hRegStack->szPath, MAX_PATHLEN);

    while (hRegStack->nElement != 0)
    {
      --hRegStack->nElement;

      if (lpElement=(privat_stack *)hRegStack->hKeysStack.last)
      {
        lstrcpyn(hRegStack->szPath, lpElement->string, MAX_PATHLEN);
        StackDelete((stack **)&hRegStack->hKeysStack.first, (stack **)&hRegStack->hKeysStack.last, (stack *)lpElement);
      }
      else break;

      if (hRegStack->nBanner == RO_BANNER_DETAILS) SendMessage(hSearchDetails, WM_SETTEXT, 0, (LPARAM)hRegStack->szPath);
      else if (hRegStack->nBanner == RO_BANNER_CALLBACK)
      {
        pushstring("BANNER", NSIS_MAX_STRLEN);
        pushstring("", NSIS_MAX_STRLEN);
        pushstring("", NSIS_MAX_STRLEN);
        pushstring(hRegStack->szPath, NSIS_MAX_STRLEN);

        hRegStack->nGoto=RO_GOTO_OPENKEY;
        return;
      }

      OpenKey:
      if (API_RegOpenKeyEx(hRegStack->hKeyRoot, hRegStack->szPath, 0, KEY_READ, &hRegStack->hKeyHandle) != ERROR_SUCCESS) continue;

      hRegStack->dwIndex=(DWORD)-1;
      if (!hRegStack->bFindValues && !hRegStack->bFindStrings) goto EnumKey;

      EnumValue:
      ++hRegStack->dwIndex;
      hRegStack->szString[0]='\0';
      dwSizeValue=MAX_PATHLEN;
      dwSizeString=MAX_DATALEN;

      if (API_RegEnumValue(hRegStack->hKeyHandle, hRegStack->dwIndex, hRegStack->szValue, &dwSizeValue, NULL, &dwType, hRegStack->szString, &dwSizeString) == ERROR_SUCCESS)
      {
        if ((hRegStack->bFindValues && (hRegStack->nNames == RO_NAME_ALL ||
                                        (hRegStack->nNames == RO_NAME_EXACT && !lstrcmpi(hRegStack->szValue, hRegStack->szName)) ||
                                        (hRegStack->nNames == RO_NAME_SUBSTR_S && xstrstrA(hRegStack->szValue, hRegStack->szName, TRUE, NULL, NULL)) ||
                                        (hRegStack->nNames == RO_NAME_SUBSTR_I && xstrstrA(hRegStack->szValue, hRegStack->szName, FALSE, NULL, NULL))) &&
                                       (hRegStack->nFindType == RO_TYPE_ALL ||
                                        hRegStack->nFindType == (int)dwType)) ||
            (hRegStack->bFindStrings && (hRegStack->nNames == RO_NAME_ALL ||
                                        ((dwType == REG_SZ || dwType == REG_EXPAND_SZ) &&
                                         ((hRegStack->nNames == RO_NAME_EXACT && !lstrcmpi((char *)hRegStack->szString, hRegStack->szName)) ||
                                          (hRegStack->nNames == RO_NAME_SUBSTR_S && xstrstrA((char *)hRegStack->szString, hRegStack->szName, TRUE, NULL, NULL)) ||
                                          (hRegStack->nNames == RO_NAME_SUBSTR_I && xstrstrA((char *)hRegStack->szString, hRegStack->szName, FALSE, NULL, NULL))))) &&
                                        (hRegStack->nFindType == RO_TYPE_ALL || hRegStack->nFindType == (int)dwType)))
        {
          RegReadType(szBuf, &pType, dwType, hRegStack->szString, dwSizeString);
          szBuf[NSIS_MAX_STRLEN - 2]='\0';
          pushstring(pType, NSIS_MAX_STRLEN);
          pushstring(szBuf, NSIS_MAX_STRLEN);
          pushstring(hRegStack->szValue, NSIS_MAX_STRLEN);
          pushstring(hRegStack->szPath, NSIS_MAX_STRLEN);

          hRegStack->nGoto=RO_GOTO_NEXTVALUE;
          return;
        }
        else goto EnumValue;
      }

      hRegStack->dwIndex=(DWORD)-1;

      EnumKey:
      if (hRegStack->bGotoSubkeys)
      {
        ++hRegStack->dwIndex;
        dwSizeKey=MAX_PATHLEN;

        if (API_RegEnumKeyEx(hRegStack->hKeyHandle, hRegStack->dwIndex, hRegStack->szKey, &dwSizeKey, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
        {
          lstrcpyn(szBuf, hRegStack->szPath, MAX_PATHLEN);
          if (hRegStack->szPath[0]) lstrcat(szBuf, "\\");
          lstrcat(szBuf, hRegStack->szKey);

          //StackInsert((stack **)&hRegStack->hKeysStack.first, (stack **)&hRegStack->hKeysStack.last, (stack **)&lpElement, hRegStack->dwIndex + 1, sizeof(privat_stack));
          StackInsert((stack **)&hRegStack->hKeysStack.first, (stack **)&hRegStack->hKeysStack.last, (stack **)&lpElement, -1, sizeof(privat_stack));
          lstrcpyn(lpElement->string, szBuf, MAX_PATHLEN);

          ++hRegStack->nElement;

          if (hRegStack->bFindKeys && (hRegStack->nNames == RO_NAME_ALL ||
                                       (hRegStack->nNames == RO_NAME_EXACT && !lstrcmpi(hRegStack->szKey, hRegStack->szName)) ||
                                       (hRegStack->nNames == RO_NAME_SUBSTR_S && xstrstrA(hRegStack->szKey, hRegStack->szName, TRUE, NULL, NULL)) ||
                                       (hRegStack->nNames == RO_NAME_SUBSTR_I && xstrstrA(hRegStack->szKey, hRegStack->szName, FALSE, NULL, NULL))))
          {
            pushstring("REG_KEY", NSIS_MAX_STRLEN);
            pushstring("", NSIS_MAX_STRLEN);
            pushstring(hRegStack->szKey, NSIS_MAX_STRLEN);
            pushstring(hRegStack->szPath, NSIS_MAX_STRLEN);
            hRegStack->nGoto=RO_GOTO_NEXTKEY;
            return;
          }
          else goto EnumKey;
        }
      }
      API_RegCloseKey(hRegStack->hKeyHandle);
    }
    hRegStack->hKeyHandle=0;
    hRegStack->nGoto=RO_GOTO_END;

    End:
    for(i=0; i < 4; ++i) pushstring("", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _Close(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    hRegStack=(HREGSTACK *)popinteger();

    if (hRegStack)
    {
      if (hRegStack->hKeyHandle) API_RegCloseKey(hRegStack->hKeyHandle);
      if (hRegStack->nBanner == RO_BANNER_DETAILS) SendMessage(hSearchDetails, WM_SETTEXT, 0, (LPARAM)"");
      StackClear((stack **)&hRegStack->hKeysStack.first, (stack **)&hRegStack->hKeysStack.last);
      GlobalFree((HGLOBAL)hRegStack);
    }
  }
}
#endif //REGISTRY_SEARCH

#ifdef REGISTRY_KEY_EXISTS
void __declspec(dllexport) _KeyExists(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    int nError=-1;

    popstring(szPath, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_READ, &hKeyHandle) == ERROR_SUCCESS)
    {
      nError=API_RegCloseKey(hKeyHandle);
    }
    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_KEY_EXISTS

#ifdef REGISTRY_READ
void __declspec(dllexport) _Read(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    char *pType;
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    DWORD dwSizeString=MAX_DATALEN;
    DWORD dwType;
    int nError=-1;
    szString[0]='\0';

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szName, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_QUERY_VALUE, &hKeyHandle) == ERROR_SUCCESS)
    {
      nError=API_RegQueryValueEx(hKeyHandle, szName, NULL, &dwType, szString, &dwSizeString);

      API_RegCloseKey(hKeyHandle);

      if (nError == ERROR_SUCCESS)
      {
        RegReadType(szBuf, &pType, dwType, szString, dwSizeString);
        szBuf[NSIS_MAX_STRLEN - 2]='\0';
      }
    }
    pushstring((nError == ERROR_SUCCESS)?pType:"", NSIS_MAX_STRLEN);
    pushstring((nError == ERROR_SUCCESS)?szBuf:"", NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_READ

#ifdef REGISTRY_WRITE
void __declspec(dllexport) _Write(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    char *pBuf=&szBuf[0];
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    DWORD dwValue;
    DWORD dwSizeString;
    DWORD dwType;
    DWORD dwDisposition;
    int nError=-1;

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szName, NSIS_MAX_STRLEN);
    popstring(szBuf, NSIS_MAX_STRLEN);
    popstring(szBuf2, NSIS_MAX_STRLEN);

    szBuf[NSIS_MAX_STRLEN - 2]='\0';
    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if ((dwType=(DWORD)TypeNameToTypeValue(szBuf2)) != (DWORD)-1 && API_RegCreateKeyEx(hKeyRoot, szPath, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKeyHandle, &dwDisposition) == ERROR_SUCCESS)
    {
      if (dwType == REG_BINARY ||
          dwType == REG_NONE ||
          dwType == REG_LINK ||
          dwType == REG_RESOURCE_LIST ||
          dwType == REG_FULL_RESOURCE_DESCRIPTOR ||
          dwType == REG_RESOURCE_REQUIREMENTS_LIST ||
          dwType == REG_QWORD)
      {
        HexStrToHexData(szBuf, (unsigned char *)szBuf2, (int *)&dwSizeString);
        nError=API_RegSetValueEx(hKeyHandle, szName, 0, dwType, (unsigned char *)szBuf2, dwSizeString);
      }
      else if (dwType == REG_DWORD ||
               dwType == REG_DWORD_BIG_ENDIAN)
      {
        if (dwType == REG_DWORD) dwValue=xatoiA(szBuf);
        else dwValue=SWAP_ENDIAN(xatoiA(szBuf));
        nError=API_RegSetValueEx(hKeyHandle, szName, 0, dwType, (unsigned char *)&dwValue, sizeof(DWORD));
      }
      else if (dwType == REG_MULTI_SZ)
      {
        while (*pBuf)
        {
          if (*pBuf == '\n') *pBuf='\0';
          ++pBuf;
        }
        *++pBuf='\0';

        nError=API_RegSetValueEx(hKeyHandle, szName, 0, REG_MULTI_SZ, (unsigned char *)szBuf, (pBuf - szBuf) + 1);
      }
      else if (dwType == REG_EXPAND_SZ ||
               dwType == REG_SZ)
      {
        nError=API_RegSetValueEx(hKeyHandle, szName, 0, dwType, (unsigned char *)szBuf, lstrlen(szBuf) + 1);
      }
      API_RegCloseKey(hKeyHandle);
    }
    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_WRITE

#ifdef REGISTRY_READ_EXTRA
void __declspec(dllexport) _ReadExtra(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    char *pBuf=&szBuf[0];
    char *pType;
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    DWORD dwSizeString=MAX_DATALEN;
    DWORD dwType;
    int nError=-1;
    int nPointer;
    szString[0]='\0';

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szName, NSIS_MAX_STRLEN);
    nPointer=popinteger();

    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_QUERY_VALUE, &hKeyHandle) == ERROR_SUCCESS)
    {
      nError=API_RegQueryValueEx(hKeyHandle, szName, NULL, &dwType, szString, &dwSizeString);

      API_RegCloseKey(hKeyHandle);

      if (nError == ERROR_SUCCESS)
      {
        RegReadType(szBuf, &pType, dwType, szString, dwSizeString);

        if (dwType == REG_BINARY ||
            dwType == REG_NONE ||
            dwType == REG_LINK ||
            dwType == REG_RESOURCE_LIST ||
            dwType == REG_FULL_RESOURCE_DESCRIPTOR ||
            dwType == REG_RESOURCE_REQUIREMENTS_LIST ||
            dwType == REG_QWORD)
        {
          nPointer*=2;
        }
        if (nPointer > 0)
        {
          if (nPointer < lstrlen(szBuf)) pBuf+=nPointer;
          else pBuf[0]='\0';
        }
        else if (nPointer < 0 && (0 - nPointer) < lstrlen(szBuf))
          pBuf+=(lstrlen(szBuf) + nPointer);

        pBuf[NSIS_MAX_STRLEN - 2]='\0';
      }
    }
    pushstring((nError == ERROR_SUCCESS)?pType:"", NSIS_MAX_STRLEN);
    pushstring((nError == ERROR_SUCCESS)?pBuf:"", NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_READ_EXTRA

#ifdef REGISTRY_WRITE_EXTRA
void __declspec(dllexport) _WriteExtra(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    char *pBuf=&szBuf[0];
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    DWORD dwSizeString=MAX_DATALEN;
    DWORD dwSizeStringExtra;
    DWORD dwType;
    int nError=-1;
    int a,b,c;
    szString[0]='\0';

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szName, NSIS_MAX_STRLEN);
    popstring(szBuf, NSIS_MAX_STRLEN);

    szBuf[NSIS_MAX_STRLEN - 2]='\0';
    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_QUERY_VALUE|KEY_SET_VALUE, &hKeyHandle) == ERROR_SUCCESS)
    {
      nError=API_RegQueryValueEx(hKeyHandle, szName, NULL, &dwType, szString, &dwSizeString);

      if (nError == ERROR_SUCCESS && *szBuf)
      {
        if (dwType == REG_BINARY ||
            dwType == REG_NONE ||
            dwType == REG_LINK ||
            dwType == REG_RESOURCE_LIST ||
            dwType == REG_FULL_RESOURCE_DESCRIPTOR ||
            dwType == REG_RESOURCE_REQUIREMENTS_LIST ||
            dwType == REG_QWORD)
        {
          HexStrToHexData(szBuf, (unsigned char *)szBuf2, (int *)&dwSizeStringExtra);
          for (a=0, b=dwSizeString, c=dwSizeStringExtra; a < c; szString[b++]=szBuf2[a++]);
          nError=API_RegSetValueEx(hKeyHandle, szName, 0, dwType, szString, (dwSizeString + c));
        }
        else if (dwType == REG_MULTI_SZ)
        {
          while (*pBuf)
          {
            if (*pBuf == '\n') *pBuf='\0';
            ++pBuf;
          }
          *++pBuf='\0';

          for (a=0, b=dwSizeString - 1, c=(pBuf - szBuf) + 1; a < c; szString[b++]=szBuf[a++]);
          nError=API_RegSetValueEx(hKeyHandle, szName, 0, REG_MULTI_SZ, szString, b);
        }
        else if (dwType == REG_EXPAND_SZ ||
                 dwType == REG_SZ)
        {
          lstrcat((char *)szString, szBuf);
          nError=API_RegSetValueEx(hKeyHandle, szName, 0, dwType, szString, lstrlen((char *)szString) + 1);
        }
      }
      API_RegCloseKey(hKeyHandle);
    }
    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_WRITE_EXTRA

#ifdef REGISTRY_CREATE
void __declspec(dllexport) _CreateKey(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    DWORD dwDisposition;

    popstring(szPath, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if (API_RegCreateKeyEx(hKeyRoot, szPath, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKeyHandle, &dwDisposition) == ERROR_SUCCESS)
    {
      API_RegCloseKey(hKeyHandle);

      pushstring((dwDisposition == REG_CREATED_NEW_KEY)?"0":"1", NSIS_MAX_STRLEN);
      return;
    }
    pushstring("-1", NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_CREATE

#ifdef REGISTRY_DELETE
void __declspec(dllexport) _DeleteValue(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    int nError=-1;

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szName, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_SET_VALUE, &hKeyHandle) == ERROR_SUCCESS)
    {
      nError=API_RegDeleteValue(hKeyHandle, szName);

      API_RegCloseKey(hKeyHandle);
    }
    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _DeleteKey(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    HKEY hKeyRoot=0;
    int nError=-1;

    popstring(szPath, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    nError=RegDeleteKeyPath(hKeyRoot, szPath);

    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _DeleteKeyEmpty(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    DWORD dwSizeKey=MAX_PATHLEN;
    DWORD dwSizeValue=MAX_PATHLEN;
    DWORD dwType;
    int nError=-1;
    popstring(szPath, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRoot, NULL, szPath);

    if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_READ, &hKeyHandle) == ERROR_SUCCESS)
    {
      if (API_RegEnumKeyEx(hKeyHandle, 0, szKey, &dwSizeKey, NULL, NULL, NULL, NULL) != ERROR_SUCCESS &&
          API_RegEnumValue(hKeyHandle, 0, szValue, &dwSizeValue, NULL, &dwType, NULL, NULL) != ERROR_SUCCESS)
      {
        nError=ERROR_SUCCESS;
      }
      API_RegCloseKey(hKeyHandle);

      if (nError == ERROR_SUCCESS)
      {
        nError=RegDeleteKeyPath(hKeyRoot, szPath);
      }
    }
    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_DELETE

#ifdef REGISTRY_COPY_VALUE
void __declspec(dllexport) _CopyValue(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    DWORD dwSizeString=MAX_DATALEN;
    DWORD dwType;
    DWORD dwDisposition;
    HKEY hKeyRootSource=0;
    HKEY hKeyRootTarget=0;
    HKEY hSourceHandle;
    HKEY hTargetHandle;
    int nError=-1;
    szString[0]='\0';

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szName, NSIS_MAX_STRLEN);
    popstring(szBuf, NSIS_MAX_STRLEN);
    popstring(szBuf2, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRootSource, NULL, szPath);
    RegReadPath(szBuf, &hKeyRootTarget, NULL, szBuf);

    if (API_RegOpenKeyEx(hKeyRootSource, szPath, 0, KEY_QUERY_VALUE|KEY_SET_VALUE, &hSourceHandle) == ERROR_SUCCESS)
    {
      nError=API_RegQueryValueEx(hSourceHandle, szName, NULL, &dwType, szString, &dwSizeString);

      if (nError == ERROR_SUCCESS && (nError=API_RegCreateKeyEx(hKeyRootTarget, szBuf, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hTargetHandle, &dwDisposition)) == ERROR_SUCCESS)
      {
        nError=API_RegSetValueEx(hTargetHandle, szBuf2, 0, dwType, szString, dwSizeString);

        API_RegCloseKey(hTargetHandle);

        if (bMoveValue == TRUE && nError == ERROR_SUCCESS)
          nError=API_RegDeleteValue(hSourceHandle, szName);
      }
      API_RegCloseKey(hSourceHandle);
    }
    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _MoveValue(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  bMoveValue=TRUE;
  _CopyValue(hwndParent, string_size, variables, stacktop);
  bMoveValue=FALSE;
}
#endif //REGISTRY_COPY_VALUE

#ifdef REGISTRY_COPY_KEY
void __declspec(dllexport) _CopyKey(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    HKEY hKeyRootSource=0;
    HKEY hKeyRootTarget=0;
    int nError;

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szBuf, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRootSource, NULL, szPath);
    RegReadPath(szBuf, &hKeyRootTarget, NULL, szBuf);

    if ((nError=RegCopyKey(hKeyRootSource, szPath, hKeyRootTarget, szBuf)) == ERROR_SUCCESS)
      if (bMoveKey == TRUE) nError=RegDeleteKeyPath(hKeyRootSource, szPath);

    pushstring((nError == ERROR_SUCCESS)?"0":"-1", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _MoveKey(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  bMoveKey=TRUE;
  _CopyKey(hwndParent, string_size, variables, stacktop);
  bMoveKey=FALSE;
}
#endif //REGISTRY_COPY_KEY

#ifdef REGISTRY_BACKUP
void __declspec(dllexport) _SaveKey(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    HSTACK hKeysStack={0};
    privat_stack *lpElement=NULL;
    char szRootName[MAX_PATHLEN];
    char szNameFilter[MAX_PATHLEN];
    HANDLE hFileWrite=0;
    HKEY hKeyRoot=0;
    HKEY hKeyHandle=0;
    DWORD dwSizeKey;
    DWORD dwSizeValue;
    DWORD dwSizeString;
    DWORD dwType;
    DWORD dwIndex;
    DWORD dwNumberOfBytesWritten;
    int nElement=1;
    short nReplaceSubkeys=RO_DELETE_IGNORE;
    short nBanner=RO_BANNER_IGNORE;
    BOOL bGotoSubkeys=TRUE;
    BOOL bAppendFile=FALSE;
    int nNames=RO_NAME_ALL;

    popstring(szPath, NSIS_MAX_STRLEN);
    popstring(szName, NSIS_MAX_STRLEN);
    popstring(szBuf, NSIS_MAX_STRLEN);

    RegReadPath(szPath, &hKeyRoot, szRootName, szPath);

    if (GetOptionsA(szBuf, "/G=", FALSE, szBuf2, NSIS_MAX_STRLEN) && *szBuf2 == '0')
      bGotoSubkeys=FALSE;
    if (GetOptionsA(szBuf, "/N=", FALSE, szNameFilter, NSIS_MAX_STRLEN))
      nNames=RO_NAME_EXACT;
    if (GetOptionsA(szBuf, "/A=", FALSE, szBuf2, NSIS_MAX_STRLEN) && *szBuf2 == '1')
      bAppendFile=TRUE;
    if (GetOptionsA(szBuf, "/B=", FALSE, szBuf2, NSIS_MAX_STRLEN) && *szBuf2 == '1')
    {
      nBanner=RO_BANNER_DETAILS;
      if (!hSearchDetails) hSearchDetails=GetDlgItem(FindWindowEx(hwndParent, NULL, "#32770", NULL), IDC_STATIC_DETAILS);
    }
    if (GetOptionsA(szBuf, "/D=", FALSE, szBuf2, NSIS_MAX_STRLEN))
    {
      if (*szBuf2 == '1') nReplaceSubkeys=RO_DELETE_ROOT;
      else if (*szBuf2 == '2') nReplaceSubkeys=RO_DELETE_ANY;
    }

    if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_READ, &hKeyHandle) != ERROR_SUCCESS)
    {
      pushstring("-1", NSIS_MAX_STRLEN);
      return;
    }
    API_RegCloseKey(hKeyHandle);

    if (bAppendFile)
    {
      hFileWrite=CreateFile(szName, FILE_APPEND_DATA, 0, NULL, OPEN_EXISTING, 0, 0);
      if (hFileWrite == INVALID_HANDLE_VALUE) bAppendFile=FALSE;
    }
    if (!bAppendFile) hFileWrite=CreateFile(szName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

    if (hFileWrite == INVALID_HANDLE_VALUE)
    {
      pushstring("-1", NSIS_MAX_STRLEN);
      return;
    }

    if (!bAppendFile) WriteFile(hFileWrite, "REGEDIT4\r\n", lstrlen("REGEDIT4\r\n"), &dwNumberOfBytesWritten, NULL);

    StackInsert((stack **)&hKeysStack.first, (stack **)&hKeysStack.last, (stack **)&lpElement, 1, sizeof(privat_stack));
    lstrcpyn(lpElement->string, szPath, MAX_PATHLEN);

    while (nElement != 0)
    {
      --nElement;

      if (lpElement=(privat_stack *)hKeysStack.last)
      {
        lstrcpyn(szPath, lpElement->string, MAX_PATHLEN);
        StackDelete((stack **)&hKeysStack.first, (stack **)&hKeysStack.last, (stack *)lpElement);
      }
      else break;

      if (nBanner == RO_BANNER_DETAILS) SendMessage(hSearchDetails, WM_SETTEXT, 0, (LPARAM)szPath);

      if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_READ, &hKeyHandle) != ERROR_SUCCESS) continue;

      if (!szPath[0])
        wsprintf(szBuf, "\r\n[%s]\r\n", szRootName);
      else
      {
        if (nReplaceSubkeys != RO_DELETE_IGNORE)
        {
          if (nReplaceSubkeys == RO_DELETE_ROOT) nReplaceSubkeys=RO_DELETE_IGNORE;
          wsprintf(szBuf, "\r\n[-%s\\%s]", szRootName, szPath);
          WriteFile(hFileWrite, szBuf, lstrlen(szBuf), &dwNumberOfBytesWritten, NULL);
        }
        wsprintf(szBuf, "\r\n[%s\\%s]\r\n", szRootName, szPath);
      }

      WriteFile(hFileWrite, szBuf, lstrlen(szBuf), &dwNumberOfBytesWritten, NULL);

      dwIndex=0;
      while (1)
      {
        dwSizeValue=MAX_PATHLEN;
        dwSizeString=MAX_DATALEN;
        szString[0]='\0';
        if (API_RegEnumValue(hKeyHandle, dwIndex++, szValue, &dwSizeValue, NULL, &dwType, szString, &dwSizeString) != ERROR_SUCCESS)
          break;

        if (nNames == RO_NAME_ALL || (nNames == RO_NAME_EXACT && !lstrcmpi(szValue, szNameFilter)))
          RegWriteType(hFileWrite, szValue, dwType, szString, dwSizeString);
      }

      if (bGotoSubkeys)
      {
        dwIndex=0;
        while (1)
        {
          dwSizeKey=MAX_PATHLEN;
          if (API_RegEnumKeyEx(hKeyHandle, dwIndex++, szKey, &dwSizeKey, NULL, NULL, NULL, NULL) != ERROR_SUCCESS)
            break;

          lstrcpyn(szBuf, szPath, MAX_PATHLEN);
          if (szPath[0]) lstrcat(szBuf, "\\");
          lstrcat(szBuf, szKey);

          StackInsert((stack **)&hKeysStack.first, (stack **)&hKeysStack.last, (stack **)&lpElement, dwIndex, sizeof(privat_stack));
          lstrcpyn(lpElement->string, szBuf, MAX_PATHLEN);

          ++nElement;
        }
      }
      API_RegCloseKey(hKeyHandle);
    }
    CloseHandle(hFileWrite);
    StackClear((stack **)&hKeysStack.first, (stack **)&hKeysStack.last);
    if (nBanner == RO_BANNER_DETAILS) SendMessage(hSearchDetails, WM_SETTEXT, 0, (LPARAM)"");
    pushstring("0", NSIS_MAX_STRLEN);
  }
}

#ifndef POCKETPC
void __declspec(dllexport) _RestoreKey(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    STARTUPINFO si={0};
    PROCESS_INFORMATION pi={0};

    popstring(szName, NSIS_MAX_STRLEN);

    if (!FileExists(szName)) goto Error;
    if (SearchPath(NULL, "regedit.exe", NULL, sizeof(szBuf2), szBuf2, 0) == 0) goto Error;
    wsprintf(szBuf, "%s /s \"%s\"", szBuf2, szName);

    si.cb=sizeof(STARTUPINFO);

    if (CreateProcess(NULL, szBuf, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
    {
      CloseHandle(pi.hProcess);
      CloseHandle(pi.hThread);
      pushstring("0", NSIS_MAX_STRLEN);
      return;
    }

    Error:
    pushstring("-1", NSIS_MAX_STRLEN);
  }
}
#endif //POCKETPC
#endif //REGISTRY_BACKUP

#ifdef REGISTRY_CONVERT
void __declspec(dllexport) _StrToHex(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    popstring(szBuf, NSIS_MAX_STRLEN);

    str2hexA((unsigned char *)szBuf, lstrlen(szBuf), szBuf2, NSIS_MAX_STRLEN, TRUE);

    pushstring(szBuf2, NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _HexToStr(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    popstring(szBuf, NSIS_MAX_STRLEN);

    hex2strA(szBuf, szBuf2, NSIS_MAX_STRLEN);

    pushstring(szBuf2, NSIS_MAX_STRLEN);
  }
}
#endif //REGISTRY_CONVERT

#ifdef POCKETPC
void __declspec(dllexport) _CERAPIINIT(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    if (CeRapiInit() == S_OK)
    {
      pushstring("0", NSIS_MAX_STRLEN);
      return;
    }
    //Unable to initialize connection to device
    pushstring("-1", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _CERAPIINITEX(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
    RAPIINIT rapiinit;

    rapiinit.cbSize=sizeof(RAPIINIT);
    rapiinit.heRapiInit=NULL;
    rapiinit.hrRapiInit=-1;

    if (CeRapiInitEx(&rapiinit) != S_OK)
    {
      //Unable to initialize connection to device
      pushstring("-1", NSIS_MAX_STRLEN);
      return;
    }
    if (MsgWaitForMultipleObjects(1, &rapiinit.heRapiInit, FALSE, PPC_TIMEOUT, 0) == WAIT_TIMEOUT)
    {
      //Timed out waiting for device
      CeRapiUninit();
      pushstring("-2", NSIS_MAX_STRLEN);
      return;
    }
    if (rapiinit.hrRapiInit != S_OK)
    {
      //Failed to connect to device
      CeRapiUninit();
      pushstring("-3", NSIS_MAX_STRLEN);
      return;
    }
    pushstring("0", NSIS_MAX_STRLEN);
  }
}

void __declspec(dllexport) _CERAPIUNINIT(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
  CeRapiUninit();
}
#endif //POCKETPC

void __declspec(dllexport) _Unload(HWND hwndParent, int string_size,
                                      char *variables, stack_t **stacktop)
{
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
#ifdef _DEBUG
  switch(ul_reason_for_call)
  {
    case DLL_PROCESS_ATTACH:
      break;
    case DLL_PROCESS_DETACH:
      break;
    case DLL_THREAD_ATTACH:
      break;
    case DLL_THREAD_DETACH:
      break;
  }
#endif
  return TRUE;
}


/* Functions */

// Function: "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft" -> HKEY_LOCAL_MACHINE "SOFTWARE\Microsoft"
BOOL RegReadPath(char *pFullPath, HKEY *hKeyRoot, char *szKeyRoot, char *szKey)
{
  char szRoot[MAX_PATHLEN];
  char *pKeyCount;
  int nFullPathLen;
  int nRootLen;
  int nKeyLen;

  nFullPathLen=lstrlen(pFullPath);
  for (pKeyCount=pFullPath + nFullPathLen - 1; pKeyCount >= pFullPath && *pKeyCount == '\\'; --pKeyCount)
    *pKeyCount='\0';

  for (pKeyCount=pFullPath; *pKeyCount && *pKeyCount != '\\'; ++pKeyCount);
  nRootLen=min(pKeyCount - pFullPath + 1, MAX_PATHLEN);
  lstrcpyn(szRoot, pFullPath, nRootLen);

  if (*pKeyCount == '\\') ++pKeyCount;
  nKeyLen=min(pFullPath + nFullPathLen - pKeyCount + 1, MAX_PATHLEN);
  if (szKey) lstrcpyn(szKey, pKeyCount, nKeyLen);

  if (!lstrcmpi(szRoot, "HKEY_CLASSES_ROOT") || !lstrcmpi(szRoot, "HKCR"))
  {
    *hKeyRoot=HKEY_CLASSES_ROOT;
    if (szKeyRoot) lstrcpy(szKeyRoot, "HKEY_CLASSES_ROOT");
  }
  else if (!lstrcmpi(szRoot, "HKEY_CURRENT_USER") || !lstrcmpi(szRoot, "HKCU"))
  {
    *hKeyRoot=HKEY_CURRENT_USER;
    if (szKeyRoot) lstrcpy(szKeyRoot, "HKEY_CURRENT_USER");
  }
  else if (!lstrcmpi(szRoot, "HKEY_LOCAL_MACHINE") || !lstrcmpi(szRoot, "HKLM"))
  {
    *hKeyRoot=HKEY_LOCAL_MACHINE;
    if (szKeyRoot) lstrcpy(szKeyRoot, "HKEY_LOCAL_MACHINE");
  }
  else if (!lstrcmpi(szRoot, "HKEY_USERS") || !lstrcmpi(szRoot, "HKU"))
  {
    *hKeyRoot=HKEY_USERS;
    if (szKeyRoot) lstrcpy(szKeyRoot, "HKEY_USERS");
  }
  else if (!lstrcmpi(szRoot, "HKEY_PERFORMANCE_DATA") || !lstrcmpi(szRoot, "HKPD"))
  {
    *hKeyRoot=HKEY_PERFORMANCE_DATA;
    if (szKeyRoot) lstrcpy(szKeyRoot, "HKEY_PERFORMANCE_DATA");
  }
  else if (!lstrcmpi(szRoot, "HKEY_CURRENT_CONFIG") || !lstrcmpi(szRoot, "HKCC"))
  {
    *hKeyRoot=HKEY_CURRENT_CONFIG;
    if (szKeyRoot) lstrcpy(szKeyRoot, "HKEY_CURRENT_CONFIG");
  }
  else if (!lstrcmpi(szRoot, "HKEY_DYN_DATA") || !lstrcmpi(szRoot, "HKDD"))
  {
    *hKeyRoot=HKEY_DYN_DATA;
    if (szKeyRoot) lstrcpy(szKeyRoot, "HKEY_DYN_DATA");
  }
  else
  {
    *hKeyRoot=0;
    return FALSE;
  }
  return TRUE;
}

int TypeNameToTypeValue(char *name)
{
  if (!lstrcmpi(name, "REG_BINARY")) return REG_BINARY;
  else if (!lstrcmpi(name, "REG_DWORD")) return REG_DWORD;
  else if (!lstrcmpi(name, "REG_DWORD_BIG_ENDIAN")) return REG_DWORD_BIG_ENDIAN;
  else if (!lstrcmpi(name, "REG_EXPAND_SZ")) return REG_EXPAND_SZ;
  else if (!lstrcmpi(name, "REG_MULTI_SZ")) return REG_MULTI_SZ;
  else if (!lstrcmpi(name, "REG_NONE")) return REG_NONE;
  else if (!lstrcmpi(name, "REG_SZ")) return REG_SZ;
  else if (!lstrcmpi(name, "REG_LINK")) return REG_LINK;
  else if (!lstrcmpi(name, "REG_RESOURCE_LIST")) return REG_RESOURCE_LIST;
  else if (!lstrcmpi(name, "REG_FULL_RESOURCE_DESCRIPTOR")) return REG_FULL_RESOURCE_DESCRIPTOR;
  else if (!lstrcmpi(name, "REG_RESOURCE_REQUIREMENTS_LIST")) return REG_RESOURCE_REQUIREMENTS_LIST;
  else if (!lstrcmpi(name, "REG_QWORD")) return REG_QWORD;
  else return -1;
}

char* TypeValueToTypeName(DWORD type)
{
  if (type == REG_BINARY) return "REG_BINARY";
  else if (type == REG_DWORD) return "REG_DWORD";
  else if (type == REG_DWORD_BIG_ENDIAN) return "REG_DWORD_BIG_ENDIAN";
  else if (type == REG_EXPAND_SZ) return "REG_EXPAND_SZ";
  else if (type == REG_MULTI_SZ) return "REG_MULTI_SZ";
  else if (type == REG_NONE) return "REG_NONE";
  else if (type == REG_SZ) return "REG_SZ";
  else if (type == REG_LINK) return "REG_LINK";
  else if (type == REG_RESOURCE_LIST) return "REG_RESOURCE_LIST";
  else if (type == REG_FULL_RESOURCE_DESCRIPTOR) return "REG_FULL_RESOURCE_DESCRIPTOR";
  else if (type == REG_RESOURCE_REQUIREMENTS_LIST) return "REG_RESOURCE_REQUIREMENTS_LIST";
  else if (type == REG_QWORD) return "REG_QWORD";
  else return "INVALID";
}

// Function: Converts registry data to string
void RegReadType(char *szOutput, char **pType, DWORD dwType, unsigned char *szString, DWORD dwSizeString)
{
  int a=0;
  int b=0;
  szOutput[0]='\0';

  if (dwType == REG_BINARY ||
      dwType == REG_NONE ||
      dwType == REG_LINK ||
      dwType == REG_RESOURCE_REQUIREMENTS_LIST ||
      dwType == REG_RESOURCE_LIST ||
      dwType == REG_FULL_RESOURCE_DESCRIPTOR ||
      dwType == REG_QWORD)
  {
    str2hexA(szString, dwSizeString, szOutput, NSIS_MAX_STRLEN, TRUE);
  }
  else if (dwType == REG_SZ ||
           dwType == REG_EXPAND_SZ)
  {
    lstrcpyn(szOutput, (char *)szString, dwSizeString);
  }
  else if (dwType == REG_MULTI_SZ)
  {
    for (a=0, b=dwSizeString - 1; a < 2 && b >= 0 && !szString[b]; ++a, --b);

    for (a=0; a <= b; ++a)
    {
      if (!szString[a]) szOutput[a]='\n';
      else szOutput[a]=szString[a];
    }
    szOutput[a]='\0';
  }
  else if (dwType == REG_DWORD)
  {
    wsprintf(szOutput, "%d", *((unsigned int *)szString));
  }
  else if (dwType == REG_DWORD_BIG_ENDIAN)
  {
    wsprintf(szOutput, "%d", SWAP_ENDIAN(*((unsigned int *)szString)));
  }

  *pType=TypeValueToTypeName(dwType);
}

// Function from NSIS source: Converts string with binary data to binary data
void HexStrToHexData(char *pHexStr, unsigned char *pHexData, int *nHexLen)
{
  int nLen=0;
  int a,b,c;

  while (*pHexStr)
  {
    a=*pHexStr;
    if (a >= '0' && a <= '9') a-='0';
    else if (a >= 'a' && a <= 'f') a-='a'-10;
    else if (a >= 'A' && a <= 'F') a-='A'-10;
    else break;
    b=*++pHexStr;
    if (b >= '0' && b <= '9') b-='0';
    else if (b >= 'a' && b <= 'f') b-='a'-10;
    else if (b >= 'A' && b <= 'F') b-='A'-10;
    else break;
    pHexStr++;
    c=(a<<4)|b;
    pHexData[nLen++]=c;
  }
  *nHexLen=nLen;
}

LONG RegDeleteSubKeys(HKEY hKey, LPCTSTR lpSubKey)
{
  char szKeyTmp[MAX_PATHLEN];
  HKEY hSubKey;
  DWORD dwSizeKey=sizeof(szKeyTmp);
  DWORD dwIndex=0;
  int nError;

  if ((nError=API_RegOpenKeyEx(hKey, lpSubKey, 0, KEY_ENUMERATE_SUB_KEYS, &hSubKey)) == ERROR_SUCCESS)
  {
    while (API_RegEnumKeyEx(hSubKey, dwIndex, szKeyTmp, &dwSizeKey, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
    {
      if (RegDeleteSubKeys(hSubKey, szKeyTmp) != ERROR_SUCCESS)
        ++dwIndex;
      dwSizeKey=sizeof(szKeyTmp);
    }
    API_RegCloseKey(hSubKey);
    nError=API_RegDeleteKey(hKey, lpSubKey);
  }
  return nError;
}

// Function: Tries to delete registry key in one step (Win9x/Me),
// if error then calls RegDeleteSubKeys
int RegDeleteKeyPath(HKEY hKeyRoot, char *szPath)
{
  char *pKeyName=szPath + lstrlen(szPath) - 1;
  HKEY hKeyHandle;
  int nError=-1;

  while (pKeyName >= szPath && *pKeyName != '\\') --pKeyName;

  if (pKeyName < szPath) return -1;
  *pKeyName++='\0';

  if (API_RegOpenKeyEx(hKeyRoot, szPath, 0, KEY_ENUMERATE_SUB_KEYS, &hKeyHandle) == ERROR_SUCCESS)
  {
    if ((nError=API_RegDeleteKey(hKeyHandle, pKeyName)) != ERROR_SUCCESS)
    {
      nError=RegDeleteSubKeys(hKeyHandle, pKeyName);
    }
    API_RegCloseKey(hKeyHandle);
  }
  return (nError == ERROR_SUCCESS)?0:-1;
}

// Function: Recursively copies registry key
LONG RegCopyKey(HKEY hSource, char *szPathSource, HKEY hTarget, char *szPathTarget)
{
  //Global variables: szKey, szValue, szString

  DWORD dwSizeKey;
  DWORD dwSizeValue;
  DWORD dwSizeString;
  DWORD dwType;
  DWORD dwIndex;
  DWORD dwDisposition;
  HKEY hSourceHandle;
  HKEY hTargetHandle;
  int nError;

  if ((nError=API_RegOpenKeyEx(hSource, szPathSource, 0, KEY_READ, &hSourceHandle)) != ERROR_SUCCESS ||
      (nError=API_RegCreateKeyEx(hTarget, szPathTarget, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hTargetHandle, &dwDisposition)) != ERROR_SUCCESS)
  {
    return nError;
  }

  dwIndex=0;
  while (1)
  {
    dwSizeValue=sizeof(szValue);
    dwSizeString=sizeof(szString);
    szString[0]='\0';
    if (API_RegEnumValue(hSourceHandle, dwIndex++, szValue, &dwSizeValue, NULL, &dwType, szString, &dwSizeString) != ERROR_SUCCESS)
      break;

    API_RegSetValueEx(hTargetHandle, szValue, 0, dwType, szString, dwSizeString);
  }

  dwIndex=0;
  while (1)
  {
    dwSizeKey=sizeof(szKey);
    if (API_RegEnumKeyEx(hSourceHandle, dwIndex++, szKey, &dwSizeKey, NULL, NULL, NULL, NULL) != ERROR_SUCCESS)
    {
      API_RegCloseKey(hSourceHandle);
      API_RegCloseKey(hTargetHandle);
      return ERROR_SUCCESS;
    }

    RegCopyKey(hSourceHandle, szKey, hTargetHandle, szKey);
  }
}

// Function: Writes registry data to file (REGEDIT4 format)
void RegWriteType(HANDLE hFileWrite, char *szValueName, DWORD dwType, unsigned char *szString, DWORD dwSizeString)
{
  //Global variables: szBuf, szBuf2

  unsigned int i=0;
  int nCurWidth=0;
  int nColumnWidth;
  DWORD dwNumberOfBytesWritten;

  if (!*szValueName)
  {
    lstrcpy(szBuf2, "@");
  }
  else
  {
    ReplaceEscapeSequence(szBuf, szValueName);
    wsprintf(szBuf2, "\"%s\"", szBuf);
  }

  if (dwType == REG_BINARY ||
      dwType == REG_EXPAND_SZ ||
      dwType == REG_MULTI_SZ ||
      dwType == REG_DWORD_BIG_ENDIAN ||
      dwType == REG_NONE ||
      dwType == REG_LINK ||
      dwType == REG_RESOURCE_LIST ||
      dwType == REG_FULL_RESOURCE_DESCRIPTOR ||
      dwType == REG_RESOURCE_REQUIREMENTS_LIST ||
      dwType == REG_QWORD)
  {
    if (dwType == REG_BINARY)
      lstrcat(szBuf2, "=hex:");
    else if (dwType == REG_NONE)
      lstrcat(szBuf2, "=hex(0):");
    else if (dwType == REG_EXPAND_SZ)
      lstrcat(szBuf2, "=hex(2):");
    else if (dwType == REG_DWORD_BIG_ENDIAN)
      lstrcat(szBuf2, "=hex(5):");
    else if (dwType == REG_LINK)
      lstrcat(szBuf2, "=hex(6):");
    else if (dwType == REG_MULTI_SZ)
      lstrcat(szBuf2, "=hex(7):");
    else if (dwType == REG_RESOURCE_LIST)
      lstrcat(szBuf2, "=hex(8):");
    else if (dwType == REG_FULL_RESOURCE_DESCRIPTOR)
      lstrcat(szBuf2, "=hex(9):");
    else if (dwType == REG_RESOURCE_REQUIREMENTS_LIST)
      lstrcat(szBuf2, "=hex(a):");
    else if (dwType == REG_QWORD)
      lstrcat(szBuf2, "=hex(b):");

    if (dwSizeString == 0)
    {
      lstrcat(szBuf2, "\r\n");
      WriteFile(hFileWrite, szBuf2, lstrlen(szBuf2), &dwNumberOfBytesWritten, NULL);
      return;
    }

    nColumnWidth=(79 - lstrlen(szBuf2)) / 3;

    if (nColumnWidth <= 0)
      nColumnWidth=1;

    for (; i < dwSizeString; lstrcpy(szBuf2, "  "), nColumnWidth=25)
    {
      for (nCurWidth=0; i < dwSizeString && nCurWidth < nColumnWidth; ++i, ++nCurWidth)
      {
        wsprintf(szName, "%02x,", (unsigned int)szString[i]);
        lstrcat(szBuf2, szName);
      }
      if (i == dwSizeString)
      {
        szBuf2[lstrlen(szBuf2) - 1]='\0';
        lstrcat(szBuf2, "\r\n");
      }
      else lstrcat(szBuf2, "\\\r\n");

      WriteFile(hFileWrite, szBuf2, lstrlen(szBuf2), &dwNumberOfBytesWritten, NULL);
    }
  }
  else if (dwType == REG_SZ)
  {
    ReplaceEscapeSequence(szBuf, (char *)szString);
    lstrcat(szBuf2, "=\"");
    lstrcat(szBuf2, szBuf);
    lstrcat(szBuf2, "\"\r\n");
    WriteFile(hFileWrite, szBuf2, lstrlen(szBuf2), &dwNumberOfBytesWritten, NULL);
  }
  else if (dwType == REG_DWORD)
  {
    wsprintf(szBuf, "%s=dword:%08x\r\n", szBuf2, *((unsigned int *)szString));
    WriteFile(hFileWrite, szBuf, lstrlen(szBuf), &dwNumberOfBytesWritten, NULL);
  }
}

// Function: Converts escape sequences (\\ -> \\\\), (\" -> \\\"), (\r -> \\r), (\n -> \\n)
void ReplaceEscapeSequence(char *pResult, char *pText)
{
  int a=0;
  int b=0;

  for (; pText[a]; ++a, ++b)
  {
    if (pText[a] == '\\')
      pResult[b]='\\', pResult[++b]='\\';
    else if (pText[a] == '\"')
      pResult[b]='\\', pResult[++b]='\"';
    else if (pText[a] == '\r')
      pResult[b]='\\', pResult[++b]='r';
    else if (pText[a] == '\n')
      pResult[b]='\\', pResult[++b]='n';
    else pResult[b]=pText[a];
  }
  pResult[b]='\0';
}

#ifndef POCKETPC
// Function: Checks is file exist
BOOL FileExists(char *fname)
{
  WIN32_FIND_DATA wfd;
  HANDLE hFind=FindFirstFile(fname, &wfd);

  if (INVALID_HANDLE_VALUE != hFind)
  {
    FindClose(hFind);
    return TRUE;
  }
  return FALSE;
}
#endif //POCKETPC


//Standart registry API calls
LONG API_RegOpenKeyEx(HKEY hKey, LPCTSTR lpSubKey, DWORD ulOptions, REGSAM c, PHKEY phkResult)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegOpenKeyEx(hKey, lpSubKey, 0, c, phkResult);
#else
  MultiByteToWideChar(CP_ACP, 0, lpSubKey, -1, wszBuf, MAX_PATHLEN);
  nError=CeRegOpenKeyEx(hKey, wszBuf, 0, 0, phkResult);
#endif
  return nError;
}

LONG API_RegEnumKeyEx(HKEY hKey, DWORD dwIndex, LPTSTR lpName, LPDWORD lpcName, LPDWORD lpReserved, LPTSTR lpClass, LPDWORD lpcClass, PFILETIME lpftLastWriteTime)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegEnumKeyEx(hKey, dwIndex, lpName, lpcName, NULL, NULL, NULL, NULL);
#else
  nError=CeRegEnumKeyEx(hKey, dwIndex, wszBuf, lpcName, NULL, NULL, NULL, NULL);

  if (nError == ERROR_SUCCESS)
  {
    WideCharToMultiByte(CP_ACP, 0, wszBuf, -1, lpName, MAX_PATHLEN, NULL, NULL);
  }
#endif
  return nError;
}

LONG API_RegCreateKeyEx(HKEY hKey, LPCTSTR lpSubKey, DWORD Reserved, LPTSTR lpClass, DWORD dwOptions, REGSAM samDesired, LPSECURITY_ATTRIBUTES lpSecurityAttributes, PHKEY phkResult, LPDWORD lpdwDisposition)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegCreateKeyEx(hKey, lpSubKey, 0, NULL, dwOptions, samDesired, NULL, phkResult, lpdwDisposition);
#else
  MultiByteToWideChar(CP_ACP, 0, lpSubKey, -1, wszBuf, MAX_PATHLEN);
  nError=CeRegCreateKeyEx(hKey, wszBuf, 0, L"", 0, 0, NULL, phkResult, lpdwDisposition);
#endif
  return nError;
}

LONG API_RegCloseKey(HKEY hKey)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegCloseKey(hKey);
#else
  nError=CeRegCloseKey(hKey);
#endif
  return nError;
}

LONG API_RegDeleteKey(HKEY hKey, LPCTSTR lpSubKey)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegDeleteKey(hKey, lpSubKey);
#else
  MultiByteToWideChar(CP_ACP, 0, lpSubKey, -1, wszBuf, MAX_PATHLEN);
  nError=CeRegDeleteKey(hKey, wszBuf);
#endif
  return nError;
}

LONG API_RegEnumValue(HKEY hKey, DWORD dwIndex, LPTSTR lpValueName, LPDWORD lpcValueName, LPDWORD lpReserved, LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegEnumValue(hKey, dwIndex, lpValueName, lpcValueName, NULL, lpType, lpData, lpcbData);
#else
  unsigned char *pwszData=(unsigned char *)wszData;
  DWORD i;

  if (!lpData) pwszData=NULL;
  nError=CeRegEnumValue(hKey, dwIndex, wszBuf, lpcValueName, NULL, lpType, pwszData, lpcbData);

  if (nError == ERROR_SUCCESS)
  {
    WideCharToMultiByte(CP_ACP, 0, wszBuf, -1, lpValueName, MAX_PATHLEN, NULL, NULL);

    if (pwszData)
    {
      if (*lpType == REG_SZ ||
          *lpType == REG_EXPAND_SZ)
      {
        WideCharToMultiByte(CP_ACP, 0, wszData, -1, lpData, MAX_DATALEN, NULL, NULL);
        *lpcbData/=sizeof(wchar_t);
      }
      else for (i=0; i <= *lpcbData; ++i) lpData[i]=pwszData[i];
    }
  }
#endif
  return nError;
}

LONG API_RegDeleteValue(HKEY hKey, LPCTSTR lpValueName)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegDeleteValue(hKey, lpValueName);
#else
  MultiByteToWideChar(CP_ACP, 0, lpValueName, -1, wszBuf, MAX_PATHLEN);
  nError=CeRegDeleteValue(hKey, wszBuf);
#endif
  return nError;
}

LONG API_RegQueryValueEx(HKEY hKey, LPCTSTR lpValueName, LPDWORD lpReserved, LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegQueryValueEx(hKey, lpValueName, NULL, lpType, lpData, lpcbData);
#else
  unsigned char *pwszData=(unsigned char *)wszData;
  DWORD i;

  if (!lpData) pwszData=NULL;
  MultiByteToWideChar(CP_ACP, 0, lpValueName, -1, wszBuf, MAX_PATHLEN);
  nError=CeRegQueryValueEx(hKey, wszBuf, NULL, lpType, pwszData, lpcbData);

  if (nError == ERROR_SUCCESS)
  {
    if (pwszData)
    {
      if (*lpType == REG_SZ ||
          *lpType == REG_EXPAND_SZ)
      {
        WideCharToMultiByte(CP_ACP, 0, wszData, -1, lpData, MAX_DATALEN, NULL, NULL);
        *lpcbData/=sizeof(wchar_t);
      }
      else for (i=0; i <= *lpcbData; ++i) lpData[i]=pwszData[i];
    }
  }
#endif
  return nError;
}

LONG API_RegSetValueEx(HKEY hKey, LPCTSTR lpValueName, DWORD Reserved, DWORD dwType, BYTE* lpData, DWORD cbData)
{
  LONG nError;
#ifndef POCKETPC
  nError=RegSetValueEx(hKey, lpValueName, 0, dwType, lpData, cbData);
#else
  unsigned char *pwszData=(unsigned char *)wszData;

  MultiByteToWideChar(CP_ACP, 0, lpValueName, -1, wszBuf, MAX_PATHLEN);

  if (dwType == REG_SZ ||
      dwType == REG_EXPAND_SZ)
  {
    MultiByteToWideChar(CP_ACP, 0, lpData, -1, wszData, MAX_DATALEN);
    cbData*=sizeof(wchar_t);
  }
  else pwszData=lpData;

  nError=CeRegSetValueEx(hKey, wszBuf, 0, dwType, pwszData, cbData);
#endif
  return nError;
}

int popinteger()
{
  char szInt[32];

  popstring(szInt, 31);
  return xatoiA(szInt);
}

void pushinteger(int integer)
{
  char szInt[32];

  xitoaA(integer, szInt, 0);
  pushstring(szInt, 32);
}

//Function: Removes the element from the top of the NSIS stack and puts it in the buffer
int popstring(char *str, int len)
{
  stack_t *th;

  if (!g_stacktop || !*g_stacktop) return 1;
  th=(*g_stacktop);
  lstrcpyn(str, th->text, len);
  *g_stacktop=th->next;
  GlobalFree((HGLOBAL)th);
  return 0;
}

//Function: Adds an element to the top of the NSIS stack
void pushstring(const char *str, int len)
{
  stack_t *th;

  if (!g_stacktop) return;
  th=(stack_t*)GlobalAlloc(GPTR, sizeof(stack_t) + len);
  lstrcpyn(th->text, str, len);
  th->next=*g_stacktop;
  *g_stacktop=th;
}
